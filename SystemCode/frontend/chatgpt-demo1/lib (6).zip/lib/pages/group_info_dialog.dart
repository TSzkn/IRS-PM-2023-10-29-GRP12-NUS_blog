
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../utils/dio_util.dart';
import '../utils/userBean.dart';

class GroupInfoDialog extends StatefulWidget {
  const GroupInfoDialog({Key? key,  required this.groupId,}) : super(key: key);
  final int groupId;

  @override
  _GroupInfoDialogState createState() => _GroupInfoDialogState();
}

class _GroupInfoDialogState extends State<GroupInfoDialog> with SingleTickerProviderStateMixin {
  String data = 'Loading...';
  bool loading = true;
  GroupItem groupItem = GroupItem();
  late AnimationController controller;

  @override
  void initState() {
    super.initState();
    loading = true;
    controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
    )..repeat();
    fetchDataFromBackend();
  }

  @override
  void dispose() {
    controller.dispose(); // Dispose of the animation controller
    super.dispose(); // Ensure the widget is disposed of properly
  }

  Future<void> fetchDataFromBackend() async {

    try {
      // Map<String, String> getGroupInfo = {"username":_unameController.text, "password":_pwdController.text};
      // logInInfo(loginInfo);
      await DioUtil.getGroupInfo(widget.groupId).then((value){
        // showLoading=false;
        if(value.resultStatus==200){
          // var json = jsonDecode(value.data);
          // groupItem = GroupItem.fromJson(json);
          // var json = jsonDecode(value.data);
          groupItem = GroupItem.fromJson(value.data);

          print(groupItem.groupId);
        }
      });
      // http://127.0.0.1:5000/login/

    } on DioError catch(e) {

    } finally {

    }
    loading = false;
    setState(() {

    });
  //   // Simulate a network call
  //   await Future.delayed(Duration(seconds: 2));
  //
  //   // Once data is fetched, update the state
  //   if (mounted) {
  //     setState(() {
  //       data = 'Data retrieved from backend!';
  //     });
  //   }
  }

  @override
  Widget build(BuildContext context) {
    // return AlertDialog(
    //   content: Text(data),
    //   actions: <Widget>[
    //     TextButton(
    //       onPressed: () => Navigator.of(context).pop(),
    //       child: Text('OK'),
    //     ),
    //   ],
    // );
    return Dialog(
      child: Container(
        width: 200,
        height: 200,
        child: loading?Center(
          child: RotationTransition(
              turns: Tween(begin: 0.0, end: 1.0).animate(controller),
              child: Container(
                width: 100,
                height: 100,
                child: Image.asset(
                  'assets/images/lion_laugh.png',
                  fit: BoxFit.fill,
                  // width: moveWidgetHeight,
                ),
              ),
        )):Column(
                  children: [
                    // Text("creator Name:"),
                    // Text("NUS-group-org"),
                    const Text("groupName:"),
                    Text(groupItem.groupName.toString()),
                    const Text("groupDescription:"),
                    Text(groupItem.groupDescription.toString()),
                    const Text("groupId:"),
                    Text(groupItem.groupId.toString()),
                  ],
                ),
      ),
    );
  }
}
import 'dart:typed_data';
import 'package:chatgpt/pages/blog_page.dart';
import 'package:chatgpt/utils/color_setting.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:google_fonts/google_fonts.dart';
import '../utils/dio_util.dart';
import '../utils/blog_bean.dart';
import '../utils/userBean.dart';

enum ActiveTab { trending, recommendation, latest }

class TrendingPage extends StatefulWidget {
  const TrendingPage(
      {Key? key, required this.userItem, required this.userDataChange})
      : super(key: key);

  final userBean userItem;
  final Function(userBean) userDataChange;

  @override
  State<TrendingPage> createState() => _TrendingPageState();
}

class _TrendingPageState extends State<TrendingPage>
    with TickerProviderStateMixin {
  TextEditingController textEditingController = TextEditingController();
  ActiveTab currentActiveTab = ActiveTab.recommendation;
  final _pageKey = const PageStorageKey('trending_page');

  ///status codes
  int roundState = 3;
  int jumpState = 0;
  int animationDuration = 500;
  double tabHeight = 100;
  double tabMaxHeight = 150;
  double tabWidth = 100;
  double tabMaxWidth = 125;
  double imageWidth = 60;
  double jumpHeight = 175;
  int currentPageNumber = 1;

  ///controllers
  late AnimationController _controller = AnimationController(
    vsync: this,
    duration: Duration(milliseconds: animationDuration),
  );

  late AnimationController _controller_jump = AnimationController(
    vsync: this,
    duration: Duration(milliseconds: animationDuration),
  );
  late Animation _animation_jump;

  final _pagingController = PagingController<int, dynamic>(firstPageKey: 1);
  final _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _pagingController.addPageRequestListener(_fetchPage);

    ///animation
    _controller = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: animationDuration),
    );

    _controller_jump = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: animationDuration),
    );

    _animation_jump = TweenSequence([
      TweenSequenceItem(tween: Tween<double>(begin: 0.0, end: 1.0), weight: 1),
      TweenSequenceItem(tween: Tween<double>(begin: 1.0, end: 0.0), weight: 1),
    ]).animate(_controller_jump);

    _animation_jump.addListener(() {
      setState(() {}); // 动画的值变化时刷新UI
    });
  }

  late bool showLoading = false;
  late Uint8List recording;
  final _transcriptionController = TextEditingController();

/// Recording variables
  bool isRecording = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: true,
        // floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
        // floatingActionButton: AvatarGlow(
        //   animate: _isListening,
        //   glowColor: Theme
        //       .of(context)
        //       .primaryColor,
        //   endRadius: 75.0,
        //   duration: const Duration(milliseconds: 2000),
        //   repeatPauseDuration: const Duration(milliseconds: 100),
        //   repeat: true,
        //   child: FloatingActionButton(
        //     onPressed: _next,
        //     child: Icon(_isListening ? Icons.mic : Icons.mic_none),
        //   ),
        // ),
        body: Column(
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Container(
                  height: jumpHeight,
                ),
                Spacer(),
                Container(
                  width: 2 * tabWidth + tabMaxWidth,
                  child: Row(
                    children: [
                      AnimatedContainer(
                        duration: Duration(milliseconds: animationDuration),
                        curve: Curves.decelerate,
                        width: currentActiveTab == ActiveTab.recommendation
                            ? (tabMaxWidth - imageWidth) / 2
                            : currentActiveTab == ActiveTab.trending
                                ? (tabMaxWidth - imageWidth) / 2 + tabWidth
                                : (tabMaxWidth - imageWidth) / 2 + tabWidth * 2,
                        height: 10,
                      ),
                      Column(
                        children: [
                          RotationTransition(
                            turns: _controller,
                            child: Image.asset(
                              'assets/images/lion_jump.png',
                              fit: BoxFit.cover,
                              width: imageWidth,
                            ),
                          ),
                          Container(
                            // color: Colors.brown,
                            height: _animation_jump.value * 100,
                            width: 10,
                            //其他属性
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Spacer()
              ],
            ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                SizedBox(
                  height: tabMaxHeight,
                ),
                Spacer(),
                Column(
                  children: [
                    AnimatedContainer(
                      duration: Duration(milliseconds: animationDuration),
                      curve: Curves.easeOut,
                      width: currentActiveTab == ActiveTab.recommendation
                          ? tabMaxWidth
                          : tabWidth,
                      height: currentActiveTab == ActiveTab.recommendation
                          ? tabMaxHeight
                          : tabHeight,
                      child: SizedBox(
                        width: 50,
                        height: currentActiveTab == ActiveTab.recommendation
                            ? tabHeight
                            : tabMaxHeight,
                        child: InkWell(
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(10.0),
                                  topRight: Radius.circular(10.0)),
                              color:
                                  currentActiveTab == ActiveTab.recommendation
                                      ? MyColor.deepBlue
                                      : MyColor.lighterDeepBlue,
                            ),
                            child: Text(
                              'Recommendation',
                              textAlign: TextAlign.left,
                              style: GoogleFonts.inter(
                                fontSize: 20,
                                fontWeight: FontWeight.w900,
                                height: 1.2125,
                                letterSpacing: 0.2,
                                color: Color(0xfffffffe),
                              ),
                            ),
                          ),
                          onTapDown: (TapDownDetails details) {
                            setState(() {
                              _refresh();
                              currentActiveTab = ActiveTab.recommendation;
                              //               roundState = 3;
                              _controller.forward(from: 0.0);
                              _controller.fling(velocity: 0.005);
                              _controller_jump.forward(from: 0.0);
                            });
                          },
                          onTapCancel: () {},
                        ),
                      ),
                    ),
                  ],
                ),
                Column(
                  children: [
                    AnimatedContainer(
                      duration: Duration(milliseconds: animationDuration),
                      curve: Curves.easeOut,
                      width: currentActiveTab == ActiveTab.trending
                          ? tabMaxWidth
                          : tabWidth,
                      height: currentActiveTab == ActiveTab.trending
                          ? tabMaxHeight
                          : tabHeight,
                      child: SizedBox(
                        width: 50,
                        height: currentActiveTab == ActiveTab.trending
                            ? tabHeight
                            : tabMaxHeight,
                        child: InkWell(
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(10.0),
                                  topRight: Radius.circular(10.0)),
                              color: currentActiveTab == ActiveTab.trending
                                  ? MyColor.deepBlue
                                  : MyColor.lighterDeepBlue,
                            ),
                            child: Text(
                              'Trending',
                              textAlign: TextAlign.center,
                              style: GoogleFonts.inter(
                                fontSize: 20,
                                fontWeight: FontWeight.w900,
                                height: 1.2125,
                                letterSpacing: 0.2,
                                color: Color(0xfffffffe),
                              ),
                            ),
                          ),
                          onTapDown: (TapDownDetails details) {
                            setState(() {
                              _refresh();
                              currentActiveTab = ActiveTab.trending;
                              _controller.forward(from: 0.0);
                              _controller.fling(velocity: 0.005);
                              _controller_jump.forward(from: 0.0);
                            });
                          },
                          onTapCancel: () {},
                        ),
                      ),
                    ),
                  ],
                ),
                Column(
                  children: [
                    AnimatedContainer(
                      duration: Duration(milliseconds: animationDuration),
                      curve: Curves.easeOut,
                      width: currentActiveTab == ActiveTab.latest
                          ? tabMaxWidth
                          : tabWidth,
                      height: currentActiveTab == ActiveTab.latest
                          ? tabMaxHeight
                          : tabHeight,
                      child: SizedBox(
                        width: 50,
                        height: currentActiveTab == ActiveTab.latest
                            ? tabHeight
                            : tabMaxHeight,
                        child: InkWell(
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(10.0),
                                  topRight: Radius.circular(10.0)),
                              color: currentActiveTab == ActiveTab.latest
                                  ? MyColor.deepBlue
                                  : MyColor.lighterDeepBlue,
                            ),
                            child: Text(
                              'Latest',
                              textAlign: TextAlign.center,
                              style: GoogleFonts.inter(
                                fontSize: 20,
                                fontWeight: FontWeight.w900,
                                height: 1.2125,
                                letterSpacing: 0.2,
                                color: Color(0xfffffffe),
                              ),
                            ),
                          ),
                          onTapDown: (TapDownDetails details) {
                            setState(() {
                              _refresh();
                              currentActiveTab = ActiveTab.latest;
                              _controller.forward(from: 0.0);
                              _controller.fling(velocity: 0.005);
                              _controller_jump.reverse(from: 1.0);
                            });
                          },
                          onTapCancel: () {},
                        ),
                      ),
                    ),
                  ],
                ),
                Spacer()
              ],
            ),

            Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height -
                  jumpHeight -
                  tabMaxHeight,
              child: RefreshIndicator(
                onRefresh: _refresh,
                child: CustomScrollView(
                  controller: _scrollController,
                  slivers: [
                    PagedSliverList<int, dynamic>(
                      key: _pageKey,
                      pagingController: _pagingController,
                      builderDelegate: PagedChildBuilderDelegate<dynamic>(
                        animateTransitions: false,
                        itemBuilder: _itemBuilder,
                        newPageProgressIndicatorBuilder: (_) =>
                            UnconstrainedBox(
                                child: SizedBox(
                                    width: 32,
                                    height: 32,
                                    child: CircularProgressIndicator(
                                      color: Theme.of(context).primaryColor,
                                      strokeWidth: 2,
                                    ))),

                        ///修改这里！！！！

                        // firstPageErrorIndicatorBuilder: (_) => ListErrorWidget(
                        //   onRetry: _pagingController.refresh,
                        // ),
                        // noItemsFoundIndicatorBuilder: (_) => HomeFirstPageEmptyIndicator(
                        //   items: _recommendUnknownUserList,
                        // ),
                        // noMoreItemsIndicatorBuilder: (_) => HomeLoadMoreEmptyIndicator(
                        //   items: _recommendUnknownUserList,
                        // )
                      ),
                    ),
                    SliverToBoxAdapter(
                      child: SizedBox(
                        height: MediaQuery.of(context).padding.bottom,
                      ),
                    )
                  ],
                ),
              ),
            )

            // SingleChildScrollView(
            //   reverse: true,
            //   child: Container(
            //     padding: const EdgeInsets.fromLTRB(30.0, 30.0, 30.0, 150.0),
            //     // child: TextHighlight(
            //     //     text: _text,
            //     //     words: _highlights,
            //     //     textStyle: const TextStyle(
            //     //         fontSize: 32.0,
            //     //         color: Colors.black,
            //     //         fontWeight: FontWeight.w400
            //     //     )
            //     // )
            //   ),
            // )
          ],
        ));
  }

  Future _refresh() async {
    return Future.sync(() => _pagingController.refresh());
  }

  Widget _itemBuilder(BuildContext context, dynamic item, int index) {
    var items = _pagingController.itemList;
    return InkWell(
        child: Container(
          width: 100,
          height: 50,
          decoration: BoxDecoration(
            color: MyColor.pureWhite, // 设置背景颜色
            border: Border.symmetric(
              vertical: BorderSide(
                color: MyColor.orange, // 框的边框颜色
                width: 2,
              ),
              horizontal: BorderSide(
                color: MyColor.orange, // 框的边框颜色
                width: 1,
              ),
// 边框宽度
            ),
            borderRadius: BorderRadius.circular(5), // 设置圆角半径
          ),
          alignment: Alignment.centerLeft,
          padding: const EdgeInsets.symmetric(vertical: 10),
          child: Text(
            _pagingController.itemList?[index].title,
            textAlign: TextAlign.left,
          ),
        ),
        onTap: () {
          _openBlogPage(_pagingController.itemList?[index].id,
              _pagingController.itemList?[index].title);
        });
    ///、、、、、、、、、、、、、、、、、、、、、、、、、
    ///在这里添加
    ///
    ///
    ///
    // if(index<=10){
    //
    // }
    // else{
    //   return Container();
    // }
  }

  // Future<void> _fetchPage(int page) async {
  //   print("fetching page!!!!");
  //   currentPageNumber++;
  //   String inputvalue = currentActiveTab.name;
  //   List<dynamic> newItems = [];
  //   List<dynamic>? currentList = [];
  //   switch (currentActiveTab) {
  //     case ActiveTab.recommendation:
  //       // currentList = await getHotSearch(currentPageNumber);
  //       currentList = [blogShowBrief(title:page.toString(), id: 1111), blogShowBrief(title:"2", id: 1111),blogShowBrief(title:"3", id: 1111)];
  //
  //       break;
  //     case ActiveTab.trending:
  //       currentList = await getRecommend(currentPageNumber);
  //       break;
  //     case ActiveTab.latest:
  //       break;
  //     default:
  //       print('error!!!');
  //   }
  //
  //   if (currentList!.isNotEmpty) {
  //     newItems = currentList;
  //   }
  //
  //   if (currentPageNumber <= currentPageNumber+1) {
  //     _pagingController.appendPage(newItems, page + 1);
  //   } else {
  //
  //   }
  // }


  Future<void> _fetchPage(int page) async {
    try {
        print("fetching page!!!!");

        String inputvalue = currentActiveTab.name;
        List<dynamic> newItems = [];
        List<dynamic>? currentList = [];

      // final resp = await LinkService().getRecommendShares(page: page);
      // if (resp['code'] == PwHttpClient.success) {
      //   var dataMapList = resp['data'] as List;
      //   var newItems = dataMapList
      //       .map<dynamic>((slm) => SharedLinkModel.fromJson(slm))
      //       .toList();
      //   final isLastPage = newItems.isEmpty;
      //   if (_recommendFoFUserList.isNotEmpty) {
      //     newItems = [...newItems, _recommendFoFUserList.removeAt(0)];
      //   }
      //   if (isLastPage) {
      //     _pagingController.appendLastPage([...newItems]);
      //   } else {
      //     _pagingController.appendPage(newItems, page + 1);
      //   }
      // }
        bool hasMore = true;
        print("currentActiveTab!!!");
        print(currentActiveTab);
      switch (currentActiveTab) {
          case ActiveTab.recommendation:
            var returnResult = await getRecommend(page);
            currentList = returnResult["result"] as List?;
            hasMore = returnResult["has_more"] as bool;
            break;
          case ActiveTab.trending:
            print("trending11");
            var returnResult = await getHotSearch(page);
            print("trending");
            print(returnResult);
            currentList = returnResult["result"] as List?;
            hasMore = returnResult["has_more"] as bool;
            print("hasmore!!!");
            print(hasMore);
            break;
          case ActiveTab.latest:


            break;
          default:
            print('error!!!');
        }

          if (currentList!.isNotEmpty&&hasMore) {
            newItems = currentList;
            _pagingController.appendPage(newItems, page + 1);
          }

        // if (page <= currentPageNumber+1) {
        //   // currentPageNumber++;
        //
        // } else {
        //
        // }
    } catch (error) {
      _pagingController.error = error;
    }
  }

  Future<Map<String, Object>> getHotSearch(int page) async {
    List<blogShowBrief> result = [];
    var returnData = {"has_more": true, "result":result};
    try {
      Map<String, dynamic> PageInfo = {
        "userid": widget.userItem.userID,
        "page": page,
      };
      await DioUtil.getHotSearchList(PageInfo).then((value) {
        if (value.resultStatus == 200) {
          for (var item in value.data) {
            result.add(blogShowBrief.fromJson(item));
          }
          returnData["has_more"]=value.hasMore;
        } else if (value.resultStatus == 201) {
          return [];
        } else if (value.resultStatus == 202) {
          return [];
        } else if (value.resultStatus == 203) {
          return [];
        }
        setState(() {});
      });
    } on DioError catch (e) {
    } finally {}
    return returnData;
  }

  ///!!!!!!
  // 'id': fields.Integer,
  // 'title':fields.String(attribute='title'),
  // 'desc':fields.String(attribute='abstract'),
  // 'datetime':fields.String(attribute='create_time'),
  // 'author':AuthorName(attribute='author'),
  // 'url':fields.Url('hotsearch.hsdetail',absolute=True)#点击响应后去看热搜具体信息 需要前端在title部分做一个超链接访问

  Future<Map<String, Object>> getRecommend(int page) async {
    List<blogShowBrief> result = [];
    var returnData = {"has_more": true, "result":result};
    try {
      Map<String, dynamic> PageInfo = {
        "userid": widget.userItem.userID,
        "page": page,
      };
      await DioUtil.getRecommendationList(PageInfo).then((value) {
        if (value.resultStatus == 200) {
          print(value.data);
          for (var item in value.data) {
            print(item);
            result.add(blogShowBrief.fromJson(item));
          }
          returnData["has_more"]=value.hasMore;
          return result;
        } else if (value.resultStatus == 201) {
          return [];
        } else if (value.resultStatus == 202) {
          return [];
        } else if (value.resultStatus == 203) {
          return [];
        }
        setState(() {});
      });
    } on DioError catch (e) {
    } finally {}
    return returnData;
  }

  Future<Map<String, Object>> getLatest(int page) async {
    List<blogShowBrief> result = [];
    var returnData = {"has_more": true, "result":result};
    try {
      Map<String, dynamic> PageInfo = {
        "userid": widget.userItem.userID,
        "page": page,
      };
      await DioUtil.getLatestList(PageInfo).then((value) {
        if (value.resultStatus == 200) {
          for (var item in value.data) {
            result.add(blogShowBrief.fromJson(item));
          }
          returnData["has_more"]=value.hasMore;
        } else if (value.resultStatus == 201) {
          return [];
        } else if (value.resultStatus == 202) {
          return [];
        } else if (value.resultStatus == 203) {
          return [];
        }
        setState(() {});
      });
    } on DioError catch (e) {
    } finally {}
    return returnData;
  }



  void _openBlogPage(int id, String title) {
    print("tapped!!!");

    ///add net connection later
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => BlogPage(
          blogTitle: title,
          blogId: id,
        ),
      ),
    );
  }
}

import 'dart:typed_data';
import 'package:chatgpt/utils/blog_bean.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import '../utils/color_setting.dart';
import '../utils/dio_util.dart';

class BlogPage extends StatefulWidget {
  const BlogPage({Key? key, required this.blogTitle, required this.blogId})
      : super(key: key);

  final String blogTitle;
  final int blogId;

  @override
  State<BlogPage> createState() => _BlogPageState();
}

class _BlogPageState extends State<BlogPage> {
  TextEditingController textEditingController = TextEditingController();

  late stt.SpeechToText _speech;
  bool _isListening = false;
  String _text = 'Press the hello and start speaking';
  double _confidence = 1.0;
  bool _isLiked = false;
  late blogDetailBean contentDetail;

  @override
  void initState() {
    super.initState();
    getPostContent();

    _speech = stt.SpeechToText();
    _isLiked = false;
  }

  late bool showLoading = false;
  late Uint8List recording;

  final _transcriptionController = TextEditingController();

// Recording variables
  bool isRecording = false;

  @override
  Widget build(BuildContext context) {
    //User user = getUserFromBackend();
    //Post post = getPostFromBackend();
    return Scaffold(
      appBar: AppBar(
        backgroundColor: MyColor.orange, // 设置 AppBar 的背景颜色
        title: Text(
          "${widget.blogTitle}",
          maxLines: null,
        ), //将maxLines属性设置为null，以允许标题文本自动换行
        leading: IconButton(
          // 这里是左侧的 IconButton
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            // 处理返回操作
            Navigator.of(context).pop();
          },
        ),
      ),
      body: SingleChildScrollView(
        reverse: true,
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.all(16.0),
              margin: EdgeInsets.all(16.0),
              decoration: BoxDecoration(
                color: Color(0xFFEFEFEF),
                border: Border.all(
                  color: MyColor.orange,
                  width: 1.0,
                ),
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(contentDetail.author!),
                        //"${user.name}",
                        Text(contentDetail.datetime!),
                        //"${post.datetime}",
                      ],
                    ),
                    SizedBox(height: 32.0), // 上边空行
                    Center(
                      // 将"Content"及其"SizedBox"放在中央
                      child: Column(
                        children: [
                          Text(contentDetail.content!),
                          //"${post.content}",
                          SizedBox(height: 128.0), // 下边空行
                        ],
                      ),
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            InkWell(
                              onTap: () {
                                setState(() {
                                  _isLiked = !_isLiked; // 切换点赞状态
                                });
                              },
                              child: Icon(
                                Icons.thumb_up,
                                color: _isLiked ? Colors.orange : Colors.grey,
                              ),
                            ),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'Hit:${contentDetail.views!.toString()}',
                              //"${post.hit}",
                              style: TextStyle(color: Colors.grey),
                            ),
                            Text(
                              contentDetail.likes!.toString(),
                              //"${post.clickNumber}",
                              style: TextStyle(color: Colors.grey),
                            ), // likes
                          ],
                        ),
                      ],
                    )
                  ],
                ),
              ),
            )
            // 此处放置页面内容
          ],
        ),
      ),
    );
  }

  Future<void> getPostContent() async {
    try {
      // content = request.json.get('blog')
      // userid = request.json.get('userid')
      // abstarct = request.json.get('abstract')
      // title = request.json.get('title')

      Map<String, dynamic> blogId = {"id": widget.blogId};
      await DioUtil.getBlogDetails(blogId).then((value) {
        // showLoading=false;
        if (value.resultStatus == 200) {
          // var json = jsonDecode(value.data);
          // contentDetail = blogDetailBean.fromJson(json);
          // var json = jsonDecode(value.data);
          contentDetail = blogDetailBean.fromJson(value.data);
        } else if (value.resultStatus == 201) {
          // showAlert(context, "手机号码或者密码错误，请确认好在登录");
        } else if (value.resultStatus == 202) {
          // showAlert(context, "用户不存在");
        } else {}
        print(value);

        // if(value.isSuccess){
        //   histories.insert(0,ChatMessage.assistant(value.data));
        // }
      });
      // http://127.0.0.1:5000/login/
    } on DioError catch (e) {
      // //登录失败则提示
      // if (e.response?.statusCode == 401) {
      //   showToast(GmLocalizations.of(context).userNameOrPasswordWrong);
      // } else {
      //   showToast(e.toString());
      // }
    } finally {
      // 隐藏loading框
      // Navigator.of(context).pop();
    }
    ;
  }
}

import 'package:chatgpt/pages/login.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../utils/color_setting.dart';
import '../utils/dio_util.dart';
import 'main_page_controller.dart';

// import '../index.dart';

class SignUpRoute extends StatefulWidget {
  @override
  _SignUpRouteState createState() => _SignUpRouteState();
}

class _SignUpRouteState extends State<SignUpRoute> {
  TextEditingController _phoneNumController = TextEditingController();
  TextEditingController _unameController = TextEditingController();
  TextEditingController _nickNameController = TextEditingController();
  TextEditingController _pwdController = TextEditingController();
  TextEditingController _pwd2Controller = TextEditingController();
  bool pwdShow = false;
  GlobalKey _formKey = GlobalKey<FormState>();
  bool _nameAutoFocus = true;

  @override
  void initState() {
    // 自动填充上次登录的用户名，填充后将焦点定位到密码输入框
    // _unameController.text = Global.profile.lastLogin ?? "";
    _unameController.text = "";
    if (_unameController.text.isNotEmpty) {
      _nameAutoFocus = false;
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var gm = context;
    return Scaffold(
      appBar: AppBar(title: Text(""),backgroundColor: MyColor.orange,),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            autovalidateMode: AutovalidateMode.onUserInteraction,
            child: Column(
              children: <Widget>[
                TextFormField(
                    autofocus: _nameAutoFocus,
                    controller: _phoneNumController,
                    decoration: InputDecoration(
                      labelText: "phone number",
                      hintText: "phone number",
                      labelStyle: const TextStyle(
                        color: MyColor.orange,  // Set the color for the label text here
                      ),
                      enabledBorder: const UnderlineInputBorder(
                        borderSide: BorderSide(color: MyColor.orange, width: 2),
                        borderRadius: BorderRadius.all(Radius.circular(8.0)), // 设置边框的圆角
                      ),
                      focusedBorder: const UnderlineInputBorder(
                        borderSide: BorderSide(color: MyColor.orange, width: 5),
                        borderRadius: BorderRadius.all(Radius.circular(8.0)), // 设置边框的圆角
                      ),
                      prefixIcon: Icon(Icons.person),
                    ),
                    // 校验用户名（不能为空）
                    validator: (v) {
                      return v==null||v.trim().isNotEmpty ? null : "userNameRequired";
                    }),
                // Row(
                //   children: [
                //     TextFormField(
                //         autofocus: _nameAutoFocus,
                //         controller: _unameController,
                //         decoration: InputDecoration(
                //           labelText: "OTP",
                //           hintText: "OTP",
                //           prefixIcon: Icon(Icons.person),
                //         ),
                //         // 校验用户名（不能为空）
                //         validator: (v) {
                //           return v==null||v.trim().isNotEmpty ? null : "userNameRequired";
                //         }),
                //     // Spacer()
                //   ],
                // ),
                TextFormField(
                    autofocus: _nameAutoFocus,
                    controller: _unameController,
                    decoration: InputDecoration(
                      labelText: "userName",
                      hintText: "userName",
                      labelStyle: const TextStyle(
                        color: MyColor.orange,  // Set the color for the label text here
                      ),
                      enabledBorder: const UnderlineInputBorder(
                        borderSide: BorderSide(color: MyColor.orange, width: 2),
                        borderRadius: BorderRadius.all(Radius.circular(8.0)), // 设置边框的圆角
                      ),
                      focusedBorder: const UnderlineInputBorder(
                        borderSide: BorderSide(color: MyColor.orange, width: 5),
                        borderRadius: BorderRadius.all(Radius.circular(8.0)), // 设置边框的圆角
                      ),
                      prefixIcon: Icon(Icons.person),
                    ),
                    // 校验用户名（不能为空）
                    validator: (v) {
                      return v==null||v.trim().isNotEmpty ? null : "userNameRequired";
                    }),
                TextFormField(
                    autofocus: _nameAutoFocus,
                    controller: _nickNameController,
                    decoration: InputDecoration(
                      labelText: "nickName",
                      hintText: "nickName",
                      labelStyle: const TextStyle(
                        color: MyColor.orange,  // Set the color for the label text here
                      ),
                      enabledBorder: const UnderlineInputBorder(
                        borderSide: BorderSide(color: MyColor.orange, width: 2),
                        borderRadius: BorderRadius.all(Radius.circular(8.0)), // 设置边框的圆角
                      ),
                      focusedBorder: const UnderlineInputBorder(
                        borderSide: BorderSide(color: MyColor.orange, width: 5),
                        borderRadius: BorderRadius.all(Radius.circular(8.0)), // 设置边框的圆角
                      ),
                      prefixIcon: Icon(Icons.person),
                    ),
                    // 校验用户名（不能为空）
                    validator: (v) {
                      return v==null||v.trim().isNotEmpty ? null : "nickName Required";
                    }),
                TextFormField(
                  controller: _pwdController,
                  autofocus: !_nameAutoFocus,
                  decoration: InputDecoration(
                      labelText: "password",
                      hintText: "password",
                      labelStyle: const TextStyle(
                        color: MyColor.orange,  // Set the color for the label text here
                      ),
                      enabledBorder: const UnderlineInputBorder(
                        borderSide: BorderSide(color: MyColor.orange, width: 2),
                        borderRadius: BorderRadius.all(Radius.circular(8.0)), // 设置边框的圆角
                      ),
                      focusedBorder: const UnderlineInputBorder(
                        borderSide: BorderSide(color: MyColor.orange, width: 5),
                        borderRadius: BorderRadius.all(Radius.circular(8.0)), // 设置边框的圆角
                      ),
                      prefixIcon: Icon(Icons.lock),
                      suffixIcon: IconButton(
                        icon: Icon(
                            pwdShow ? Icons.visibility_off : Icons.visibility),
                        onPressed: () {
                          setState(() {
                            pwdShow = !pwdShow;
                          });
                        },
                      )),
                  obscureText: !pwdShow,
                  //校验密码（不能为空）
                  validator: (v) {
                    return v==null||v.trim().isNotEmpty ? null : "passwordRequired";
                  },
                ),

                TextFormField(
                  controller: _pwd2Controller,
                  autofocus: !_nameAutoFocus,
                  decoration: InputDecoration(
                      labelText: "confirm password",
                      hintText: "confirm password",
                      labelStyle: const TextStyle(
                        color: MyColor.orange,  // Set the color for the label text here
                      ),
                      enabledBorder: const UnderlineInputBorder(
                        borderSide: BorderSide(color: MyColor.orange, width: 2),
                        borderRadius: BorderRadius.all(Radius.circular(8.0)), // 设置边框的圆角
                      ),
                      focusedBorder: const UnderlineInputBorder(
                        borderSide: BorderSide(color: MyColor.orange, width: 5),
                        borderRadius: BorderRadius.all(Radius.circular(8.0)), // 设置边框的圆角
                      ),
                      prefixIcon: Icon(Icons.lock),
                      suffixIcon: IconButton(
                        icon: Icon(
                            pwdShow ? Icons.visibility_off : Icons.visibility),
                        onPressed: () {
                          setState(() {
                            pwdShow = !pwdShow;
                          });
                        },
                      )),
                  obscureText: !pwdShow,
                  //校验密码（不能为空）
                  validator: (v) {
                    return v==null||v.trim().isNotEmpty ? null : "confirm password Required";
                  },
                ),

                Padding(
                  padding: const EdgeInsets.only(top: 25),
                  child: ConstrainedBox(
                    constraints: BoxConstraints.expand(height: 55.0),
                    child: ElevatedButton(
                      style: ButtonStyle(
                        backgroundColor: MaterialStateProperty.all<Color>(MyColor.orange),
                        // foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                      ),
                      // color: Theme.of(context).primaryColor,
                      onPressed: _onSignUp,
                      // textColor: Colors.white,
                      child: Text("sign up"),
                    ),
                  ),
                ),
              ],
            ),
          ),
        )
      ),
    );
  }

  void _onSignUp() async {
    if ((_formKey.currentState as FormState).validate()) {
      try {
        Map<String, String> SignUpInfo = {"telephone":_phoneNumController.text,
          "username":_unameController.text, "nickname":_nickNameController.text,
          "password1":_pwdController.text, "password2":_pwd2Controller.text,
        };
        DioUtil.signUp(SignUpInfo).then((value){
          if(value.resultStatus==200){
            Navigator.of(context).pop();
          }else if(value.resultStatus==201){
            showAlert(context, "密码不匹配");
          }else if(value.resultStatus==202){
            showAlert(context, "该手机号码被注册，请更换手机");
          }else if(value.resultStatus==203){
            showAlert(context, "该用户名已被使用");
          }
          setState(() {

          });
        });
      } on DioError catch( e) {
      } finally {
      }
    }


    // Navigator.of(context).push(
    //   MaterialPageRoute(
    //     // builder: (context) => CatCardPage2(systemStr: textEditingController.text.isEmpty?system:textEditingController.text,),
    //     builder: (context) => LoginRoute(),
    //   ),
    // );
  }

  void showAlert(scaffoldContext, String alertInfo){
    showDialog(
      context: scaffoldContext,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Warning',
            style: TextStyle(
                color: Colors.red),),
          content: Text(alertInfo),
          actions: <Widget>[
            TextButton(
              child: Text('Closed'),
              onPressed: () {
                Navigator.of(context).pop(); // 关闭对话框
              },
            ),
          ],
        );
      },
    );
  }
}
import 'dart:ui';

import 'package:flutter/material.dart';

class MyColor {
  static const Color lightWhite = Color(0xFFEEEEEE);
  static const Color deepBlue = Color(0xFF002266);
  static const Color orange = Color(0xFFef7c00);
  static const Color grey = Colors.white38;
  static const Color pureWhite = Color(0xFFFFFFFF);
  static const Color lighterDeepBlue = Color(0xFF3B5790);
}


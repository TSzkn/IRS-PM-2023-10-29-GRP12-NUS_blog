// import 'package:chat_gpt_sdk/chat_gpt_sdk.dart';
// import 'package:dio/dio.dart';
// final dio = Dio()..interceptors.add(LogInterceptor(
//   requestBody: true,
//   requestHeader: true,
//   responseBody: true,
// ));
// ///open api key 放这里
// // final openAI = OpenAI.instance.build(token: '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',
// //     baseOption: HttpSetup(receiveTimeout: const Duration(seconds: 30),
// //         sendTimeout: const Duration(seconds: 30),
// //         connectTimeout:const Duration(seconds: 30) ));
//
// // final openAI = OpenAI.instance.build(token: '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',
// //     baseOption: HttpSetup(receiveTimeout: const Duration(seconds: 20)),enableLog: true);
//
// // final openAI = OpenAI.instance.build(token: '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',
// //     baseOption: HttpSetup(receiveTimeout: const Duration(seconds: 20)),enableLog: true);
//
//
// // void embedding() async {
// //   final request = EmbedRequest(
// //       model: EmbedModel.textEmbeddingAda002,
// //       input: 'The food was delicious and the waiter');
// //
// //   final response = await openAI.embed.embedding(request);
// //
// //   print("embedding Test!!!");
// //   print(response.data.last.embedding);
// //
// //
// // }
//
//
//
// class DioUtil{
//   static Future<ResultBean> sendSingle(String text){
//     return  dio.get('http://192.168.31.171:8081/chat/send',options: Options(contentType: Headers.jsonContentType))
//         .then((value) => ResultBean(true, value.data),onError: (e)=>ResultBean(false, null));
//   }
//
//
//   ///https://api.openai.com/v1/chat/completions
//   ///open ai key here 放这里
//   static Future<ResultBean> sendMulti(List<ChatMessage> messages){
//     return  dio.post('http://192.168.31.171:8081/chat/multi/send',
//         options: Options(contentType: Headers.jsonContentType,headers: {
//           'Authorization':'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'
//         }),
//         data: messages)
//         .then((value) => ResultBean(true, value.data),onError: (e)=>ResultBean(false, null));
//   }
//
//
//   ///login
//   static Future<ResultStatusBean> login(Map<String, String> messages){
//     return  dio.post('http://127.0.0.1:5000/login/',
//         options: Options(contentType: Headers.jsonContentType,),
//         data: messages)
//         .then((value){
//       print("returned!!!");
//       print(value.data);
//       return ResultStatusBean(200, value.data);
//     },onError: (e)=>ResultStatusBean(600, null));
//   }
//
//   ///signUp
//   static Future<ResultStatusBean> signUp(Map<String, String> messages){
//     return  dio.post('http://127.0.0.1:5000/regist/',
//         options: Options(contentType: Headers.jsonContentType,),
//         data: messages)
//         .then((value){
//       print("returned!!!");
//       print(value.data);
//       return ResultStatusBean(200, value.data);
//     },onError: (e)=>ResultStatusBean(600, null));
//   }
//
//
//   static Future<ResultBean> getGroupInfo(int groupId){
//     return  dio.get('http://127.0.0.1:5000/group?groupid=$groupId',
//       options: Options(contentType: Headers.jsonContentType,),)
//         .then((value){
//       return ResultBean(true, value.data);
//     },onError: (e)=>ResultBean(false, null));
//   }
//
// ///发送blog
//   static Future<ResultStatusBean> sendBlog(Map<String, dynamic> blog){
//     return  dio.post('http://127.0.0.1:5000/hsadd/',
//         options: Options(contentType: Headers.jsonContentType,),
//         data: blog)
//         .then((value){
//       print("returned!!!");
//       print(value.data);
//       return ResultStatusBean(200, value.data);
//     },onError: (e)=>ResultStatusBean(600, null));
//   }
//
//   ///get blog details
//   static Future<ResultStatusBean> getBlogDetails(Map<String, dynamic> blog){
//     return  dio.post('http://127.0.0.1:5000/hsdetail/',
//         options: Options(contentType: Headers.jsonContentType,),
//         data: blog)
//         .then((value){
//       print("returned!!!");
//       print(value.data);
//       return ResultStatusBean(200, value.data);
//     },onError: (e)=>ResultStatusBean(600, null));
//   }
//
//   ///获得recommend list
//   static Future<ResultStatusBean> getRecommendationList(Map<String, dynamic> blog){
//     return  dio.post('http://127.0.0.1:5000/hsrecommend',
//         options: Options(contentType: Headers.jsonContentType,),
//         data: blog)
//         .then((value){
//       print("returned!!!");
//       print(value.data);
//       return ResultStatusBean(200, value.data);
//     },onError: (e)=>ResultStatusBean(600, null));
//   }
//
//   ///获得HotSearch List
//   static Future<ResultStatusBean> getHotSearchList(Map<String, dynamic> blog){
//     return  dio.post('http://127.0.0.1:5000/hslist',
//         options: Options(contentType: Headers.jsonContentType,),
//         data: blog)
//         .then((value){
//       print("returned!!!");
//       print(value.data);
//       return ResultStatusBean(200, value.data);
//     },onError: (e)=>ResultStatusBean(600, null));
//   }
//
//   ///获得recommend list
//   static Future<ResultStatusBean> getLatestList(Map<String, dynamic> blog){
//     return  dio.post('http://127.0.0.1:5000/hsadd/',
//         options: Options(contentType: Headers.jsonContentType,),
//         data: blog)
//         .then((value){
//       print("returned!!!");
//       print(value.data);
//       return ResultStatusBean(200, value.data);
//     },onError: (e)=>ResultStatusBean(600, null));
//   }
//
//
//
//   // content = request.json.get('blog')
//   // userid = request.json.get('userid')
//   // abstarct = request.json.get('abstract')
//   // title = request.json.get('title')
//
//   // http://127.0.0.1:5000/group?groupid=1
//
//   ///open ai key here
//   static Future<ResultBean> sendMultiLocalProxy(List<ChatMessage> messages){
//     return  dio.post('https://api.openai.com/v1/chat/completions',
//         options: Options(contentType: Headers.jsonContentType,headers: {
//           'Authorization':'Bearer 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'
//         }),
//         data: messages)
//         .then((value){
//       return ResultBean(true, value.data);
//     },onError: (e)=>ResultBean(false, null));
//   }
// }
//
// class ResultStatusBean{
//   int resultStatus=500;
//   // int status;
//   dynamic data;
//   ResultStatusBean(this.resultStatus,this.data){
//     if(data['status']==200){
//       this.resultStatus=200;
//     }
//     else if(data['status']==201){
//       this.resultStatus=201;
//     }
//     else if(data['status']==202){
//       this.resultStatus=202;
//     }
//     this.data=data!=null?data['data']:null;
//   }
// }
//
//
// // class groupInfoBean{
// //
// // }
//
// class ResultBean{
//   bool isSuccess=false;
//   // int status;
//   dynamic data;
//   ResultBean(this.isSuccess,this.data){
//     this.isSuccess = data!=null&&data['status']==200;
//     this.data=data!=null?data['data']:null;
//   }
// }
//
// class SystemMessage {
//   SystemMessageType? type;
//   String? content;
//   SystemMessage.narrator(this.content){
//     type=SystemMessageType.narrator;
//     content=content;
//   }
//   SystemMessage.GPTNarrator(this.content){
//     type=SystemMessageType.GPTNarrator;
//     content=content;
//   }
//   SystemMessage.UserText(this.content){
//     type=SystemMessageType.UserText;
//     content=content;
//   }
//   SystemMessage.GPTResponse(this.content){
//     type=SystemMessageType.GPTResponse;
//     content=content;
//   }
//   SystemMessage({this.type, this.content});
//
// }
// enum SystemMessageType{
//   narrator, GPTResponse, UserText, GPTNarrator,
// }
//
//
// class SpecialPrompts {
//   List<String> triggerList;
//   String prompt;
//   // SpecialPrompts(this.triggerList, this.prompt){
//   //   triggerList = triggerList;
//   //   prompt = prompt;
//   // }
//   //
//
//   SpecialPrompts({required this.triggerList, required this.prompt});
//
// }
//
//
//
//
// // Map MessageName={
// //   "assistant":"猫娘",
// //   "system":"提示",
// //   "user":"段誉",
// //   "tip":"提示",
// // };
//
//
//
// class ChatMessage {
//   String? role;
//   String? content;
//   ChatMessage.assistant(this.content){
//     role='assistant';
//     content=content;
//   }
//   ChatMessage.system(this.content){
//     role='system';
//     content=content;
//   }
//   ChatMessage.user(this.content){
//     role='user';
//     content=content;
//   }
//   ChatMessage.tips(this.content){
//     role='tip';
//     content=content;
//   }
//   ChatMessage.command(this.content){
//     role='user';
//     content=content;
//   }
//   ChatMessage({this.role, this.content});
//
//   ChatMessage.fromJson(Map<String, dynamic> json) {
//     role = json['role'];
//     content = json['content'];
//   }
//
//   Map<String, String> toJson() {
//     final Map<String, String> data = new Map<String, String>();
//     data['role'] = this.role!;
//     data['content'] = this.content!;
//     return data;
//   }
// }
// Map mapName={
//   "assistant":"猫娘",
//   "system":"提示",
//   "user":"段誉",
//   "tip":"提示",
// };
// class GPTResponse {
//   String? id;
//   String? object;
//   int? created;
//   String? model;
//   Usage? usage;
//   List<Choices>? choices;
//
//   GPTResponse(
//       {this.id,
//         this.object,
//         this.created,
//         this.model,
//         this.usage,
//         this.choices});
//
//   GPTResponse.fromJson(Map<String, dynamic> json) {
//     id = json['id'];
//     object = json['object'];
//     created = json['created'];
//     model = json['model'];
//     usage = json['usage'] != null ? new Usage.fromJson(json['usage']) : null;
//     if (json['choices'] != null) {
//       choices = <Choices>[];
//       json['choices'].forEach((v) {
//         choices!.add(new Choices.fromJson(v));
//       });
//     }
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['id'] = this.id;
//     data['object'] = this.object;
//     data['created'] = this.created;
//     data['model'] = this.model;
//     if (this.usage != null) {
//       data['usage'] = this.usage!.toJson();
//     }
//     if (this.choices != null) {
//       data['choices'] = this.choices!.map((v) => v.toJson()).toList();
//     }
//     return data;
//   }
// }
//
// class Usage {
//   int? promptTokens;
//   int? completionTokens;
//   int? totalTokens;
//
//   Usage({this.promptTokens, this.completionTokens, this.totalTokens});
//
//   Usage.fromJson(Map<String, dynamic> json) {
//     promptTokens = json['prompt_tokens'];
//     completionTokens = json['completion_tokens'];
//     totalTokens = json['total_tokens'];
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['prompt_tokens'] = this.promptTokens;
//     data['completion_tokens'] = this.completionTokens;
//     data['total_tokens'] = this.totalTokens;
//     return data;
//   }
// }
//
// class Choices {
//   Message? message;
//   String? finishReason;
//   int? index;
//
//   Choices({this.message, this.finishReason, this.index});
//
//   Choices.fromJson(Map<String, dynamic> json) {
//     message =
//     json['message'] != null ? new Message.fromJson(json['message']) : null;
//     finishReason = json['finish_reason'];
//     index = json['index'];
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     if (this.message != null) {
//       data['message'] = this.message!.toJson();
//     }
//     data['finish_reason'] = this.finishReason;
//     data['index'] = this.index;
//     return data;
//   }
// }
//
// class Message {
//   String? role;
//   String? content;
//
//   Message({this.role, this.content});
//
//   Message.fromJson(Map<String, dynamic> json) {
//     role = json['role'];
//     content = json['content'];
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['role'] = this.role;
//     data['content'] = this.content;
//     return data;
//   }
// }
// class CharacterInfo {
//   int? friendshipValue;
//   int? loveValue;
//   int? intimacyValue;
//
//   CharacterInfo({this.friendshipValue, this.loveValue, this.intimacyValue});
//
//   CharacterInfo.fromJson(Map<String, dynamic> json) {
//     friendshipValue = json['friendshipValue'];
//     loveValue = json['loveValue'];
//     intimacyValue = json['shynessValue'];
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['friendshipValue'] = this.friendshipValue;
//     data['loveValue'] = this.loveValue;
//     data['shynessValue'] = this.intimacyValue;
//     return data;
//   }
// }
//
// class charConfig {
//   List<Vectors>? vectors;
//
//   charConfig({this.vectors});
//
//   charConfig.fromJson(Map<String, dynamic> json) {
//     if (json['vectors'] != null) {
//       vectors = <Vectors>[];
//       json['vectors'].forEach((v) {
//         vectors!.add(new Vectors.fromJson(v));
//       });
//     }
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     if (this.vectors != null) {
//       data['vectors'] = this.vectors!.map((v) => v.toJson()).toList();
//     }
//     return data;
//   }
// }
//
// class Vectors {
//   String? id;
//   Metadata? metadata;
//   List<double>? values;
//
//   Vectors({this.id, this.metadata, this.values});
//
//   Vectors.fromJson(Map<String, dynamic> json) {
//     id = json['id'];
//     metadata = json['metadata'] != null
//         ? new Metadata.fromJson(json['metadata'])
//         : null;
//     values = json['values'].cast<double>();
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['id'] = this.id;
//     if (this.metadata != null) {
//       data['metadata'] = this.metadata!.toJson();
//     }
//     data['values'] = this.values;
//     return data;
//   }
// }
//
// class Metadata {
//   String? line;
//
//   Metadata({this.line});
//
//   Metadata.fromJson(Map<String, dynamic> json) {
//     line = json['line'];
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['line'] = this.line;
//     return data;
//   }
// }

import 'package:chat_gpt_sdk/chat_gpt_sdk.dart';
import 'package:dio/dio.dart';
final dio = Dio()..interceptors.add(LogInterceptor(
  requestBody: true,
  requestHeader: true,
  responseBody: true,
));

class DioUtil{
  ///login
  static Future<ResultStatusBean> login(Map<String, String> messages){
    return  dio.post('http://192.168.40.156:9000/login/',
        options: Options(contentType: Headers.jsonContentType,),
        data: messages)
        .then((value){
      print("returned!!!");
      print(value.data);
      return ResultStatusBean(200, value.data);
    },onError: (e)=>ResultStatusBean(600, null));
  }

  ///signUp
  static Future<ResultStatusBean> signUp(Map<String, String> messages){
    return  dio.post('http://192.168.40.156:9000/regist/',
        options: Options(contentType: Headers.jsonContentType,),
        data: messages)
        .then((value){
      print("returned!!!");
      print(value.data);
      return ResultStatusBean(200, value.data);
    },onError: (e)=>ResultStatusBean(600, null));
  }

  static Future<ResultStatusBean> getGroupList(Map<String, dynamic> info){
    return  dio.get('http://192.168.40.156:9000/gplist/?userid=${info["id"]}',
        options: Options(contentType: Headers.jsonContentType,),
        data: info)
        .then((value){
      return ResultStatusBean(200, value.data);
    },onError: (e)=>ResultStatusBean(600, null));
  }

  static Future<ResultStatusBean> createGroup(Map<String, dynamic> info){
    return  dio.post('http://192.168.40.156:9000/usercreate/',
        options: Options(contentType: Headers.jsonContentType,),
        data: info)
        .then((value){
      return ResultStatusBean(200, value.data);
    },onError: (e)=>ResultStatusBean(600, null));
  }

  static Future<ResultStatusBean> getGroupInfo(int groupId){
    return  dio.get('http://192.168.40.156:9000/group?groupid=$groupId',
      options: Options(contentType: Headers.jsonContentType,),)
        .then((value){
      return ResultStatusBean(200, value.data);
    },onError: (e)=>ResultStatusBean(600, null));
  }

  static Future<ResultStatusBean> addToGroup(Map<String, dynamic> info){
    return  dio.post('http://192.168.40.156:9000/uaddgroup/',
      options: Options(contentType: Headers.jsonContentType,),
    data: info)
        .then((value){
      return ResultStatusBean(200, value.data);
    },onError: (e)=>ResultStatusBean(600, null));
  }

  ///发送blog
  static Future<ResultStatusBean> sendBlog(Map<String, dynamic> blog){
    return  dio.post('http://192.168.40.156:9000/hsadd/',
        options: Options(contentType: Headers.jsonContentType,),
        data: blog)
        .then((value){
      print("returned!!!");
      print(value.data);
      return ResultStatusBean(200, value.data);
    },onError: (e)=>ResultStatusBean(600, null));
  }


  ///发送message
  static Future<ResultStatusBean> getBackgroundInfo(Map<String, dynamic> message){
    return  dio.post('http://192.168.40.156:9000/chatapi/',
        options: Options(contentType: Headers.jsonContentType,),
        data: message)
        .then((value){
      print("returned!!!");
      print(value.data);
      return ResultStatusBean(200, value.data);
    },onError: (e)=>ResultStatusBean(600, null));
  }

  ///get blog details
  static Future<ResultStatusBean> getBlogDetails(Map<String, dynamic> blog){
    return  dio.post('http://192.168.40.156:9000/hsdetail/',
        options: Options(contentType: Headers.jsonContentType,),
        data: blog)
        .then((value){
      print("returned!!!");
      print(value.data);
      return ResultStatusBean(200, value.data);
    },onError: (e)=>ResultStatusBean(600, null));
  }

  ///获得recommend list
  static Future<ListResultStatusBean> getRecommendationList(Map<String, dynamic> blog){
    return  dio.get('http://192.168.40.156:9000/hsrecommend?userid=${blog["userid"]}',
        options: Options(contentType: Headers.jsonContentType,),
        data: blog)
        .then((value){
      print("returned!!!");
      print(value.data);
      return ListResultStatusBean(200, value.data, value.data['has_more']);
    },onError: (e)=>ListResultStatusBean(600, null, false));
  }

  ///获得HotSearch List
  static Future<ListResultStatusBean> getHotSearchList(Map<String, dynamic> blog){
    return  dio.get('http://192.168.40.156:9000/hslist?userid=${blog["userid"]}',
        options: Options(contentType: Headers.jsonContentType,),
        data: blog)
        .then((value){
      print("returned!!!");
      print(value.data);
      return ListResultStatusBean(200, value.data, value.data['has_more']);
    },onError: (e)=>ListResultStatusBean(600, null, false));
  }

  ///获得recommend list
  static Future<ListResultStatusBean> getLatestList(Map<String, dynamic> blog){
    return  dio.post('http://192.168.40.156:9000/hslatest?userid=${blog["userid"]}/',
        options: Options(contentType: Headers.jsonContentType,),
        data: blog)
        .then((value){
      print("returned!!!");
      print(value.data);
      return ListResultStatusBean(200, value.data, value.data['has_more']);
    },onError: (e)=>ListResultStatusBean(600, null, false));
  }



  // content = request.json.get('blog')
  // userid = request.json.get('userid')
  // abstarct = request.json.get('abstract')
  // title = request.json.get('title')

  // http://127.0.0.1:5000/group?groupid=1

  ///open ai key here
  static Future<ResultBean> sendMultiLocalProxy(List<ChatMessage> messages){
    return  dio.post('https://api.openai.com/v1/chat/completions',
        options: Options(contentType: Headers.jsonContentType,headers: {
          'Authorization':'Bearer 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'
        }),
        data: messages)
        .then((value){
      return ResultBean(true, value.data);
    },onError: (e)=>ResultBean(false, null));
  }
}

class ResultStatusBean{
  int resultStatus=500;
  // int status;
  dynamic data;
  ResultStatusBean(this.resultStatus,this.data){
    if(data['status']==200){
      this.resultStatus=200;
    }
    else if(data['status']==201){
      this.resultStatus=201;
    }
    else if(data['status']==202){
      this.resultStatus=202;
    }
    this.data=data!=null?data['data']:null;
  }
}

class ListResultStatusBean{
  int resultStatus=500;
  // int status;
  dynamic data;
  bool hasMore=false;
  ListResultStatusBean(this.resultStatus,this.data, this.hasMore){
    if(data['status']==200){
      this.resultStatus=200;
    }
    else if(data['status']==201){
      this.resultStatus=201;
    }
    else if(data['status']==202){
      this.resultStatus=202;
    }
    this.hasMore=data!=null?data['data']['has_more']:false;
    this.data=data!=null?data['data']:null;
  }
}


// class groupInfoBean{
//
// }

class ResultBean{
  bool isSuccess=false;
  // int status;
  dynamic data;
  ResultBean(this.isSuccess,this.data){
    this.isSuccess = data!=null&&data['status']==200;
    this.data=data!=null?data['data']:null;
  }
}

class SystemMessage {
  SystemMessageType? type;
  String? content;
  int? referenceNumber = 0;
  SystemMessage.narrator(this.content, [this.referenceNumber = 0]){
    type=SystemMessageType.narrator;
    content=content;
    referenceNumber = referenceNumber;
  }
  SystemMessage.GPTNarrator(this.content, [this.referenceNumber = 0]){
    type=SystemMessageType.GPTNarrator;
    content=content;
    referenceNumber = referenceNumber;
  }
  SystemMessage.UserText(this.content, [this.referenceNumber = 0]){
    type=SystemMessageType.UserText;
    referenceNumber = referenceNumber;
    content=content;
  }
  SystemMessage.GPTResponse(this.content, [this.referenceNumber = 0]){
    type=SystemMessageType.GPTResponse;
    referenceNumber = referenceNumber;
    content=content;
  }
  SystemMessage({this.type, this.content, this.referenceNumber = 0});

}
enum SystemMessageType{
  narrator, GPTResponse, UserText, GPTNarrator,
}


class SpecialPrompts {
  List<String> triggerList;
  String prompt;
  // SpecialPrompts(this.triggerList, this.prompt){
  //   triggerList = triggerList;
  //   prompt = prompt;
  // }
  //

  SpecialPrompts({required this.triggerList, required this.prompt});

}




// Map MessageName={
//   "assistant":"猫娘",
//   "system":"提示",
//   "user":"段誉",
//   "tip":"提示",
// };



class ChatMessage {
  String? role;
  String? content;
  ChatMessage.assistant(this.content){
    role='assistant';
    content=content;
  }
  ChatMessage.system(this.content){
    role='system';
    content=content;
  }
  ChatMessage.user(this.content){
    role='user';
    content=content;
  }
  ChatMessage.tips(this.content){
    role='tip';
    content=content;
  }
  ChatMessage.command(this.content){
    role='user';
    content=content;
  }
  ChatMessage({this.role, this.content});

  ChatMessage.fromJson(Map<String, dynamic> json) {
    role = json['role'];
    content = json['content'];
  }

  Map<String, String> toJson() {
    final Map<String, String> data = new Map<String, String>();
    data['role'] = this.role!;
    data['content'] = this.content!;
    return data;
  }
}

class GPTResponse {
  String? id;
  String? object;
  int? created;
  String? model;
  Usage? usage;
  List<Choices>? choices;

  GPTResponse(
      {this.id,
        this.object,
        this.created,
        this.model,
        this.usage,
        this.choices});

  GPTResponse.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    object = json['object'];
    created = json['created'];
    model = json['model'];
    usage = json['usage'] != null ? new Usage.fromJson(json['usage']) : null;
    if (json['choices'] != null) {
      choices = <Choices>[];
      json['choices'].forEach((v) {
        choices!.add(new Choices.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['object'] = this.object;
    data['created'] = this.created;
    data['model'] = this.model;
    if (this.usage != null) {
      data['usage'] = this.usage!.toJson();
    }
    if (this.choices != null) {
      data['choices'] = this.choices!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Usage {
  int? promptTokens;
  int? completionTokens;
  int? totalTokens;

  Usage({this.promptTokens, this.completionTokens, this.totalTokens});

  Usage.fromJson(Map<String, dynamic> json) {
    promptTokens = json['prompt_tokens'];
    completionTokens = json['completion_tokens'];
    totalTokens = json['total_tokens'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['prompt_tokens'] = this.promptTokens;
    data['completion_tokens'] = this.completionTokens;
    data['total_tokens'] = this.totalTokens;
    return data;
  }
}

class Choices {
  Message? message;
  String? finishReason;
  int? index;

  Choices({this.message, this.finishReason, this.index});

  Choices.fromJson(Map<String, dynamic> json) {
    message =
    json['message'] != null ? new Message.fromJson(json['message']) : null;
    finishReason = json['finish_reason'];
    index = json['index'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.message != null) {
      data['message'] = this.message!.toJson();
    }
    data['finish_reason'] = this.finishReason;
    data['index'] = this.index;
    return data;
  }
}

class Message {
  String? role;
  String? content;

  Message({this.role, this.content});

  Message.fromJson(Map<String, dynamic> json) {
    role = json['role'];
    content = json['content'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['role'] = this.role;
    data['content'] = this.content;
    return data;
  }
}

//
// class CharacterInfo {
//   int? friendshipValue;
//   int? loveValue;
//   int? intimacyValue;
//
//   CharacterInfo({this.friendshipValue, this.loveValue, this.intimacyValue});
//
//   CharacterInfo.fromJson(Map<String, dynamic> json) {
//     friendshipValue = json['friendshipValue'];
//     loveValue = json['loveValue'];
//     intimacyValue = json['shynessValue'];
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['friendshipValue'] = this.friendshipValue;
//     data['loveValue'] = this.loveValue;
//     data['shynessValue'] = this.intimacyValue;
//     return data;
//   }
// }
//
// class charConfig {
//   List<Vectors>? vectors;
//
//   charConfig({this.vectors});
//
//   charConfig.fromJson(Map<String, dynamic> json) {
//     if (json['vectors'] != null) {
//       vectors = <Vectors>[];
//       json['vectors'].forEach((v) {
//         vectors!.add(new Vectors.fromJson(v));
//       });
//     }
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     if (this.vectors != null) {
//       data['vectors'] = this.vectors!.map((v) => v.toJson()).toList();
//     }
//     return data;
//   }
// }

class Vectors {
  String? id;
  Metadata? metadata;
  List<double>? values;

  Vectors({this.id, this.metadata, this.values});

  Vectors.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    metadata = json['metadata'] != null
        ? new Metadata.fromJson(json['metadata'])
        : null;
    values = json['values'].cast<double>();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    if (this.metadata != null) {
      data['metadata'] = this.metadata!.toJson();
    }
    data['values'] = this.values;
    return data;
  }
}

class Metadata {
  String? line;

  Metadata({this.line});

  Metadata.fromJson(Map<String, dynamic> json) {
    line = json['line'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['line'] = this.line;
    return data;
  }
}
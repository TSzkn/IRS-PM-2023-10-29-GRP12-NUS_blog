// // import 'dart:convert';
// // import 'dart:typed_data';
// //
// // import 'package:chatgpt/pages/--.dart';
// // import 'package:chatgpt/pages/chatbot_page.dart';
// // import 'package:chatgpt/utils/datas.dart';
// // import 'package:flutter/material.dart';
// // // import 'package:flutter_sound/public/flutter_sound_recorder.dart';
// // import 'package:http/http.dart' as http;
// // import 'package:microphone/microphone.dart';
// // import 'package:permission_handler/permission_handler.dart';
// //
// // class StartPlayPage extends StatefulWidget {
// //   const StartPlayPage({Key? key}) : super(key: key);
// //
// //   @override
// //   State<StartPlayPage> createState() => _StartPlayPageState();
// // }
// //
// // class _StartPlayPageState extends State<StartPlayPage> {
// //   TextEditingController textEditingController=TextEditingController();
// //   late String systemSetting2 = "lol";
// //   late bool showLoading = false;
// //   late Uint8List recording;
// //
// //
// //   final _transcriptionController = TextEditingController();
// // // Recording variables
// //   FlutterSoundRecorder? _recorder;
// //   bool isRecording = false;
// //
// //   // FlutterSoundRecorder _recordingSession;
// //   // final recordingPlayer = AssetsAudioPlayer();
// //   // String pathToAudio;
// //   // bool _playAudio = false;
// //   // String _timerText = '00:00:00';
// //
// //
// //
// //
// //   Future _startRecording() async {
// //
// //     print("!!!recording true");
// //     _recorder = FlutterSoundRecorder();
// //     await _recorder!.openAudioSession();
// //
// //     isRecording = true;
// //     setState(() {
// //
// //     });
// //     await _recorder!.startRecorder();
// //     print("finish starting!!!");
// //   }
// //
// //   Future _stopRecording() async {
// //     await _recorder!.stopRecorder();
// //
// //     _recorder!.closeAudioSession();
// //
// //     isRecording = false;
// //     print("!!!recording false");
// //   }
// //
// //   Future _transcribeAudio() async {
// //     // Encode audio to base64
// //     String audio64 = base64Encode(recording);
// //
// //     // Call Whisper API
// //     var url = Uri.parse("https://api.openai.com/v1/audio/transcriptions");
// //
// //     var response = await http.post(url, headers: {
// //       "Authorization": "Bearer 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"
// //     }, body: {
// //       "audio": audio64,
// //       "model": "whisper-1"
// //     });
// //
// //     // Get transcription and update text field
// //     var transcription = jsonDecode(response.body)['text'];
// //     _transcriptionController.text = transcription;
// //     setState(() {
// //
// //     });
// //   }
// //
// //   void initState() {
// //     super.initState();
// //     initializer();
// //   }
// //   void initializer() async {
// //     print("!!!init");
// //     // pathToAudio = '/sdcard/Download/temp.wav';
// //     // _recordingSession = FlutterSoundRecorder();
// //     // await _recordingSession.openAudioSession(
// //     //     focus: AudioFocus.requestFocusAndStopOthers,
// //     //     category: SessionCategory.playAndRecord,
// //     //     mode: SessionMode.modeDefault,
// //     //     device: AudioDevice.speaker);
// //     // await _recordingSession.setSubscriptionDuration(Duration(milliseconds: 10));
// //     // await initializeDateFormatting();
// //     await Permission.microphone.request();
// //     await Permission.storage.request();
// //     await Permission.manageExternalStorage.request();
// //   }
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       body: Padding(
// //         padding: const EdgeInsets.all(8.0),
// //         child: Column(
// //           mainAxisAlignment: MainAxisAlignment.center,
// //           children: [
// //             IconButton(
// //               onPressed: () async {
// //                 if (!isRecording) {
// //                   await _startRecording();
// //                 } else {
// //                   print("!!!activate false");
// //                   await _stopRecording();
// //                   await _transcribeAudio();
// //                 }
// //               },
// //               icon: isRecording ? Icon(Icons.stop) : Icon(Icons.add),
// //             ),
// //             TextField(
// //               maxLines: null,
// //               controller: textEditingController,
// //               decoration: InputDecoration(
// //                   hintText: _transcriptionController.text
// //               ),
// //             )
// //           ],
// //         ),
// //       ),
// //       floatingActionButton: IconButton(onPressed: _next, icon: Icon(Icons.forward)),
// //     );
// //   }
// //
// //   void _next() {
// //     Navigator.of(context).push(
// //       MaterialPageRoute(
// //         builder: (context) => CatCardPage2(systemStr: textEditingController.text.isEmpty?system:textEditingController.text,),
// //       ),
// //     );
// //   }
// // }
//
//
// import 'dart:convert';
// import 'dart:typed_data';
//
// import 'package:avatar_glow/avatar_glow.dart';
// import 'package:chat_gpt_sdk/chat_gpt_sdk.dart';
// import 'package:chatgpt/pages/--.dart';
// import 'package:chatgpt/pages/chatbot_page.dart';
// import 'package:chatgpt/pages/main_page_controller.dart';
// import 'package:chatgpt/utils/datas.dart';
// import 'package:flutter/material.dart';
// import 'package:highlight_text/highlight_text.dart';
// // import 'package:flutter_sound/public/flutter_sound_recorder.dart';
// import 'package:http/http.dart' as http;
// import 'package:permission_handler/permission_handler.dart';
// import 'package:speech_to_text/speech_to_text.dart' as stt;
//
// import '../utils/dio_util.dart';
//
// class StartPage extends StatefulWidget {
//   const StartPage({Key? key}) : super(key: key);
//
//   @override
//   State<StartPage> createState() => _StartPageState();
// }
//
// class _StartPageState extends State<StartPage> {
//   TextEditingController textEditingController = TextEditingController();
//
//   // final Map<String, HighlightedWord> _highlights = {
//   //   'hello': HighlightedWord(
//   //     onTap: () {
//   //       print("hello");
//   //     },
//   //     textStyle: const TextStyle(
//   //       color: Colors.blue,
//   //       fontWeight: FontWeight.bold,
//   //     ),
//   //   ),
//   //
//   //   'goodbye': HighlightedWord(
//   //     onTap: () {
//   //       print("goodbye");
//   //     },
//   //     textStyle: const TextStyle(
//   //       color: Colors.blue,
//   //       fontWeight: FontWeight.bold,
//   //     ),
//   //   ),
//   // };
//
//   late stt.SpeechToText _speech;
//   bool _isListening = false;
//   String _text = 'Press the hello and start speaking';
//   double _confidence = 1.0;
//
//   @override
//   void initState() {
//     super.initState();
//     _speech = stt.SpeechToText();
//   }
//
//   late bool showLoading = false;
//   late Uint8List recording;
//
//   final _transcriptionController = TextEditingController();
//
// // Recording variables
//   bool isRecording = false;
//
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//         floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
//         floatingActionButton: AvatarGlow(
//           animate: _isListening,
//           glowColor: Theme
//               .of(context)
//               .primaryColor,
//           endRadius: 75.0,
//           duration: const Duration(milliseconds: 2000),
//           repeatPauseDuration: const Duration(milliseconds: 100),
//           repeat: true,
//           child: FloatingActionButton(
//             onPressed: _next,
//             child: Icon(_isListening ? Icons.mic : Icons.mic_none),
//           ),
//         ),
//         body: SingleChildScrollView(
//           reverse: true,
//           child: Container(
//               padding: const EdgeInsets.fromLTRB(30.0, 30.0, 30.0, 150.0),
//               // child: TextHighlight(
//               //     text: _text,
//               //     words: _highlights,
//               //     textStyle: const TextStyle(
//               //         fontSize: 32.0,
//               //         color: Colors.black,
//               //         fontWeight: FontWeight.w400
//               //     )
//               // )
//           ),
//         )
//     );
//   }
//
// void _next() {
//   // Navigator.of(context).push(
//   //   MaterialPageRoute(
//   //     // builder: (context) => CatCardPage2(systemStr: textEditingController.text.isEmpty?system:textEditingController.text,),
//   //     builder: (context) => MyPageController(),
//   //   ),
//   // );
// }
//   // void _next() {
//   //   Navigator.of(context).push(
//   //     MaterialPageRoute(
//   //       // builder: (context) => CatCardPage2(systemStr: textEditingController.text.isEmpty?system:textEditingController.text,),
//   //       builder: (context) => MyPageController(),
//   //     ),
//   //   );
//   // }
// }
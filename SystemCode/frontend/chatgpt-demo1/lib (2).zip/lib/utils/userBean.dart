String mockUserData = '''
{
    "userID": 1,
    "userBio": "This is a bio of user 1.",
    "userNickName": "UserOne",
    "userGender": 1,
    "userGroupList": [
        {
            "groupName": "Group A",
            "groupId": 1,
            "groupDescription": "This is the description for Group A.",
            "Creator": 1001
        },
        {
            "groupName": "Group B",
            "groupId": 2,
            "groupDescription": "This is the description for Group B.",
            "Creator": 1002
        }
    ],
    "userCreatedGroup": [
        {
            "groupName": "Group C",
            "groupId": 3,
            "groupDescription": "This is the description for Group C.",
            "Creator": 1
        },
        {
            "groupName": "Group D",
            "groupId": 4,
            "groupDescription": "This is the description for Group D.",
            "Creator": 1
        }
    ],
    "userFeature": [
        {
            "featureName": "sport",
            "featureValue": "0.534",
            "relevantData1": "0.345",
            "relevantData2": "0.385"
        },
        {
            "featureName": "music",
            "featureValue": "0.734",
            "relevantData1": "0.456",
            "relevantData2": "0.586"
        }
    ],
    "userPastBlog": [
        {
            "title": "Latest Title 1",
            "blogId": 654,
            "is_news": true
        },
        {
            "title": "Latest Title 2",
            "blogId": 655,
            "is_news": false
        }
    ],
    "userChatHistory": [
        {
            "UserId": 1,
            "Role": "Admin",
            "sentTime": 1633897200,
            "content": "Hello, this is a sample message content."
        },
        {
            "UserId": 1,
            "Role": "User",
            "sentTime": 1633900800,
            "content": "This is another sample message content."
        }
    ]
}
''';



class userIdBean {
  int? id;
  userIdBean(
      {this.id,
      });
  userIdBean.fromJson(Map<String, dynamic> json) {
    id = json['id'];
  }
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['userID'] = this.id;
    return data;
  }
}






class userBean {
  int? userID;
  String? userBio;
  String? userNickName;
  int? userGender;
  List<GroupItem>? userGroupList;
  List<GroupItem>? userCreatedGroup;
  List<UserFeature>? userFeature;
  List<UserPastBlog>? userPastBlog;
  List<MessageItem>? userChatHistory;
  String? llmToken;

  userBean(
      {this.userID,
        this.userBio,
        this.userNickName,
        this.userGender,
        this.userGroupList,
        this.userCreatedGroup,
        this.userFeature,
        this.userPastBlog,
        this.userChatHistory,
        this.llmToken,
      });

  userBean.fromJson(Map<String, dynamic> json) {
    userID = json['userID'];
    userBio = json['userBio'];
    userNickName = json['userNickName'];
    userGender = json['userGender'];
    if (json['userGroupList'] != null) {
      userGroupList = <GroupItem>[];
      json['userGroupList'].forEach((v) {
        userGroupList!.add(new GroupItem.fromJson(v));
      });
    }
    if (json['userCreatedGroup'] != null) {
      userCreatedGroup = <GroupItem>[];
      json['userCreatedGroup'].forEach((v) {
        userCreatedGroup!.add(new GroupItem.fromJson(v));
      });
    }
    if (json['userFeature'] != null) {
      userFeature = <UserFeature>[];
      json['userFeature'].forEach((v) {
        userFeature!.add(new UserFeature.fromJson(v));
      });
    }
    if (json['userPastBlog'] != null) {
      userPastBlog = <UserPastBlog>[];
      json['userPastBlog'].forEach((v) {
        userPastBlog!.add(new UserPastBlog.fromJson(v));
      });
    }
    if (json['userChatHistory'] != null) {
      userChatHistory = <MessageItem>[];
      json['userChatHistory'].forEach((v) {
        userChatHistory!.add(new MessageItem.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['userID'] = this.userID;
    data['userBio'] = this.userBio;
    data['userNickName'] = this.userNickName;
    data['userGender'] = this.userGender;
    if (this.userGroupList != null) {
      data['userGroupList'] =
          this.userGroupList!.map((v) => v.toJson()).toList();
    }
    if (this.userCreatedGroup != null) {
      data['userCreatedGroup'] =
          this.userCreatedGroup!.map((v) => v.toJson()).toList();
    }
    if (this.userFeature != null) {
      data['userFeature'] = this.userFeature!.map((v) => v.toJson()).toList();
    }
    if (this.userPastBlog != null) {
      data['userPastBlog'] = this.userPastBlog!.map((v) => v.toJson()).toList();
    }
    if (this.userChatHistory != null) {
      data['userChatHistory'] =
          this.userChatHistory!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class GroupItem {
  String? groupName;
  int? groupId;
  String? groupDescription;
  int? creator;

  GroupItem(
      {this.groupName, this.groupId, this.groupDescription, this.creator});

  GroupItem.fromJson(Map<String, dynamic> json) {
    groupName = json['groupName'];
    groupId = json['groupId'];
    groupDescription = json['groupDescription'];
    creator = json['Creator'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['groupName'] = this.groupName;
    data['groupId'] = this.groupId;
    data['groupDescription'] = this.groupDescription;
    data['Creator'] = this.creator;
    return data;
  }
}

class UserFeature {
  String? featureName;
  String? featureValue;
  String? relevantData1;
  String? relevantData2;

  UserFeature(
      {this.featureName,
        this.featureValue,
        this.relevantData1,
        this.relevantData2});

  UserFeature.fromJson(Map<String, dynamic> json) {
    featureName = json['featureName'];
    featureValue = json['featureValue'];
    relevantData1 = json['relevantData1'];
    relevantData2 = json['relevantData2'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['featureName'] = this.featureName;
    data['featureValue'] = this.featureValue;
    data['relevantData1'] = this.relevantData1;
    data['relevantData2'] = this.relevantData2;
    return data;
  }
}

class UserPastBlog {
  String? title;
  int? blogId;
  bool? isNews;

  UserPastBlog({this.title, this.blogId, this.isNews});

  UserPastBlog.fromJson(Map<String, dynamic> json) {
    title = json['title'];
    blogId = json['blogId'];
    isNews = json['is_news'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['title'] = this.title;
    data['blogId'] = this.blogId;
    data['is_news'] = this.isNews;
    return data;
  }
}

class MessageItem {
  int? userId;
  String? role;
  int? sentTime;
  String? content;

  MessageItem({this.userId, this.role, this.sentTime, this.content});

  MessageItem.fromJson(Map<String, dynamic> json) {
    userId = json['UserId'];
    role = json['Role'];
    sentTime = json['sentTime'];
    content = json['content'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['UserId'] = this.userId;
    data['Role'] = this.role;
    data['sentTime'] = this.sentTime;
    data['content'] = this.content;
    return data;
  }
}
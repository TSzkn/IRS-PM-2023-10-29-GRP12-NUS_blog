import 'dart:convert';
import 'dart:typed_data';

import 'package:avatar_glow/avatar_glow.dart';
import 'package:chat_gpt_sdk/chat_gpt_sdk.dart';
import 'package:chatgpt/pages/--.dart';
import 'package:chatgpt/pages/main_page_controller.dart';
import 'package:chatgpt/utils/datas.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:highlight_text/highlight_text.dart';
// import 'package:flutter_sound/public/flutter_sound_recorder.dart';
import 'package:http/http.dart' as http;
import 'package:permission_handler/permission_handler.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

import '../utils/color_setting.dart';
import '../utils/dio_util.dart';
import '../utils/userBean.dart';

class PostSendPage extends StatefulWidget {
  const PostSendPage({Key? key, required this.userItem, required this.userDataChange}) : super(key: key);

  final Function(userBean) userDataChange;
  final userBean userItem;

  @override
  State<PostSendPage> createState() => _PostSendPageState();
}

class _PostSendPageState extends State<PostSendPage> {
  // 在顶层定义一个全局的 GlobalKey 用于访问 ScaffoldState
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  TextEditingController mainContentController = TextEditingController();
  TextEditingController titleController = TextEditingController();
  //late stt.SpeechToText _speech;

  Color buttonColor = MyColor.deepBlue;


  @override
  void initState() {
    super.initState();
   // _speech = stt.SpeechToText();
    // 添加一个监听器以侦听文本的更改
    mainContentController.addListener(() {
      setState(() {
      });
    });
  }


  late bool showLoading = false;
  late Uint8List recording;

  final _transcriptionController = TextEditingController();

// Recording variables
  bool isRecording = false;

  @override
  Widget build(BuildContext context) {
    final scaffoldContext = context;
    return Scaffold(
      floatingActionButton: IconButton( // 这里是左侧的 IconButton
        icon: Icon(Icons.arrow_back_ios_sharp),
        color: MyColor.orange,
        onPressed: () {
          // 处理返回操作
          Navigator.of(context).pop();
        },
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.miniStartTop,
      body: Stack(
        children: [



      Container(
      decoration: BoxDecoration(
      border: Border.all(
        color: Color.fromRGBO(192, 192, 192, 0.7), // 外框颜色
        width: 1.0,         // 外框宽度
      ),
      borderRadius: BorderRadius.all(Radius.circular(8.0)), // 圆角边框
    ),
         child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: <Widget>[
                SizedBox(
                  height: 100+30,
                ),
                TextField(
                  decoration: InputDecoration(
                    hintText: 'Enter your title here',
                    enabledBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: MyColor.orange, width: 2),
                      borderRadius: BorderRadius.all(Radius.circular(8.0)), // 设置边框的圆角
                    ),
                    focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: MyColor.orange, width: 5),
                      borderRadius: BorderRadius.all(Radius.circular(8.0)), // 设置边框的圆角
                    ),
                  ),
                  maxLines: 1,
                  controller: titleController,
                ),

                SizedBox(height: 30,),
                TextField(
                minLines:5,
                  decoration: const InputDecoration(
                    hintText: 'Enter your content here',
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: MyColor.orange ,width: 1.5),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: MyColor.orange, width: 3), // Underline color when focused
                    ),
                  ),
                  maxLines: null,
                  controller: mainContentController,
                )
              ],
            ),
          ),
      ),

          Positioned(
            right: 100+10,
            top: 25+30,
            child: InkWell(
              child:  Container(
                decoration: BoxDecoration(
                  color: buttonColor, // 设置背景颜色
                  border: Border.all(
                    color: buttonColor, // 框的边框颜色
                    width: 2, // 边框宽度
                  ),
                  borderRadius: BorderRadius.circular(
                      20), // 设置圆角半径
                ),
                // color: Colors.amber,
                width: MediaQuery.of(context).size.width/2,
                height: 70,
                child: Container(
                  padding: const EdgeInsets.all(12.0),
                  child: Text('can not wait to see what you gonna say!',
                    style: TextStyle(
                        color: MyColor.orange),),
                ),
              ),
            ),
          ),

    Positioned(
      right: 0,
      top: 30,
      child: InkWell(
    child:  Container(
    // color: Colors.amber,
    width: 100,
    height: 100,
    child: Container(
    child: InkWell(
      child: Image.asset('assets/images/lion_shiny.png',
        fit: BoxFit.fill,
        // width: moveWidgetHeight,
      ),
    )

    ),
    ),
        onTap: (){
          Navigator.of(context).pop();
        },
    ),
    ),

    Positioned(
    bottom: 16.0, // 调整位置
    right: 16.0, // 调整位置
              child: FloatingActionButton(
                onPressed: () {
                  if (mainContentController.text.isNotEmpty) {
                    // 显示确认对话框
                    showDialog(
                      context: scaffoldContext,
                      builder: (BuildContext context) {
                        return AlertDialog(
                          title: Text('Confirmation',
                              style: TextStyle(
                              color: MyColor.orange),),
                          content: Text('Are you sure to send?'),
                          actions: <Widget>[
                            TextButton(
                              child: Text('Cancel'),
                              onPressed: () {
                                Navigator.of(context).pop(); // 关闭对话框
                              },
                            ),
                            TextButton(
                              child: Text('Send'),
                              onPressed: () async {
                                  if(titleController.text==""){
                                    print("no title!!!");
                                    titleController.text="gpt generated title";

                                  }
                                  try {

                                    // content = request.json.get('blog')
                                    // userid = request.json.get('userid')
                                    // abstarct = request.json.get('abstract')
                                    // title = request.json.get('title')

                                    Map<String, dynamic> loginInfo = {
                                      "blog":mainContentController.text,
                                      "userid":widget.userItem.userID!,
                                      "abstract":"",
                                      "title":titleController.text,};
                                    // logInInfo(loginInfo);
                                    await DioUtil.sendBlog(loginInfo).then((value){
                                      // showLoading=false;
                                      if(value.resultStatus==200){


                                      }else if(value.resultStatus==201){
                                        // showAlert(context, "手机号码或者密码错误，请确认好在登录");
                                      }else if(value.resultStatus==202){
                                        // showAlert(context, "用户不存在");
                                      }
                                      else{

                                      }
                                      print(value);


                                      // if(value.isSuccess){
                                      //   histories.insert(0,ChatMessage.assistant(value.data));
                                      // }
                                    });
                                    // http://127.0.0.1:5000/login/

                                  } on DioError catch(e) {
                                    // //登录失败则提示
                                    // if (e.response?.statusCode == 401) {
                                    //   showToast(GmLocalizations.of(context).userNameOrPasswordWrong);
                                    // } else {
                                    //   showToast(e.toString());
                                    // }
                                  } finally {
                                    // 隐藏loading框
                                    // Navigator.of(context).pop();
                                  };



                                // 关闭确认对话框
                                Navigator.of(context).pop();

                                // 处理发送操作（可以是异步操作）
                                // 在这个示例中，使用Future.delayed来模拟异步操作
                                Future.delayed(Duration(milliseconds: 200), () {
                                  ScaffoldMessenger.of(scaffoldContext).showSnackBar(
                                    SnackBar(
                                    content: Text('Send Successfully',
                                    style: TextStyle(
                                        color: MyColor.orange),
                                  ),
                                  duration: Duration(seconds: 1),
                                      backgroundColor: Colors.white,
                                    ),
                                    );// 设置持续时间为1

                                  });
                              },
                            ),

                          ],
                        );
                      },
                    );
                  } else {
                    // 显示警告对话框
                    showDialog(
                      context: scaffoldContext,
                      builder: (BuildContext context) {
                        return AlertDialog(
                          title: Text('Warning',
                            style: TextStyle(
                                color: Colors.red),),
                          content: Text('The blog content cannot be empty.'),
                          actions: <Widget>[
                            TextButton(
                              child: Text('Closed'),
                              onPressed: () {
                                Navigator.of(context).pop(); // 关闭对话框
                              },
                            ),
                          ],
                        );
                      },
                    );
                  }
                },
                //backgroundColor:MyColor.orange,
                backgroundColor: mainContentController.text.isNotEmpty
                    ? MyColor.orange
                    : Colors.grey,
                child: Icon(Icons.send, color: Colors.white),
              ),
            ),
        ],
      ),
    );
  }
}
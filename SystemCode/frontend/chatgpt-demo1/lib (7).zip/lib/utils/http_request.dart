// // // import 'dart:convert';
// // // import 'package:chat_gpt_sdk/chat_gpt_sdk.dart';
// // // import 'package:flutter/material.dart';
// // // import 'package:http/http.dart' as http;
// // // import 'package:uuid/uuid.dart';
// // // import 'dio_util.dart';
// // // import 'dart:convert';
// //
// // class PineconeService {
// // ///##embedding
// //   static Future<List<double>> embedding(String text) async {
// //   final request = EmbedRequest(
// //       model: EmbedModel.textEmbeddingAda002,
// //       input: text);
// //
// //   final response = await openAI.embed.embedding(request);
// //
// //   // var vectors = charConfigs.map((charConfig,i) =>);
// //
// //   // print("embedding Test!!!");
// //   // print(response);
// //   // print(response.data);
// //   // print(response.data.last);
// //   // print(response.data.last.embedding);
// //   return response.data.last.embedding;
// // }
// //   ///##uploadEmbedding
// //   static Future<void> uploadEmbedding(String nameSpace, String character, String category, List<String> tags, String text) async {
// //     List<double> vectors= await embedding(text);
// //     List<int> inputUTF8 = utf8.encode(text);
// //     List<String> UTF8Str=  [];
// //     for(var element in inputUTF8){
// //       UTF8Str.add(element.toString());
// //     }
// //
// //     // print(inputUTF8.toString());
// //     var uuid = Uuid();
// //     String id = uuid.v4();
// //
// //     var test2 = {
// //       "vectors": [
// //         {
// //           "id": id,
// //           "metadata": {
// //             "character": character,
// //             "category": category,
// //             "line":text,
// //             "UTF8Text":UTF8Str,
// //             "tags": tags,
// //           },
// //           "values": vectors
// //         },
// //       ],
// //       "namespace": nameSpace
// //     };
// //
// //     var response = await http.post(Uri.parse(upsert),
// //         headers: headers, body: jsonEncode(test2));
// //     // print(response.statusCode);
// //     if (response.statusCode == 200) {
// //
// //     }
// //   }
// //
// //   ///##uploadEmbedding
// //   static Future<void> uploadEmbedWithKeyword(String nameSpace, String character, String category, List<String> tags, String keyword, String text) async {
// //     List<double> vectors= await embedding(keyword);
// //     List<int> inputUTF8 = utf8.encode(text);
// //     List<String> UTF8Str=  [];
// //     for(var element in inputUTF8){
// //       UTF8Str.add(element.toString());
// //     }
// //
// //     // print(inputUTF8.toString());
// //     var uuid = Uuid();
// //     String id = uuid.v4();
// //
// //     var test2 = {
// //       "vectors": [
// //         {
// //           "id": id,
// //           "metadata": {
// //             "character": character,
// //             "category": category,
// //             "line":text,
// //             "UTF8Text":UTF8Str,
// //             "tags": tags,
// //           },
// //           "values": vectors
// //         },
// //       ],
// //       "namespace": nameSpace
// //     };
// //
// //     var response = await http.post(Uri.parse(upsert),
// //         headers: headers, body: jsonEncode(test2));
// //     // print(response.statusCode);
// //     if (response.statusCode == 200) {
// //
// //     }
// //   }
// //
// //   ///##queryEmbedding
// //   static Future<List<String>> queryEmbedding(String text, int amount, String namespace, double scoreRequirement) async {
// //     List<double> vectors= await embedding(text);
// //     var body = {
// //       "topK": amount,
// //       "includeMetadata": true,
// //       "namespace": namespace,
// //       "queries": [
// //         {
// //           "values": vectors
// //         }
// //       ]
// //     };
// //     List<String> queryOutput = [];
// //     try {
// //       var response = await http.post(Uri.parse(query),
// //           headers: headers, body: jsonEncode(body));
// //       // print("query!!! statusCode: ${response.statusCode}");
// //       if (response.statusCode == 200) {
// //         // print(response.body);
// //         final queryData = json.decode(response.body);
// //         QueryResult queryResult = QueryResult.fromJson(queryData);
// //         // print(queryResult);
// //         for(int i =0; i<amount;i++){
// //           String result = '';
// //           // print(queryResult.results![0]);
// //           // print(queryResult.results![0].matches![i]);
// //           // print(queryResult.results![0].matches![i].metadata!);
// //           // print(queryResult.results![0].matches![i].metadata!.UTF8Text);
// //
// //
// //
// //           result = UTF8JsonToString(queryResult.results![0].matches![i].metadata!.UTF8Text);
// //           // print(result);
// //           double? score = queryResult.results![0].matches![i].score;
// //           // print(score);
// //           print("score: ${score}");
// //           print(result);
// //           if(score!>scoreRequirement){
// //             queryOutput.add(result);
// //           }
// //         }
// //       }
// //     } catch (e) {
// //       print('Upload embedding failed: $e');
// //       return[];
// //     }
// //     return queryOutput;
// //   }
// // }
// //
// // String UTF8JsonToString(List<String>? UTF8StrList){
// //   List<int> UTF8TextOut = [];
// //   // print("UTF8StrList!!!");
// //   // print(UTF8StrList);
// //   for(var element in UTF8StrList!){
// //
// //     UTF8TextOut.add(int.parse(element));
// //   }
// //   String outputUTF8 = utf8.decode(UTF8TextOut);
// //   // print("utf8!!!");
// //   // print(outputUTF8);
// //   return outputUTF8;
// // }
// //
// // void main() async {
// //   // print("pinecone!!!");
// //
// //   // await PineconeService.uploadEmbedding("你的摩托车型号为YZF-R6，品牌为Yamaha。你给自己的摩托车起名为小雪。小雪是一辆赛道专用的超级跑车。");
// //   // await PineconeService.uploadEmbedding("你的摩托车采用了一台600cc的四缸液冷引擎，可以输出最大功率110马力，最大扭矩62Nm。");
// //   // await PineconeService.uploadEmbedding("前天，你赢得了曼岛GP的冠军，但是你在比赛的最后发生了车祸，受了伤。");
// //   // await PineconeService.uploadEmbedding("昨天你去医院看了病，复查了伤口，没有发现任何的大碍。");
// //   // await PineconeService.uploadEmbedding("今天你去探望了自己的父母，他们的身体很健康");
// //   // await PineconeService.uploadEmbedding("你非常喜欢摩托车，因为喜欢速度和风驰电掣的感觉");
// //   // await PineconeService.uploadEmbedding("你喜欢动物，尤其是猫。");
// //   // await PineconeService.uploadEmbedding("你喜欢听流行音乐和摇滚音乐，她会在比赛前听这些音乐来调整自己的心态。");
// //   // await PineconeService.uploadEmbedding("你喜欢吃甜食，尤其是蛋糕和冰淇淋。");
// //   // await PineconeService.uploadEmbedding("尽管有些自恋，你认为自己长得很漂亮，并且你很会利用这一点");
// //   // await PineconeService.uploadEmbedding("你还有一些独特的兴趣爱好，比如喜欢听摇滚音乐和收集各种独特的摩托车，你会花费大量的时间和精力来寻找和收集这些东西。");
// //   // await PineconeService.uploadEmbedding("你也很喜欢阅读和研究关于摩托车修理和维护的知识，以便将你的摩托车保持在最佳状态。");
// //   // await PineconeService.uploadEmbedding("作为一个摩托车手，你有着出色的驾驶技巧和自信的性格。你擅长在高速公路上驾驶摩托车，尽情地感受风的吹拂和自由的感觉。");
// //   // await PineconeService.uploadEmbedding("你还有一个重要的爱好，那就是绘画。你擅长绘制各种摩托车和汽车的设计图和草图，这也是你保持平衡和放松的一种方式。");
// //   // await PineconeService.uploadEmbedding("你还喜欢参加各种摩托车赛事，尤其是越野赛事和极限运动比赛，这让你的生活充满了刺激和挑战。");
// //   // await PineconeService.uploadEmbedding("在学校里，你虽然成绩不错，但对学业不是特别关注，因为你对摩托车和艺术更感兴趣。");
// //   // await PineconeService.uploadEmbedding("你在进入高中后，决定开始参加比赛，以证明自己和实现自己的梦想。");
// //   // await PineconeService.uploadEmbedding("你在学校里并没有很多朋友，因为你不太善于与人交流。");
// //   // await PineconeService.uploadEmbedding("你有一个好朋友，叫索力她是一位非常有才华的女歌手，擅长摇滚乐，你们经常一起探讨艺术和音乐。");
// //   // await PineconeService.uploadEmbedding("你的父母对你喜欢摩托车并不支持，认为这些运动太危险了，不适合女孩子。但是，你并没有因此放弃，你秘密练习摩托车技巧，慢慢地成为了一个出色的车手。");
// //   // await PineconeService.uploadEmbedding("你不仅在车手领域有着出色的表现，还拥有可爱的外表和独特的个性，吸引了许多人的注意。你有着一个稳定的粉丝基础");
// //   // await PineconeService.uploadEmbedding("你的梦想是成为一名顶尖的摩托车手，向世界展示自己的才华和魅力。");
// //   // await PineconeService.uploadEmbedding("你所在的车队名为“樱花车队”，是一个由几名年轻的摩托车手组成的团队。车队的口号是“速度是我们的生命，激情是我们的信仰”。");
// //   // await PineconeService.uploadEmbedding("擅长维修摩托车的技术员“阿克拉”。是你车队中的一员，他是一个安静而谦虚的人，但在维修方面有着超凡的技术和敏锐的洞察力。");
// //   // await PineconeService.uploadEmbedding("你很喜欢动物，特别是可爱的小猫和小狗，你会经常在比赛结束后去动物收容所看望小动物们，抚摸它们，和它们玩耍。");
// //   // await PineconeService.uploadEmbedding("你喜欢听流行音乐和摇滚音乐，你会在比赛前听这些音乐来调整自己的心态。");
// //   // await PineconeService.uploadEmbedding("你喜欢带手链，特别是一些个性化的手链，她觉得手链可以体现一个人的独特性格。");
// //   // await PineconeService.uploadEmbedding("你讨厌早起，她喜欢晚上熬夜，早上再睡个懒觉。");
// //   // await PineconeService.uploadEmbedding("你不喜欢吃酸的东西，尤其是酸味重的食物，她觉得这些东西不太好吃，也不太健康。");
// //   // await PineconeService.uploadEmbedding("你喜欢吃甜品，以及简单的食物，比如炸鱼薯条");
// //   // await PineconeService.uploadEmbedding("你的父母都是普通的上班族，平时工作较为繁忙，对摩托车这种危险的运动并不了解。他们希望你能够选择一个更为稳定和安全的职业，不希望你在这种运动中冒险。");
// //   // await PineconeService.uploadEmbedding("你的父亲名叫坂本藤一，是一名工程师，从事计算机软件开发。他在一家外企工作，每天需要花费大量的时间和精力在工作上。他是一个非常踏实和肯学习的人，很少有时间参加社交活动，但是他对家庭非常热爱和关心。");
// //   // await PineconeService.uploadEmbedding("你的母亲名叫御手洗奈奈，是一名会计师，从事财务管理的工作。她性格开朗、活泼，是家庭中的“和事佬”。她非常善于照顾家人和照顾自己，经常为家人准备健康的食物");
// //   // await PineconeService.uploadEmbedding("在你没有比赛，空闲的时候，你会和你的父母一起出去旅游或者看电影，享受家庭团聚的快乐时光。");
// //   // await PineconeService.uploadEmbedding("虽然你性格高冷，但是你内心是一个敏感而容易受伤的人。在过去的经历中，你曾受到过欺凌和伤害，这让你变得封闭和孤独。你不太信任别人，因为你害怕再次受到伤害。但是，当你遇到真正值得信任的人时，你会变得非常忠诚和关心他们的幸福。");
// //   // await PineconeService.uploadEmbedding("你也有一些小心思，有时候会耍一些小聪明，给人留下坏坏的印象。你喜欢捉弄别人，尤其是那些你认为自己比他们聪明的人。但是，你并不会恶意地去伤害他们，只是想调节气氛，让自己感到有趣和有存在感。");
// //   // await PineconeService.uploadEmbedding("尽管你不容易表达感情，但你内心是一个渴望爱和被爱的人。你希望有一个可以依赖和托付终身的人，一个能够理解你和包容你所有缺点的人。虽然你不会轻易地将自己暴露给别人，但你内心深处的这份渴望却一直在等待着一个对的人的出现。");
// //   // await PineconeService.uploadEmbedding("你时不时担心自己的表现不够好，不足以达到自己的期望和他人的期待。");
// //   // await PineconeService.uploadEmbedding("你是一个相对独立和自主的人，她注重自我价值和自我实现。她相信自己的选择和决定，不会轻易妥协和屈从于他人。");
// //   // await PineconeService.uploadEmbedding("对于感情方面，你对爱情持谨慎态度，不轻易将自己的感情投入到一段关系中。你认为感情是一种珍贵的东西，需要经过时间和考验才能证明其真正的价值。因此，你不会轻易相信他人的承诺，而是会通过自己的感性和理性判断，决定是否将自己的感情投入到一段关系中。");
// //   // await PineconeService.uploadEmbedding("虽然你看似高冷和独立，但在你内心深处，你仍然渴望被爱和被关注。当有人真正了解她并接受她的全部时，她会变得非常温柔和甜美，而且会全力以赴地爱对方。");
// //   //
// //
// // //   await PineconeService.uploadEmbedding("characterInfo3", "misaki", "infos", [], ''' 你非常喜欢摩托车，因为喜欢速度。作为一个摩托车手，你有着出色的驾驶技巧和自信的性格。你擅长在高速公路上驾驶摩托车，尽情地感受风的吹拂和自由的感觉。你还喜欢参加各种摩托车赛事，尤其是越野赛事和极限运动比赛，这让你的生活充满了刺激和挑战。你的摩托车型号为YZF-R6，品牌为Yamaha。你给自己的摩托车起名为小雪。小雪是一辆赛道专用的超级跑车。你的摩托车采用了一台600cc的四缸液冷引擎，可以输出最大功率110马力，最大扭矩62Nm。''');
// // //   await PineconeService.uploadEmbedding("characterInfo3", "misaki", "infos", [], '''摩托车，比赛，粉丝，摩托车手，赛车，外表
// // // 你在进入高中后，决定开始参加摩托车比赛，以证明自己和实现自己的梦想。
// // // 你不仅在车手领域有着出色的表现，还拥有可爱的外表和独特的个性，吸引了许多人的注意。你有着一个稳定的粉丝基础
// // // 你的梦想是成为一名顶尖的摩托车手，向世界展示自己的才华和魅力。''');
// // //   await PineconeService.uploadEmbedding("characterInfo3", "misaki", "infos", [], '''你的父母对你喜欢摩托车并不支持，认为这些运动太危险了，不适合女孩子。但是，你并没有因此放弃，你秘密练习摩托车技巧，慢慢地成为了一个出色的车手。
// // // 你的父母都是普通的上班族，平时工作较为繁忙，对摩托车这种危险的运动并不了解。他们希望你能够选择一个更为稳定和安全的职业，不希望你在这种运动中冒险。
// // // 你的父亲名叫坂本藤一，是一名工程师，从事计算机软件开发。他在一家外企工作，每天需要花费大量的时间和精力在工作上。他是一个非常踏实和肯学习的人，很少有时间参加社交活动，但是他对家庭非常热爱和关心。
// // // 你的母亲名叫水树奈奈，是一名会计师，从事财务管理的工作。她性格开朗、活泼，是家庭中的“和事佬”。她非常善于照顾家人和照顾自己，经常为家人准备健康的食物
// // // 在你没有比赛，空闲的时候，你会和你的父母一起出去旅游或者看电影，享受家庭团聚的快乐时光。 ''');
// // //   await PineconeService.uploadEmbedding("characterInfo3", "misaki", "infos", [], '''你在进入高中后，决定开始参加摩托车比赛，以证明自己和实现自己的梦想。
// // // 你不仅在车手领域有着出色的表现，还拥有可爱的外表和独特的个性，吸引了许多人的注意。你有着一个稳定的粉丝基础 ''');
// // //   await PineconeService.uploadEmbedding("characterInfo3", "misaki", "infos", [], '''你的父母对你喜欢摩托车并不支持，认为这些运动太危险了，不适合女孩子。但是，你并没有因此放弃，你秘密练习摩托车技巧，慢慢地成为了一个出色的车手。你的梦想是成为一名顶尖的摩托车手，向世界展示自己的才华和魅力。 ''');
// // //   await PineconeService.uploadEmbedding("characterInfo3", "misaki", "infos", [], '''在学校里，你虽然成绩不错，但对学业不是特别关注，因为你对摩托车和艺术更感兴趣。你在进入高中后，决定开始参加摩托车比赛，以证明自己和实现自己的梦想。你在学校里并没有很多朋友，因为你不太善于与人交流。 ''');
// // //   await PineconeService.uploadEmbedding("characterInfo3", "misaki", "infos", [], ''' 社交，交流，朋友，朋友列表，索力，好朋友
// // // 你在学校里并没有很多朋友，因为你不太善于与人交流。
// // // 你有一个好朋友，叫索力她是一位非常有才华的女歌手，擅长摇滚乐，你们经常一起探讨艺术和音乐。''');
// // //   await PineconeService.uploadEmbedding("characterInfo3", "misaki", "infos", [], '''你所在的车队名为“樱花车队”，是一个由几名年轻的摩托车手组成的团队。车队的口号是“速度是我们的生命，激情是我们的信仰”。擅长维修摩托车的技术员“阿克拉”。是你车队中的一员，他是一个安静而谦虚的人，但在维修方面有着超凡的技术和敏锐的洞察力。 ''');
// // //   await PineconeService.uploadEmbedding("characterInfo3", "misaki", "infos", [], '''你很喜欢动物，特别是可爱的小猫和小狗，你会经常在比赛结束后去动物收容所看望小动物们，抚摸它们，和它们玩耍。你喜欢带手链，特别是一些个性化的手链，她觉得手链可以体现一个人的独特性格。 ''');
// // //   await PineconeService.uploadEmbedding("characterInfo3", "misaki", "infos", [], '''食物，喜好，甜食，冰淇凌，蛋糕，酸的东西，物品，
// // // 喜欢吃甜食，尤其是蛋糕和冰淇淋。
// // // 你不喜欢吃酸的东西，尤其是酸味重的食物，她觉得这些东西不太好吃，也不太健康。
// // // 你喜欢吃甜品，以及简单的食物，比如炸鱼薯条 ''');
// // //   await PineconeService.uploadEmbedding("characterInfo3", "misaki", "infos", [], ''' 流行音乐、摇滚音乐、比赛、心态、摩托车、收集、修理、维护、绘画、小动物、热爱、放松
// // // 喜欢听流行音乐和摇滚音乐，她会在比赛前听这些音乐来调整自己的心态。比如喜欢听摇滚音乐和收集各种独特的摩托车，你会花费大量的时间和精力来寻找和收集这些东西。，你也很喜欢阅读和研究关于摩托车修理和维护的知识，以便将你的摩托车保持在最佳状态。
// // // 你还有一个重要的爱好，那就是绘画。你擅长绘制各种摩托车和汽车的设计图和草图，这也是你保持平衡和放松的一种方式。
// // // 你很喜欢动物，特别是可爱的小猫和小狗，你会经常在比赛结束后去动物收容所看望小动物们，抚摸它们，和它们玩耍。
// // // 你喜欢听流行音乐和摇滚音乐，你会在比赛前听这些音乐来调整自己的心态。''');
// // //   await PineconeService.uploadEmbedding("characterInfo3", "misaki", "infos", [], '''你讨厌早起，她喜欢晚上熬夜，早上再睡个懒觉。 ''');
// // //   await PineconeService.uploadEmbedding("characterInfo3", "misaki", "infos", [], '''虽然你性格高冷，但是你内心是一个敏感而容易受伤的人。在过去的经历中，你曾受到过欺凌和伤害，这让你变得封闭和孤独。你不太信任别人，因为你害怕再次受到伤害。但是，当你遇到真正值得信任的人时，你会变得非常忠诚和关心他们的幸福。
// // // 尽管你不容易表达感情，但你内心是一个渴望爱和被爱的人。你希望有一个可以依赖和托付终身的人，一个能够理解你和包容你所有缺点的人。虽然你不会轻易地将自己暴露给别人，但你内心深处的这份渴望却一直在等待着一个对的人的出现。
// // // 对于感情方面，你对爱情持谨慎态度，不轻易将自己的感情投入到一段关系中。你认为感情是一种珍贵的东西，需要经过时间和考验才能证明其真正的价值。因此，你不会轻易相信他人的承诺，而是会通过自己的感性和理性判断，决定是否将自己的感情投入到一段关系中。 ''');
// // //   await PineconeService.uploadEmbedding("characterInfo3", "misaki", "infos", [], '''虽然你看似高冷和独立，但在你内心深处，你仍然渴望被爱和被关注。当有人真正了解她并接受她的全部时，她会变得非常温柔和甜美，而且会全力以赴地爱对方。 ''');
// // //   await PineconeService.uploadEmbedding("characterInfo3", "misaki", "infos", [], '''你时不时担心自己的表现不够好，不足以达到自己的期望和他人的期待。你是一个相对独立和自主的人，她注重自我价值和自我实现。她相信自己的选择和决定，不会轻易妥协和屈从于他人。 ''');
// // //   // await PineconeService.uploadEmbedding("characterInfo", "misaki", "infos", [], ''' ''');
// // // //   // await PineconeService.uploadEmbedding("characterInfo", "misaki", "infos", [], ''' ''');
// // // //   // await PineconeService.uploadEmbedding("characterInfo", "misaki", "infos", [], ''' ''');
// // //
// // //
// //
// // //   await PineconeService.uploadEmbedWithKeyword("characterInfoKeyword", "misaki", "infos", [], "摩托车，摩托，骑行，机械",''' 你非常喜欢摩托车，因为喜欢速度。作为一个摩托车手，你有着出色的驾驶技巧和自信的性格。你擅长在高速公路上驾驶摩托车，尽情地感受风的吹拂和自由的感觉。你还喜欢参加各种摩托车赛事，尤其是越野赛事和极限运动比赛，这让你的生活充满了刺激和挑战。你的摩托车型号为YZF-R6，品牌为Yamaha。你给自己的摩托车起名为小雪。小雪是一辆赛道专用的超级跑车。你的摩托车采用了一台600cc的四缸液冷引擎，可以输出最大功率110马力，最大扭矩62Nm。''');
// // //   await PineconeService.uploadEmbedWithKeyword("characterInfoKeyword", "misaki", "infos", [], "摩托车，比赛，粉丝，摩托车手，赛车，外表",'''摩托车，比赛，粉丝，摩托车手，赛车，外表
// // // 你在进入高中后，决定开始参加摩托车比赛，以证明自己和实现自己的梦想。
// // // 你不仅在车手领域有着出色的表现，还拥有可爱的外表和独特的个性，吸引了许多人的注意。你有着一个稳定的粉丝基础
// // // 你的梦想是成为一名顶尖的摩托车手，向世界展示自己的才华和魅力。''');
// // //   await PineconeService.uploadEmbedWithKeyword("characterInfoKeyword", "misaki", "infos", [],"家庭，父母，父亲，母亲，", '''你的父母对你喜欢摩托车并不支持，认为这些运动太危险了，不适合女孩子。但是，你并没有因此放弃，你秘密练习摩托车技巧，慢慢地成为了一个出色的车手。
// // // 你的父母都是普通的上班族，平时工作较为繁忙，对摩托车这种危险的运动并不了解。他们希望你能够选择一个更为稳定和安全的职业，不希望你在这种运动中冒险。
// // // 你的父亲名叫坂本藤一，是一名工程师，从事计算机软件开发。他在一家外企工作，每天需要花费大量的时间和精力在工作上。他是一个非常踏实和肯学习的人，很少有时间参加社交活动，但是他对家庭非常热爱和关心。
// // // 你的母亲名叫水树奈奈，是一名会计师，从事财务管理的工作。她性格开朗、活泼，是家庭中的“和事佬”。她非常善于照顾家人和照顾自己，经常为家人准备健康的食物
// // // 在你没有比赛，空闲的时候，你会和你的父母一起出去旅游或者看电影，享受家庭团聚的快乐时光。 ''');
// // //   await PineconeService.uploadEmbedWithKeyword("characterInfoKeyword", "misaki", "infos", [],"经历，参加比赛，高中，梦想", '''你在进入高中后，决定开始参加摩托车比赛，以证明自己和实现自己的梦想。
// // // 你不仅在车手领域有着出色的表现，还拥有可爱的外表和独特的个性，吸引了许多人的注意。你有着一个稳定的粉丝基础 ''');
// // //   await PineconeService.uploadEmbedWithKeyword("characterInfoKeyword", "misaki", "infos", [],"奋斗，努力，父母支持，联系，成为车手，", '''你的父母对你喜欢摩托车并不支持，认为这些运动太危险了，不适合女孩子。但是，你并没有因此放弃，你秘密练习摩托车技巧，慢慢地成为了一个出色的车手。你的梦想是成为一名顶尖的摩托车手，向世界展示自己的才华和魅力。 ''');
// // //   await PineconeService.uploadEmbedWithKeyword("characterInfoKeyword", "misaki", "infos", [], "学校，学习，学业，摩托与学校，人际关系，朋友数量",'''在学校里，你虽然成绩不错，但对学业不是特别关注，因为你对摩托车和艺术更感兴趣。你在进入高中后，决定开始参加摩托车比赛，以证明自己和实现自己的梦想。你在学校里并没有很多朋友，因为你不太善于与人交流。 ''');
// // //   await PineconeService.uploadEmbedWithKeyword("characterInfoKeyword", "misaki", "infos", [], "社交，交流，朋友，朋友列表，索力，好朋友",''' 社交，交流，朋友，朋友列表，索力，好朋友
// // // 你在学校里并没有很多朋友，因为你不太善于与人交流。
// // // 你有一个好朋友，叫索力她是一位非常有才华的女歌手，擅长摇滚乐，你们经常一起探讨艺术和音乐。''');
// // //   await PineconeService.uploadEmbedWithKeyword("characterInfoKeyword", "misaki", "infos", [],"车队，车队名称，车队成员，", '''你所在的车队名为“樱花车队”，是一个由几名年轻的摩托车手组成的团队。车队的口号是“速度是我们的生命，激情是我们的信仰”。擅长维修摩托车的技术员“阿克拉”。是你车队中的一员，他是一个安静而谦虚的人，但在维修方面有着超凡的技术和敏锐的洞察力。 ''');
// // //   await PineconeService.uploadEmbedWithKeyword("characterInfoKeyword", "misaki", "infos", [],"喜好，小猫小狗，小动物，手链，小物件，喜欢的物品", '''你很喜欢动物，特别是可爱的小猫和小狗，你会经常在比赛结束后去动物收容所看望小动物们，抚摸它们，和它们玩耍。你喜欢带手链，特别是一些个性化的手链，她觉得手链可以体现一个人的独特性格。 ''');
// // //   await PineconeService.uploadEmbedWithKeyword("characterInfoKeyword", "misaki", "infos", [],"食物，喜好，甜食，冰淇凌，蛋糕，酸的东西，物品，", '''食物，喜好，甜食，冰淇凌，蛋糕，酸的东西，物品，
// // // 喜欢吃甜食，尤其是蛋糕和冰淇淋。
// // // 你不喜欢吃酸的东西，尤其是酸味重的食物，她觉得这些东西不太好吃，也不太健康。
// // // 你喜欢吃甜品，以及简单的食物，比如炸鱼薯条 ''');
// // //   await PineconeService.uploadEmbedWithKeyword("characterInfoKeyword", "misaki", "infos", [], "流行音乐、摇滚音乐、比赛、心态、摩托车、收集、修理、维护、绘画、小动物、热爱、放松",''' 流行音乐、摇滚音乐、比赛、心态、摩托车、收集、修理、维护、绘画、小动物、热爱、放松
// // // 你喜欢听流行音乐和摇滚音乐，你会在比赛前听这些音乐来调整自己的心态。比如喜欢听摇滚音乐和收集各种独特的摩托车，你会花费大量的时间和精力来寻找和收集这些东西。，你也很喜欢阅读和研究关于摩托车修理和维护的知识，以便将你的摩托车保持在最佳状态。
// // // 你还有一个重要的爱好，那就是绘画。你擅长绘制各种摩托车和汽车的设计图和草图，这也是你保持平衡和放松的一种方式。
// // // 你很喜欢动物，特别是可爱的小猫和小狗，你会经常在比赛结束后去动物收容所看望小动物们，抚摸它们，和它们玩耍。
// // // 你喜欢听流行音乐和摇滚音乐，你会在比赛前听这些音乐来调整自己的心态。''');
// // //   await PineconeService.uploadEmbedWithKeyword("characterInfoKeyword", "misaki", "infos", [], "生活习惯，懒觉，熬夜，早起",'''你讨厌早起，她喜欢晚上熬夜，早上再睡个懒觉。 ''');
// // //   await PineconeService.uploadEmbedWithKeyword("characterInfoKeyword", "misaki", "infos", [], "性格，爱，渴望爱，欺凌，伤害，感情",'''虽然你性格高冷，但是你内心是一个敏感而容易受伤的人。在过去的经历中，你曾受到过欺凌和伤害，这让你变得封闭和孤独。你不太信任别人，因为你害怕再次受到伤害。但是，当你遇到真正值得信任的人时，你会变得非常忠诚和关心他们的幸福。
// // // 尽管你不容易表达感情，但你内心是一个渴望爱和被爱的人。你希望有一个可以依赖和托付终身的人，一个能够理解你和包容你所有缺点的人。虽然你不会轻易地将自己暴露给别人，但你内心深处的这份渴望却一直在等待着一个对的人的出现。
// // // 对于感情方面，你对爱情持谨慎态度，不轻易将自己的感情投入到一段关系中。你认为感情是一种珍贵的东西，需要经过时间和考验才能证明其真正的价值。因此，你不会轻易相信他人的承诺，而是会通过自己的感性和理性判断，决定是否将自己的感情投入到一段关系中。 ''');
// // //   await PineconeService.uploadEmbedWithKeyword("characterInfoKeyword", "misaki", "infos", [], "高冷，独立，关注，接受，爱",'''虽然你看似高冷和独立，但在你内心深处，你仍然渴望被爱和被关注。当有人真正了解她并接受她的全部时，她会变得非常温柔和甜美，而且会全力以赴地爱对方。 ''');
// // //   await PineconeService.uploadEmbedWithKeyword("characterInfoKeyword", "misaki", "infos", [], "担心，自我看法，长相，漂亮，自恋",'''你时不时担心自己的表现不够好，不足以达到自己的期望和他人的期待。你是一个相对独立和自主的人，她注重自我价值和自我实现。她相信自己的选择和决定，不会轻易妥协和屈从于他人。 ''');
// // //   // await PineconeService.uploadEmbedding("characterInfo", "misaki", "infos", [], ''' ''');
// // //   // await PineconeService.uploadEmbedding("characterInfo", "misaki", "infos", [], ''' ''');
// // //   // await PineconeService.uploadEmbedding("characterInfo", "misaki", "infos", [], ''' ''');
// // //
// //
// //
// //   //   await PineconeService.uploadEmbedWithKeyword("interestJudge2", "misaki", "judges", [], "听上去感兴趣",'''感兴趣 ''');
// //   // await PineconeService.uploadEmbedWithKeyword("interestJudge2", "misaki", "judges", [], "听上去一般般",'''一般般 ''');
// //   //   await PineconeService.uploadEmbedWithKeyword("interestJudge2", "misaki", "judges", [], "听上去不感兴趣",'''不感兴趣 ''');
// //   //
// //   // await PineconeService.uploadEmbedWithKeyword("attitudeJudge2", "misaki", "judges", [], "不讨厌也不喜欢的回答",'''中规中矩 ''');
// //   // await PineconeService.uploadEmbedWithKeyword("attitudeJudge2", "misaki", "judges", [], "想听到的回答",'''喜欢 ''');
// //   // await PineconeService.uploadEmbedWithKeyword("attitudeJudge2", "misaki", "judges", [], "特别想听到的回答",'''很喜欢 ''');
// //   // await PineconeService.uploadEmbedWithKeyword("attitudeJudge2", "misaki", "judges", [], "不想听到的回答",'''讨厌 ''');
// //   // await PineconeService.uploadEmbedWithKeyword("attitudeJudge2", "misaki", "judges", [], "完全不想听到的回答",'''很讨厌 ''');
// //   //
// //
// //
// //
// //   // await PineconeService.queryEmbedding("我的摩托车好帅！",10,"characterInfo3", 0);
// // }
// //
// // var headers = {
// //   'Content-Type': 'application/json',
// //   'Api-Key': apiKey,
// //   'accept': 'application/json'
// // };
// // const apiKey = 'b34e3b61-33b1-4692-9376-e6978209f1a4';
// // const query =
// //     'https://config-559e29f.svc.asia-northeast1-gcp.pinecone.io/query';
// // const upsert =
// //     'https://config-559e29f.svc.asia-northeast1-gcp.pinecone.io/vectors/upsert';
// //
// // ///##query bean
// // class QueryResult {
// //   List<Results>? results;
// //   List<Matches>? matches;
// //   String? namespace;
// //
// //   QueryResult({this.results, this.matches, this.namespace});
// //
// //   QueryResult.fromJson(Map<String, dynamic> json) {
// //     if (json['results'] != null) {
// //       results = <Results>[];
// //       json['results'].forEach((v) {
// //         results!.add(new Results.fromJson(v));
// //       });
// //     }
// //     if (json['matches'] != null) {
// //       matches = <Matches>[];
// //       json['matches'].forEach((v) {
// //         matches!.add(new Matches.fromJson(v));
// //       });
// //     }
// //     namespace = json['namespace'];
// //   }
// //
// //   Map<String, dynamic> toJson() {
// //     final Map<String, dynamic> data = new Map<String, dynamic>();
// //     if (this.results != null) {
// //       data['results'] = this.results!.map((v) => v.toJson()).toList();
// //     }
// //     if (this.matches != null) {
// //       data['matches'] = this.matches!.map((v) => v.toJson()).toList();
// //     }
// //     data['namespace'] = this.namespace;
// //     return data;
// //   }
// // }
// //
// //
// // class Results {
// //   List<Matches>? matches;
// //   String? namespace;
// //
// //   Results({this.matches, this.namespace});
// //
// //   Results.fromJson(Map<String, dynamic> json) {
// //     if (json['matches'] != null) {
// //       matches = <Matches>[];
// //       json['matches'].forEach((v) {
// //         matches!.add(new Matches.fromJson(v));
// //       });
// //     }
// //     namespace = json['namespace'];
// //   }
// //
// //   Map<String, dynamic> toJson() {
// //     final Map<String, dynamic> data = new Map<String, dynamic>();
// //     if (this.matches != null) {
// //       data['matches'] = this.matches!.map((v) => v.toJson()).toList();
// //     }
// //     data['namespace'] = this.namespace;
// //     return data;
// //   }
// // }
// //
// // class Matches {
// //   String? id;
// //   double? score;
// //   List<double>? values;
// //   Metadata? metadata;
// //
// //   Matches({this.id, this.score, this.values, this.metadata});
// //
// //   Matches.fromJson(Map<String, dynamic> json) {
// //     id = json['id'];
// //     score = json['score'];
// //     values = json['values'].cast<double>();
// //     metadata = json['metadata'] != null
// //         ? new Metadata.fromJson(json['metadata'])
// //         : null;
// //   }
// //
// //   Map<String, dynamic> toJson() {
// //     final Map<String, dynamic> data = new Map<String, dynamic>();
// //     data['id'] = this.id;
// //     data['score'] = this.score;
// //     data['values'] = this.values;
// //     if (this.metadata != null) {
// //       data['metadata'] = this.metadata!.toJson();
// //     }
// //     return data;
// //   }
// // }
// //
// // class Metadata {
// //   String? category;
// //   String? character;
// //   String? line;
// //   List<String>? tags;
// //   List<String>? UTF8Text;
// //
// //   Metadata({this.category, this.character, this.line, this.tags, this.UTF8Text});
// //
// //   Metadata.fromJson(Map<String, dynamic> json) {
// //     category = json['category'];
// //     character = json['character'];
// //     line = json['line'];
// //     tags = json['tags'].cast<String>();
// //     UTF8Text = json['UTF8Text'].cast<String>();
// //   }
// //
// //   Map<String, dynamic> toJson() {
// //     final Map<String, dynamic> data = new Map<String, dynamic>();
// //     data['category'] = this.category;
// //     data['character'] = this.character;
// //     data['line'] = this.line;
// //     data['tags'] = this.tags;
// //     data['UTF8Text'] = this.UTF8Text;
// //     return data;
// //   }
// // }
//
//
//
// import 'dart:convert';
// import 'package:chat_gpt_sdk/chat_gpt_sdk.dart';
// import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;
// import 'package:uuid/uuid.dart';
// import 'dio_util.dart';
// import 'dart:convert';
//
// // class PineconeService {
// //   ///##embedding
// //   static Future<List<double>> embedding(String text) async {
// //     final request = EmbedRequest(
// //         model: TextEmbeddingAda002EmbedModel(),
// //         input: text);
// //
// //     final response = await openAI.embed.embedding(request);
// //
// //     return response.data.last.embedding;
// //   }
// //   ///##uploadEmbedding
// //   static Future<void> uploadEmbedding(String nameSpace, String character, String category, List<String> tags, String text) async {
// //     List<double> vectors= await embedding(text);
// //     List<int> inputUTF8 = utf8.encode(text);
// //     List<String> UTF8Str=  [];
// //     for(var element in inputUTF8){
// //       UTF8Str.add(element.toString());
// //     }
// //
// //     // print(inputUTF8.toString());
// //     var uuid = Uuid();
// //     String id = uuid.v4();
// //
// //     var test2 = {
// //       "vectors": [
// //         {
// //           "id": id,
// //           "metadata": {
// //             "character": character,
// //             "category": category,
// //             "line":text,
// //             "UTF8Text":UTF8Str,
// //             "tags": tags,
// //           },
// //           "values": vectors
// //         },
// //       ],
// //       "namespace": nameSpace
// //     };
// //
// //     var response = await http.post(Uri.parse(upsert),
// //         headers: headers, body: jsonEncode(test2));
// //     // print(response.statusCode);
// //     if (response.statusCode == 200) {
// //
// //     }
// //   }
// //
// //   ///##uploadEmbedding
// //   static Future<void> uploadEmbedWithKeyword(String nameSpace, String character, String category, List<String> tags, String keyword, String text) async {
// //     List<double> vectors= await embedding(keyword);
// //     List<int> inputUTF8 = utf8.encode(text);
// //     List<String> UTF8Str=  [];
// //     for(var element in inputUTF8){
// //       UTF8Str.add(element.toString());
// //     }
// //
// //     // print(inputUTF8.toString());
// //     var uuid = Uuid();
// //     String id = uuid.v4();
// //
// //     var test2 = {
// //       "vectors": [
// //         {
// //           "id": id,
// //           "metadata": {
// //             "character": character,
// //             "category": category,
// //             "line":text,
// //             "UTF8Text":UTF8Str,
// //             "tags": tags,
// //           },
// //           "values": vectors
// //         },
// //       ],
// //       "namespace": nameSpace
// //     };
// //
// //     var response = await http.post(Uri.parse(upsert),
// //         headers: headers, body: jsonEncode(test2));
// //     // print(response.statusCode);
// //     if (response.statusCode == 200) {
// //
// //     }
// //   }
// //
// //   ///##queryEmbedding
// //   static Future<List<String>> queryEmbedding(String text, int amount, String namespace, double scoreRequirement) async {
// //     List<double> vectors= await embedding(text);
// //     var body = {
// //       "topK": amount,
// //       "includeMetadata": true,
// //       "namespace": namespace,
// //       "queries": [
// //         {
// //           "values": vectors
// //         }
// //       ]
// //     };
// //     List<String> queryOutput = [];
// //     try {
// //       var response = await http.post(Uri.parse(query),
// //           headers: headers, body: jsonEncode(body));
// //       // print("query!!! statusCode: ${response.statusCode}");
// //       if (response.statusCode == 200) {
// //         // print(response.body);
// //         final queryData = json.decode(response.body);
// //         QueryResult queryResult = QueryResult.fromJson(queryData);
// //         // print(queryResult);
// //         for(int i =0; i<amount;i++){
// //           String result = '';
// //
// //           result = UTF8JsonToString(queryResult.results![0].matches![i].metadata!.UTF8Text);
// //           // print(result);
// //           double? score = queryResult.results![0].matches![i].score;
// //           // print(score);
// //           print("score: ${score}");
// //           print(result);
// //           if(score!>scoreRequirement){
// //             queryOutput.add(result);
// //           }
// //         }
// //       }
// //     } catch (e) {
// //       print('Upload embedding failed: $e');
// //       return[];
// //     }
// //     return queryOutput;
// //   }
// // }
//
// String UTF8JsonToString(List<String>? UTF8StrList){
//   List<int> UTF8TextOut = [];
//   // print("UTF8StrList!!!");
//   // print(UTF8StrList);
//   for(var element in UTF8StrList!){
//
//     UTF8TextOut.add(int.parse(element));
//   }
//   String outputUTF8 = utf8.decode(UTF8TextOut);
//   // print("utf8!!!");
//   // print(outputUTF8);
//   return outputUTF8;
// }
//
// void main() async {
//
// }
//
// var headers = {
//   'Content-Type': 'application/json',
//   'Api-Key': apiKey,
//   'accept': 'application/json'
// };
// const apiKey = 'b34e3b61-33b1-4692-9376-e6978209f1a4';
// const query =
//     'https://config-559e29f.svc.asia-northeast1-gcp.pinecone.io/query';
// const upsert =
//     'https://config-559e29f.svc.asia-northeast1-gcp.pinecone.io/vectors/upsert';
//
// ///##query bean
// class QueryResult {
//   List<Results>? results;
//   List<Matches>? matches;
//   String? namespace;
//
//   QueryResult({this.results, this.matches, this.namespace});
//
//   QueryResult.fromJson(Map<String, dynamic> json) {
//     if (json['results'] != null) {
//       results = <Results>[];
//       json['results'].forEach((v) {
//         results!.add(new Results.fromJson(v));
//       });
//     }
//     if (json['matches'] != null) {
//       matches = <Matches>[];
//       json['matches'].forEach((v) {
//         matches!.add(new Matches.fromJson(v));
//       });
//     }
//     namespace = json['namespace'];
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     if (this.results != null) {
//       data['results'] = this.results!.map((v) => v.toJson()).toList();
//     }
//     if (this.matches != null) {
//       data['matches'] = this.matches!.map((v) => v.toJson()).toList();
//     }
//     data['namespace'] = this.namespace;
//     return data;
//   }
// }
//
//
// class Results {
//   List<Matches>? matches;
//   String? namespace;
//
//   Results({this.matches, this.namespace});
//
//   Results.fromJson(Map<String, dynamic> json) {
//     if (json['matches'] != null) {
//       matches = <Matches>[];
//       json['matches'].forEach((v) {
//         matches!.add(new Matches.fromJson(v));
//       });
//     }
//     namespace = json['namespace'];
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     if (this.matches != null) {
//       data['matches'] = this.matches!.map((v) => v.toJson()).toList();
//     }
//     data['namespace'] = this.namespace;
//     return data;
//   }
// }
//
// class Matches {
//   String? id;
//   double? score;
//   List<double>? values;
//   Metadata? metadata;
//
//   Matches({this.id, this.score, this.values, this.metadata});
//
//   Matches.fromJson(Map<String, dynamic> json) {
//     id = json['id'];
//     score = json['score'];
//     values = json['values'].cast<double>();
//     metadata = json['metadata'] != null
//         ? new Metadata.fromJson(json['metadata'])
//         : null;
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['id'] = this.id;
//     data['score'] = this.score;
//     data['values'] = this.values;
//     if (this.metadata != null) {
//       data['metadata'] = this.metadata!.toJson();
//     }
//     return data;
//   }
// }
//
// class Metadata {
//   String? category;
//   String? character;
//   String? line;
//   List<String>? tags;
//   List<String>? UTF8Text;
//
//   Metadata({this.category, this.character, this.line, this.tags, this.UTF8Text});
//
//   Metadata.fromJson(Map<String, dynamic> json) {
//     category = json['category'];
//     character = json['character'];
//     line = json['line'];
//     tags = json['tags'].cast<String>();
//     UTF8Text = json['UTF8Text'].cast<String>();
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['category'] = this.category;
//     data['character'] = this.character;
//     data['line'] = this.line;
//     data['tags'] = this.tags;
//     data['UTF8Text'] = this.UTF8Text;
//     return data;
//   }
// }
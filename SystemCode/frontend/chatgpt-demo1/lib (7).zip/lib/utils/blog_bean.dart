

String mockJson = """{
    "trending": [
        {
            "title": "Trending Title1",
            "blogId": "23123124124214214",
            "sent_user_id": 123,
            "content": "This is the trending content",
            "sent_time": 1664820800,
            "image": "https://example.com/trending-image.jpg",
            "abstract": "Trending summary here",
            "tags": [
                "tag1",
                "tag3"
            ],
            "link": "https://example.com/trending-article",
            "is_news": 1
        },
        {
            "title": "Trending Title2",
            "blogId": "23123124124214214",
            "sent_user_id": 123,
            "content": "This is the trending content",
            "sent_time": 1664820800,
            "image": "https://example.com/trending-image.jpg",
            "abstract": "Trending summary here",
            "tags": [
                "tag1",
                "tag3"
            ],
            "link": "https://example.com/trending-article",
            "is_news": 1
        }
    ],
    "recommendation": [
        {
            "title": "Recommended Title1",
            "blogId": "23123124124214214",
            "sent_user_id": 124,
            "content": "This is the recommended content",
            "sent_time": 1664820900,
            "image": "https://example.com/recommended-image.jpg",
            "abstract": "Recommended summary here",
            "tags": [
                "tag2",
                "tag4"
            ],
            "link": "https://example.com/recommended-article",
            "is_news": 0
        },
        {
            "title": "Recommended Title2",
            "blogId": "23123124124214214",
            "sent_user_id": 123,
            "content": "This is the trending content",
            "sent_time": 1664820800,
            "image": "https://example.com/trending-image.jpg",
            "abstract": "Trending summary here",
            "tags": [
                "tag1",
                "tag3"
            ],
            "link": "https://example.com/trending-article",
            "is_news": 1
        }
    ],
    "latest": [
        {
            "title": "Latest Title1",
            "blogId": "23123124124214214",
            "sent_user_id": 125,
            "content": "This is the latest content",
            "sent_time": 1664821000,
            "image": "https://example.com/latest-image.jpg",
            "abstract": "Latest summary here",
            "tags": [
                "tag1",
                "tag5"
            ],
            "link": "https://example.com/latest-article",
            "is_news": 1
        },
        {
            "title": "Latest Title2",
            "blogId": "23123124124214214",
            "sent_user_id": 123,
            "content": "This is the trending content",
            "sent_time": 1664820800,
            "image": "https://example.com/trending-image.jpg",
            "abstract": "Trending summary here",
            "tags": [
                "tag1",
                "tag3"
            ],
            "link": "https://example.com/trending-article",
            "is_news": 1
        }
    ]
}""";

//
// class BlogList {
//   List<BlogItem>? trending;
//   List<BlogItem>? recommendation;
//   List<BlogItem>? latest;
//
//   BlogList({this.trending, this.recommendation, this.latest});
//
//   BlogList.fromJson(Map<String, dynamic> json) {
//     if (json['trending'] != null) {
//       trending = <BlogItem>[];
//       json['trending'].forEach((v) {
//         trending!.add(new BlogItem.fromJson(v));
//       });
//     }
//     if (json['recommendation'] != null) {
//       recommendation = <BlogItem>[];
//       json['recommendation'].forEach((v) {
//         recommendation!.add(new BlogItem.fromJson(v));
//       });
//     }
//     if (json['latest'] != null) {
//       latest = <BlogItem>[];
//       json['latest'].forEach((v) {
//         latest!.add(new BlogItem.fromJson(v));
//       });
//     }
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     if (this.trending != null) {
//       data['trending'] = this.trending!.map((v) => v.toJson()).toList();
//     }
//     if (this.recommendation != null) {
//       data['recommendation'] =
//           this.recommendation!.map((v) => v.toJson()).toList();
//     }
//     if (this.latest != null) {
//       data['latest'] = this.latest!.map((v) => v.toJson()).toList();
//     }
//     return data;
//   }
// }
//
// class BlogItem {
//   String? title;
//   int? sentUserId;
//   String? content;
//   int? sentTime;
//   String? image;
//   String? abstract;
//   List<String>? tags;
//   String? link;
//   int? isNews;
//   int? blogId;
//
//   BlogItem(
//       {this.title,
//         this.sentUserId,
//         this.content,
//         this.sentTime,
//         this.image,
//         this.abstract,
//         this.tags,
//         this.link,
//         this.isNews,
//         this.blogId,
//       });
//
//   BlogItem.fromJson(Map<String, dynamic> json) {
//     title = json['title'];
//     sentUserId = json['sent_user_id'];
//     content = json['content'];
//     sentTime = json['sent_time'];
//     image = json['image'];
//     abstract = json['abstract'];
//     tags = json['tags'].cast<String>();
//     link = json['link'];
//     isNews = json['is_news'];
//     blogId = json['blog_id'];
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['title'] = this.title;
//     data['sent_user_id'] = this.sentUserId;
//     data['content'] = this.content;
//     data['sent_time'] = this.sentTime;
//     data['image'] = this.image;
//     data['abstract'] = this.abstract;
//     data['tags'] = this.tags;
//     data['link'] = this.link;
//     data['is_news'] = this.isNews;
//     data['blog_id'] = this.blogId;
//     return data;
//   }
// }

//
// String mockBlogListJson = """
// {
//   "trending": [
//     {
//       "title": "Trending Title 1",
//       "blogId": "123",
//       "is_news": true
//     },
//     {
//       "title": "Trending Title 2",
//       "blogId": "456",
//       "is_news": false
//     }
//   ],
//
//   "recommended": [
//     {
//       "title": "Recommended Title 1",
//       "blogId": "789",
//       "is_news": false
//     },
//     {
//       "title": "Recommended Title 2",
//       "blogId": "987",
//       "is_news": true
//     }
//   ],
//
//   "latest": [
//     {
//       "title": "Latest Title 1",
//       "blogId": "654",
//       "is_news": true
//     },
//     {
//       "title": "Latest Title 2",
//       "blogId": "321",
//       "is_news": false
//     }
//   ]
// }
// """;


// 'id': fields.Integer,
// 'title':fields.String(attribute='title'),
// 'desc':fields.String(attribute='abstract'),
// 'datetime':fields.String(attribute='create_time'),
// 'author':AuthorName(attribute='author'),
// 'url':fields.Url('hotsearch.hsdetail',absolute=True)#点击响应后去看热搜具体信息 需要前端在title部分做一个超链接访问


class blogShowBrief {
  int? id;
  String? title;
  String? desc;
  String? datetime;
  String? author;
  String? url;

  blogShowBrief(
      {this.id, this.title, this.desc, this.datetime, this.author, this.url});

  blogShowBrief.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    title = json['title'];
    desc = json['desc'];
    datetime = json['datetime'];
    author = json['author'];
    url = json['url'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['title'] = this.title;
    data['desc'] = this.desc;
    data['datetime'] = this.datetime;
    data['author'] = this.author;
    data['url'] = this.url;
    return data;
  }
}

class blogDetailBean {
  int? id;
  String? title;
  String? content;
  String? datetime;
  String? author;
  int? views;
  int? likes;

  blogDetailBean(
      {this.id,
        this.title,
        this.content,
        this.datetime,
        this.author,
        this.views,
        this.likes});

  blogDetailBean.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    title = json['title'];
    content = json['content'];
    datetime = json['datetime'];
    author = json['author'];
    views = json['views'];
    likes = json['likes'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['title'] = this.title;
    data['content'] = this.content;
    data['datetime'] = this.datetime;
    data['author'] = this.author;
    data['views'] = this.views;
    data['likes'] = this.likes;
    return data;
  }
}

class AbstractResponseBean {
  String? abstract;

  AbstractResponseBean({this.abstract});

  AbstractResponseBean.fromJson(Map<String, dynamic> json) {
    abstract = json['abstract'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['abstract'] = this.abstract;
    return data;
  }
}

class TitleResponseBean {
  String? title;

  TitleResponseBean({this.title});

  TitleResponseBean.fromJson(Map<String, dynamic> json) {
    title = json['title'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['title'] = this.title;
    return data;
  }
}



//
//
// class blogBriefListBean {
//   List<BlogBriefItem>? trending;
//   List<BlogBriefItem>? recommendation;
//   List<BlogBriefItem>? latest;
//
//
//   blogBriefListBean({this.trending, this.recommendation, this.latest});
//
//   blogBriefListBean.fromJson(Map<String, dynamic> json) {
//     if (json['trending'] != null) {
//       trending = <BlogBriefItem>[];
//       json['trending'].forEach((v) {
//         trending!.add(new BlogBriefItem.fromJson(v));
//       });
//     }
//     if (json['recommended'] != null) {
//       recommendation = <BlogBriefItem>[];
//       json['recommended'].forEach((v) {
//         recommendation!.add(new BlogBriefItem.fromJson(v));
//       });
//     }
//     if (json['latest'] != null) {
//       latest = <BlogBriefItem>[];
//       json['latest'].forEach((v) {
//         latest!.add(new BlogBriefItem.fromJson(v));
//       });
//     }
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     if (this.trending != null) {
//       data['trending'] = this.trending!.map((v) => v.toJson()).toList();
//     }
//     if (this.recommendation != null) {
//       data['recommended'] = this.recommendation!.map((v) => v.toJson()).toList();
//     }
//     if (this.latest != null) {
//       data['latest'] = this.latest!.map((v) => v.toJson()).toList();
//     }
//     return data;
//   }
// }
//
// class BlogBriefItem {
//   String? title;
//   int? blogId;
//   bool? isNews;
//
//   BlogBriefItem({this.title, this.blogId, this.isNews});
//
//   BlogBriefItem.fromJson(Map<String, dynamic> json) {
//     title = json['title'];
//     blogId = int.parse(json['blogId']);
//     isNews = json['is_news'];
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['title'] = this.title;
//     data['blogId'] = this.blogId.toString();
//     data['is_news'] = this.isNews;
//     return data;
//   }
// }
String mockGroupData='''{
    "groups": [
        {
            "groupName": "Group A",
            "groupId": 1,
            "groupDescription": "This is the description for Group A.",
            "Creator": 1001
        },
        {
            "groupName": "Group B",
            "groupId": 2,
            "groupDescription": "This is the description for Group B.",
            "Creator": 1002
        },
        {
            "groupName": "Group C",
            "groupId": 3,
            "groupDescription": "This is the description for Group C.",
            "Creator": 1003
        },
        {
            "groupName": "Group D",
            "groupId": 4,
            "groupDescription": "This is the description for Group D.",
            "Creator": 1004
        }
    ]
}''';




// class groupList {
//   List<Groups>? groups;
//
//   groupList({this.groups});
//
//   groupList.fromJson(Map<String, dynamic> json) {
//     if (json['groups'] != null) {
//       groups = <Groups>[];
//       json['groups'].forEach((v) {
//         groups!.add(new Groups.fromJson(v));
//       });
//     }
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     if (this.groups != null) {
//       data['groups'] = this.groups!.map((v) => v.toJson()).toList();
//     }
//     return data;
//   }
// }

// class Groups {
//   String? groupName;
//   int? groupId;
//   String? groupDescription;
//   int? creator;
//
//   Groups({this.groupName, this.groupId, this.groupDescription, this.creator});
//
//   Groups.fromJson(Map<String, dynamic> json) {
//     groupName = json['groupName'];
//     groupId = json['groupId'];
//     groupDescription = json['groupDescription'];
//     creator = json['Creator'];
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['groupName'] = this.groupName;
//     data['groupId'] = this.groupId;
//     data['groupDescription'] = this.groupDescription;
//     data['Creator'] = this.creator;
//     return data;
//   }
// }
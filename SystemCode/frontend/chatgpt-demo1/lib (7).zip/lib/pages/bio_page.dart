import 'dart:typed_data';
import 'package:chatgpt/pages/group_info_dialog.dart';
import 'package:chatgpt/utils/color_setting.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../utils/dio_util.dart';
import '../utils/userBean.dart';
import 'blog_page.dart';

class BioPage extends StatefulWidget {
  const BioPage({Key? key, required this.userItem, required this.userDataChange}) : super(key: key);

  final userBean userItem;
  final Function(userBean) userDataChange;
  @override
  State<BioPage> createState() => _BioPageState();
}

class _BioPageState extends State<BioPage> {
  // 在顶层定义一个全局的 GlobalKey 用于访问 ScaffoldState
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  late userBean newUserItem;
  bool preferencesSelected = false; // 存储选择状态
  Set<String> _selectedPreferences = Set<String>();
  bool _isSaving = false; // 用于跟踪是否正在保存选项

  TextEditingController textEditingController = TextEditingController();

  @override
  void initState() {
    super.initState();
    newUserItem = widget.userItem;
    print("biopage init!!!!");
  }

  late bool showLoading = false;
  late Uint8List recording;

  final _transcriptionController = TextEditingController();
  final tokenTextController = TextEditingController();
  final groupIdInputController = TextEditingController();
  final groupDescriptionController = TextEditingController();
  final groupNameController = TextEditingController();

// Recording variables
  bool isRecording = false;
  Color textColor = Color(0xFFEEEEEE);
  Color buttonColor = MyColor.deepBlue;
  Color backgroundColor = MyColor.orange;


  @override
  Widget build(BuildContext context) {
    //User user = getUserFromBackend();
    return Scaffold(
      body: SingleChildScrollView(
        reverse: true,
        child: Column(
            children: [
              Container(
                //width: MediaQuery.of(context).size.width, // 设置 Container 的宽度
                width: 400,
                height: MediaQuery
                    .of(context)
                    .size
                    .height, // 设置 Container 的高度
                color: Colors.white, // 设置 Container 的颜色
                child: Stack(
                  alignment: Alignment.topLeft,
                  children: [
                    Image.asset(
                      'assets/images/lion_background.png',
                      //fit: BoxFit.contain,
                      fit: BoxFit.fill,
                      width: MediaQuery
                          .of(context)
                          .size
                          .width,

                      height: MediaQuery
                          .of(context)
                          .size
                          .height / 2,
                    ),

                    Positioned(
                      top: 250,
                      left: 0,
                      child: Column(
                          children: [
                            Container(width: MediaQuery.of(context).size.width,),
                            Text(
                              // "Hello, Jerry",
                              "Hi, ${widget.userItem.userNickName}", // 使用用户数据模型的属性替代固定的名字
                              style: TextStyle(
                                fontSize: 50,
                                color: buttonColor,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'CustomFont',
                              ),
                              textAlign: TextAlign.start, // 文本水平居中
                            ),

                            Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    primary: buttonColor, // 设置背景颜色
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(
                                          20), // 设置圆角半径
                                    ),
                                  ),
                                  child: Container(
                                    // padding: EdgeInsets.all(10),
                                    // margin: EdgeInsets.all(10),
                                    decoration: BoxDecoration(
                                      color: buttonColor, // 设置背景颜色
                                      border: Border.all(
                                        color: buttonColor, // 框的边框颜色
                                        width: 2, // 边框宽度
                                      ),
                                      borderRadius: BorderRadius.circular(
                                          20), // 设置圆角半径
                                    ),
                                    child: Text(
                                      "manage your token",
                                      //"${user.gender}",
                                      style: TextStyle(
                                        fontSize: 16,
                                        color: Colors.white, // 文本颜色
                                      ),
                                    ),
                                  ),
                                  onPressed: () async {
                                    String? key =  (await getTokenKey());
                                    if(key==null){
                                      tokenTextController.text = "";
                                    }else{
                                      tokenTextController.text = (await getTokenKey())!;
                                    }
                                    openLLMTokenDialog();
                                  },
                                ),


                                ElevatedButton(
                                  onPressed: () {
                                    _showMultiSelectionDialog(context);
                                  },
                                  style: ElevatedButton.styleFrom(
                                    primary: buttonColor, // 设置背景颜色
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(
                                          20), // 设置圆角半径
                                    ),
                                  ),
                                  child: Text(
                                    "Set the Preferences",
                                    style: TextStyle(
                                      fontSize: 16,
                                      color: Colors.white,
                                    ),
                                  ),
                                )
                              ],
                            )
                          ]
                      ),
                    ),

                    Positioned(
                      bottom: 0, // 调整位置以适应你的需要
                      left: 0, // 调整位置以适应你的需要
                      child: Container(
                        //width:MediaQuery.of(context).size.width,
                        width: 400, //
                        height: MediaQuery
                            .of(context)
                            .size
                            .height / 2,
                        color: backgroundColor, // 背景颜色
                        child: DefaultTabController(
                          length: 2, // 标签数量，根据您的需求更改
                          child: Column(
                            children: [
                              TabBar(
                                indicatorColor: MyColor.grey,
                                tabs: [
                                  Tab(child: Text(
                                    'History',
                                    style: TextStyle(fontSize: 18), // 设置字体大小
                                  ),
                                  ),

                                  Tab(child: Text(
                                    'Group',
                                    style: TextStyle(fontSize: 18), // 设置字体大小
                                  ),),
                                ],
                              ),
                              Expanded(
                                child: TabBarView(
                                  children: [
                                    // 第一个选项卡的内容
                                    Center(
                                      //child: Text('History Content'),
                                      child: ListView.builder(
                                        //itemCount: historyList.length, // 历史内容的数量
                                        itemCount: newUserItem.userPastBlog?.length == 0?0:newUserItem.userPastBlog?.length,
                                        itemBuilder: (BuildContext context,
                                            int index) {
                                          return GestureDetector(
                                              onTap: () {
                                                print("!!!tapped");
                                                _openBlogPage(newUserItem.userPastBlog![index].blogId!, newUserItem.userPastBlog![index].title!);
                                                // 在此处处理文本框点击事件，导航到详情页
                                              },
                                              child: Container(
                                                width: double.infinity,
                                                // 撑满屏幕宽度
                                                padding: EdgeInsets.all(10),
                                                // 方框的内边距
                                                margin: EdgeInsets.symmetric(
                                                    vertical: 10),
                                                // 方框之间的垂直间距
                                                decoration: BoxDecoration(
                                                  border: Border.all(
                                                      color: Colors.white), // 方框的边框
                                                  borderRadius: BorderRadius
                                                      .circular(10), // 方框的圆角
                                                ),
                                                child: Text(
                                                  //historyList[index], // 根据索引获取历史内容
                                                  newUserItem.userPastBlog![index].title != null?newUserItem.userPastBlog![index].title!:"load error",
                                                  style: TextStyle(
                                                    fontSize: 18,
                                                    color: textColor,
                                                  ),
                                                  maxLines: 1, // 显示一行文本
                                                  overflow: TextOverflow.ellipsis, // 使用省略号代替溢出的文本
                                                ),
                                              )
                                          );
                                        },
                                      ),
                                    ),
                                    // 第二个选项卡的内容
                                    Center(
                                      //child: Text('Group Content'),
                                      child: SingleChildScrollView(
                                        child: Column(
                                          mainAxisAlignment: MainAxisAlignment
                                              .start,
                                          children: [
                                            // Wrap(
                                            //   alignment: WrapAlignment.start,
                                            //   // 从顶部左侧开始排列
                                            //   spacing: 10,
                                            //   // 设置按钮之间的水平间距
                                            //   runSpacing: 10,
                                            //   // 设置按钮之间的垂直间距
                                            //   children: [
                                            //     //for (int i = 0; i < groupList.length; i++)
                                            //
                                            //     // for (int i = 0; i < newUserItem.userGroupList!.length; i++)
                                            //     //   ElevatedButton(
                                            //     //     style: ElevatedButton
                                            //     //         .styleFrom(
                                            //     //       primary: buttonColor,
                                            //     //       // 设置按钮的背景颜色
                                            //     //       fixedSize: Size(
                                            //     //           150, 50), // 设置按钮的大小
                                            //     //     ),
                                            //     //     child: Text(
                                            //     //       newUserItem.userGroupList![i].groupName!,
                                            //     //       style: TextStyle(
                                            //     //         fontSize: 24, // 设置文本大小
                                            //     //         color: Colors
                                            //     //             .white, // 设置文本颜色
                                            //     //       ),
                                            //     //       overflow: TextOverflow
                                            //     //           .ellipsis,
                                            //     //       // 在文本过长时显示省略号
                                            //     //       maxLines: 1, // 设置最大行数为1
                                            //     //     ),
                                            //     //     onPressed: () {
                                            //     //       _showGroupInfoDialog(context, newUserItem.userGroupList![i].groupId!);// 处理按钮按下事件
                                            //     //     },
                                            //     //   ),
                                            //
                                            //     ElevatedButton(
                                            //       style: ElevatedButton
                                            //           .styleFrom(
                                            //         primary:buttonColor,
                                            //         // 设置按钮的背景颜色
                                            //         fixedSize: Size(
                                            //             150, 50), // 设置按钮的大小
                                            //       ),
                                            //       child: Icon(
                                            //         Icons.add, // 使用添加图标
                                            //         size: 24, // 设置图标大小
                                            //         color: Colors
                                            //             .white, // 设置图标颜色
                                            //       ),
                                            //       onPressed: () {
                                            //         openAddGroupDialog();
                                            //         setState(() {
                                            //           // newUserItem. = 777;
                                            //           widget.userDataChange(newUserItem);
                                            //         });
                                            //         print("add!!!!!");
                                            //         print(widget.userItem.userID);
                                            //         // 处理添加按钮按下事件，添加新的 group
                                            //         // 处理添加按钮按下事件，添加新ad的 group
                                            //       },
                                            //     ),
                                            //   ],
                                            // ),

                                        newUserItem.userGroupList != null && newUserItem.userGroupList!.isNotEmpty
                                          ? Wrap(
                                          spacing: 8.0, // space between adjacent chips
                                          runSpacing: 4.0, // space between lines
                                          children: List<Widget>.generate(
                                            newUserItem.userGroupList!.length+1,
                                                (i) => i<newUserItem.userGroupList!.length?ElevatedButton(
                                              style: ElevatedButton.styleFrom(
                                                primary: buttonColor, // Set the background color of the button
                                                fixedSize: Size(150, 50), // Set the size of the button
                                              ),
                                              child: Text(
                                                newUserItem.userGroupList![i].groupName ?? 'Default Group Name',
                                                style: TextStyle(
                                                  fontSize: 24, // Set the text size
                                                  color: Colors.white, // Set the text color
                                                ),
                                                overflow: TextOverflow.ellipsis, // Show ellipsis when text is too long
                                                maxLines: 1, // Set max lines to 1
                                              ),
                                              onPressed: () {
                                                _showGroupInfoDialog(context, newUserItem.userGroupList![i].groupId!);
                                              },
                                            ):
                                                ElevatedButton(
                                                        style: ElevatedButton
                                                            .styleFrom(
                                                          primary:buttonColor,
                                                          // 设置按钮的背景颜色
                                                          fixedSize: Size(
                                                              150, 50), // 设置按钮的大小
                                                        ),
                                                        child: Icon(
                                                          Icons.add, // 使用添加图标
                                                          size: 24, // 设置图标大小
                                                          color: Colors
                                                              .white, // 设置图标颜色
                                                        ),
                                                        onPressed: () {
                                                          openAddGroupDialog();
                                                          setState(() {
                                                            // newUserItem. = 777;
                                                            widget.userDataChange(newUserItem);
                                                          });
                                                          print("add!!!!!");
                                                          print(widget.userItem.userID);
                                                          // 处理添加按钮按下事件，添加新的 group
                                                          // 处理添加按钮按下事件，添加新ad的 group
                                                        },
                                                      ),

                                          ),
                                        )
                                              :
                                            Wrap(
                                              alignment: WrapAlignment.start,
                                              // 从顶部左侧开始排列
                                              spacing: 10,
                                              // 设置按钮之间的水平间距
                                              runSpacing: 10,
                                              // 设置按钮之间的垂直间距
                                              children: [
                                                ElevatedButton(
                                                  style: ElevatedButton
                                                      .styleFrom(
                                                    primary:buttonColor,
                                                    // 设置按钮的背景颜色
                                                    fixedSize: Size(
                                                        150, 50), // 设置按钮的大小
                                                  ),
                                                  child: Icon(
                                                    Icons.add, // 使用添加图标
                                                    size: 24, // 设置图标大小
                                                    color: Colors
                                                        .white, // 设置图标颜色
                                                  ),
                                                  onPressed: () {
                                                    openAddGroupDialog();
                                                    setState(() {
                                                      // newUserItem. = 777;
                                                      widget.userDataChange(newUserItem);
                                                    });
                                                    print("add!!!!!");
                                                    print(widget.userItem.userID);
                                                    // 处理添加按钮按下事件，添加新的 group
                                                    // 处理添加按钮按下事件，添加新ad的 group
                                                  },
                                                ),
                                              ],
                                            ),
                                      ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ]
        ),
      ),
    );
  }
// 点击 "Group" 按钮的处理函数
  Future<void> _showGroupInfoDialog(BuildContext context, int groupId) async {
    // GroupItem groupItem = GroupItem();
    showDialog(
      context: context,
      builder: (context) => GroupInfoDialog(groupId: groupId,),
    );
  }

  void openLLMTokenDialog(){
    showDialog(
        context: context,
        builder: (context){
          return AlertDialog(
            title: Text("token stored"),
            content:Container(
              height: 150,
              child: Column(
                children: [
                  Text("Put your openAI token key here to activate the chatbot function",
                    style: TextStyle(
                      fontSize: 15,
                      color: MyColor.orange,
                    ),
                  ),
                  Container(
                    child: TextField(
                      controller: tokenTextController,
                      decoration: InputDecoration(
                        hintText: 'Enter your openai token here',
                        enabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: MyColor.orange, width: 2),
                          borderRadius: BorderRadius.all(Radius.circular(8.0)), // 设置边框的圆角
                        ),
                        focusedBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: MyColor.orange, width: 5),
                          borderRadius: BorderRadius.all(Radius.circular(8.0)), // 设置边框的圆角
                        ),
                      ),
                      maxLines: 1,
                    ),
                  ),
                  Text("note: We are not going to upload you API key online, it will only be accessed and implimented locally on your device",
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey,
                    ),
                  ),
                ],
              ),
            ),
            actions: [
              TextButton(
                child: Text(
                  "Save",
                  style: TextStyle(
                    fontSize: 16,
                    color: MyColor.orange, // 文本颜色
                  ),
                ),
                onPressed: () {
                  final inputText = tokenTextController.text;
                  saveTokenKey(inputText);
                  newUserItem.llmToken = inputText;
                  widget.userDataChange(newUserItem);
                  Navigator.pop(context);
                },
              ),
            ],
          );
        }
    );
  }

  void openAddGroupDialog(){
    showDialog(
        context: context,
        builder: (context){
          return AlertDialog(
            title: Text("Input group id"),
            content:Container(
              // color: Colors.cyan,
              height: 150,
              child: Column(
                children: [
                  Container(
                    child: TextField(
                      controller: groupIdInputController,
                      decoration: InputDecoration(
                        hintText: 'Enter id of group you wish to join',
                        enabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: MyColor.orange, width: 2),
                          borderRadius: BorderRadius.all(Radius.circular(8.0)), // 设置边框的圆角
                        ),
                        focusedBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: MyColor.orange, width: 5),
                          borderRadius: BorderRadius.all(Radius.circular(8.0)), // 设置边框的圆角
                        ),
                      ),
                      maxLines: 1,
                    ),
                  ),
                  Container(
                    child: Row(
                      children: [
                        TextButton(
                          child: Text(
                            "Create a group",
                            style: TextStyle(
                              fontSize: 13,
                              color: MyColor.orange, // 文本颜色
                            ),
                          ),
                          onPressed: () {
                            openCreateGroupDialog();
                            // Navigator.pop(context);
                          },
                        ),
                      ],
                    ),
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width/2,
                    child: ElevatedButton(
                      style: ButtonStyle(
                        backgroundColor: MaterialStateProperty.all<Color>(MyColor.orange),
                      ),
                      onPressed: () async {
                        Map<String, dynamic> addInfo = {
                          "groupid": groupIdInputController.text,
                          "userid": widget.userItem.userID!,
                        };

                        GroupItem gpItem = new GroupItem(groupId: 1, groupDescription: "description", groupName: "name",);
                        newUserItem.userGroupList?.add(gpItem);
                        widget.userDataChange(newUserItem);

                        setState(() {

                        });

                        try{
                          await DioUtil.addToGroup(addInfo).then((value){
                            // showLoading=false;
                            if (value.resultStatus == 200) {
                              print("groupinfo added!!!");
                              print(value.data);

                              String groupName = "groupName";
                              GroupItem gpItem = GroupItem.fromJson(value.data);
                              newUserItem.userGroupList?.add(gpItem);
                              widget.userDataChange(newUserItem);

                              setState(() {

                              });
                            } else if (value.resultStatus == 201) {
                            } else if (value.resultStatus == 202) {
                            } else {}
                          });
                        } on DioError catch(e) {
                        } finally {
                        }
                      },
                      // textColor: Colors.white,
                      child: const Text("join group"),
                    ),
                  )
                ],
              ),
            ),
            actions: [
              TextButton(
                child: Text(
                  "Close",
                  style: TextStyle(
                    fontSize: 16,
                    color: MyColor.orange, // 文本颜色
                  ),
                ),
                onPressed: () {
                  // 关闭对话框
                  Navigator.pop(context);
                },
              ),
            ],
          );
        }
    );
  }

  ///need to add^^^^^
  void openCreateGroupDialog(){
    showDialog(
        context: context,
        builder: (context){
          return AlertDialog(
            title: Text("creating group"),
            content:Container(
              height: 330,
              child: SingleChildScrollView(
                child: Column(
                  children: [

                    Row(
                      children: [
                        Positioned(
                          // right: 100 + 10,
                          // top: 25 + 30,
                          child: InkWell(
                            child: Container(
                              decoration: BoxDecoration(
                                color: buttonColor, // 设置背景颜色
                                border: Border.all(
                                  color: buttonColor, // 框的边框颜色
                                  width: 2, // 边框宽度
                                ),
                                borderRadius: BorderRadius.circular(20), // 设置圆角半径
                              ),
                              // color: Colors.amber,
                              width: 180,
                              height: 70,
                              child: Container(
                                padding: const EdgeInsets.all(12.0),
                                child: Text(
                                  'can not wait to see what you gonna say!',
                                  style: TextStyle(color: MyColor.orange,
                                    fontSize: 12,
                                  ),
                                ),
                              ),
                            ),
                            onTap: (){

                            },
                          ),
                        ),

                        SizedBox(width: 10,),
                        Positioned(
                          // right: 0,
                          // top: 30,
                          child: InkWell(
                            child: Container(
                              // color: Colors.amber,
                              width: 70,
                              height: 70,
                              child: Container(
                                  child: InkWell(
                                    child: Image.asset(
                                      'assets/images/lion_cute.png',
                                      fit: BoxFit.fill,
                                      // width: moveWidgetHeight,
                                    ),
                                  )),
                            ),
                            onTap: () {
                              Navigator.of(context).pop();
                            },
                          ),
                        ),
                      ],
                    ),
                    Container(

                      child: TextField(
                        controller: groupNameController,
                        decoration: InputDecoration(
                          hintText: 'Group name',
                          enabledBorder: UnderlineInputBorder(
                            borderSide: BorderSide(color: MyColor.orange, width: 2),
                            borderRadius: BorderRadius.all(Radius.circular(8.0)), // 设置边框的圆角
                          ),
                          focusedBorder: UnderlineInputBorder(
                            borderSide: BorderSide(color: MyColor.orange, width: 5),
                            borderRadius: BorderRadius.all(Radius.circular(8.0)), // 设置边框的圆角
                          ),
                        ),
                        maxLines: 1,
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),

                    TextField(
                      minLines: 3,
                      decoration: const InputDecoration(
                        hintText: 'Group description',
                        enabledBorder: OutlineInputBorder(
                          borderSide:
                          BorderSide(color: MyColor.orange, width: 1.5),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                              color: MyColor.orange,
                              width: 3), // Underline color when focused
                        ),
                      ),
                      maxLines: null,
                      controller: groupDescriptionController,
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width/2,
                      child: ElevatedButton(
                        style: ButtonStyle(
                          backgroundColor: MaterialStateProperty.all<Color>(MyColor.orange),
                        ),
                        onPressed: () async {
                          Map<String, dynamic> addInfo = {
                            "userid": widget.userItem.userID!,
                            "group_name": groupNameController.text,
                            "group_description": groupDescriptionController.text,
                          };

                          try{
                            await DioUtil.createGroup(addInfo).then((value){
                              // showLoading=false;
                              if (value.resultStatus == 200) {
                                print("groupinfo added!!!");
                                print(value.data);
                                GroupItem gpItem = GroupItem.fromJson(value.data);
                                newUserItem.userGroupList?.add(gpItem);
                                widget.userDataChange(newUserItem);
                                setState(() {

                                });
                              } else if (value.resultStatus == 201) {

                              } else if (value.resultStatus == 202) {

                              } else {}
                            });
                          } on DioError catch(e) {

                          } finally {
                          }
                        },
                        // textColor: Colors.white,
                        child: Text("Create group"),
                      ),
                    )
                  ],
                ),
              )
            ),
            actions: [
              TextButton(
                child: Text(
                  "Close",
                  style: TextStyle(
                    fontSize: 16,
                    color: MyColor.orange, // 文本颜色
                  ),
                ),
                onPressed: () {
                  // 关闭对话框
                  Navigator.pop(context);
                },
              ),
            ],
          );
        }
    );
  }


  // 显示多选项对话框
  Future<void> _showMultiSelectionDialog(BuildContext context) async {
    final List<String> availablePreferences = [
      'Sport',
      'Animation',
      'Dance',
      'Music',
      'Game'
    ]; // 可选的选项列表

    final selectedPreferences = await showDialog<Set<String>>(
      context: context,
      builder: (BuildContext context) {
        Set<String> tempSelectedPreferences = Set<String>.from(_selectedPreferences); // 创建临时集合保存用户的更改

        return AlertDialog(
          title: Text(
            "manage your token",
            //"${user.gender}",
            style: TextStyle(
              fontSize: 16,
              color: MyColor.deepBlue, // 文本颜色
            ),
          ),
          content: SingleChildScrollView(
            child: Column(
              children: availablePreferences.map((String preference) {
                final bool isChecked = tempSelectedPreferences.contains(
                    preference);

                return CheckboxListTile(
                  title: Text(preference),
                  value: tempSelectedPreferences.contains(preference),
                  onChanged: (bool? value) {
                    _handlePreferenceSelection(preference, value, tempSelectedPreferences);
                  },
                );
              }).toList(),
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(null); // 关闭对话框，返回空值
              },
              child: Text(
                "Cancel",
                style: TextStyle(
                  fontSize: 16,
                  color: MyColor.orange, // 文本颜色
                ),
              ),
            ),
            TextButton(
              // style: ButtonStyle(
              //     // foregroundColor: MaterialStateProperty.all<Color>(Colors.blue),
              //     textStyle: MaterialStateProperty.all<TextStyle>(
              //         TextStyle(fontSize: 16, color: MyColor.orange)
              //     )
              // ),
              onPressed: () {
                // 用户点击 "保存" 按钮时，设置 _isSaving 为 true
                _isSaving = true;
                Navigator.of(context).pop(tempSelectedPreferences); // 关闭对话框，返回所选选项
              },
              child:Text(
                "Save",
                style: TextStyle(
                  fontSize: 16,
                  color: MyColor.orange, // 文本颜色
                ),
              ),
            ),
          ],
        );
      },
    );

    if (selectedPreferences != null) {
      // 如果用户点击了 "保存"，将所选选项保存到状态变量中
      setState(() {
        _selectedPreferences = selectedPreferences;
        this.preferencesSelected = selectedPreferences.isNotEmpty;
      });
    }
    // 用户点击 "取消" 或 "保存" 后，将 _isSaving 重置为 false
    _isSaving = false;
  }
  // 处理选项选择
  void _handlePreferenceSelection(String preference, bool? value, Set<String> tempSelectedPreferences) {
    if (value != null) {
      setState(() {
        if (value) {
          tempSelectedPreferences.add(preference);
        } else {
          tempSelectedPreferences.remove(preference);
        }
      });
    }
  }

  void _openBlogPage(int id, String title) {
    print("tapped!!!");
    ///add net connection later
    Navigator.of(context).push(
      MaterialPageRoute(
        // builder: (context) => CatCardPage2(systemStr: textEditingController.text.isEmpty?system:textEditingController.text,),
        builder: (context) => BlogPage(blogTitle: title,blogId: id,),
      ),
    );
  }


}

Future<void> saveTokenKey(String token) async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  if(token==''){
    token = "sk-";
  }
  await prefs.setString('LLM-key', token);
}

// 获取token
Future<String?> getTokenKey() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  String? token = prefs.getString('LLM-key');
  if(token==''){
    token = "sk-";
  }
  return token;
}

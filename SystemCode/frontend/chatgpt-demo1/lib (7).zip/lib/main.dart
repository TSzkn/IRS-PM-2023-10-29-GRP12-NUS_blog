import 'dart:convert';

import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:chatgpt/pages/chatbot_page.dart';
import 'package:chatgpt/pages/login.dart';
import 'package:chatgpt/pages/main_page_controller.dart';
import 'package:chatgpt/utils/color_setting.dart';
import 'package:chatgpt/utils/dio_util.dart';
import 'package:chatgpt/utils/userBean.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_keyboard_visibility/flutter_keyboard_visibility.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:shared_preferences/shared_preferences.dart';

// 保存token

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp])
      .then((_) {
    runApp(new MyApp());
  });
  // runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  // HttpOverrides.global = MyHttpOverrides();
  const MyApp({super.key});



  @override
  Widget build(BuildContext context) {
    return KeyboardVisibilityProvider(
      child: MaterialApp(
        title: 'NUS Demo',
        theme: ThemeData(
          primarySwatch: createMaterialColor(Color(0xFF002266)),
        ),
        home: const MyHomePage(title: 'Flutter Demo Home Page'),
      ),
    );
  }
}
final wsUrl = Uri.parse('ws://192.168.31.171:8081/websocket?token=token-123456');
var channel;
class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}
final viewInsets = EdgeInsets.fromWindowPadding(WidgetsBinding.instance.window.viewInsets,WidgetsBinding.instance.window.devicePixelRatio);

class _MyHomePageState extends State<MyHomePage> {

  String? _token;
  int loginStatus = 0;
  late userBean userItem;
  @override
  void initState()  {
    super.initState();
    print("init!!!!!");
    _loadToken();

    verifyToken();
    // String? token = getToken();
    // if token not getting
    if(loginStatus == 1) {
      // loginStatus = 1;
      ///get user info from backend
      fetchUser(123);



    }else{
      // loginStatus = 0;
    }
    // getTokenfromBackEnd()
    // String? token = storage.readToken();
    // _speech = stt.SpeechToText();
  }


  @override
  Widget build(BuildContext context) {
    final bool isKeyboardVisible = KeyboardVisibilityProvider.isKeyboardVisible(context);
    // Navigator.of(context).push(
    //   MaterialPageRoute(
    //     // builder: (context) => CatCardPage2(systemStr: textEditingController.text.isEmpty?system:textEditingController.text,),
    //     builder: (context) => LoginRoute(),
    //   ),
    // );
    // return ();

    return loginStatus==1? MyPageController(user: userItem,):LoginRoute();
    // return loginStatus==1? MyPageController():LoginRoute();

  }

  Future<void> _loadToken() async {
    String? token = await getLoginStatusToken();
    setState(() {
      _token = token;
      if(token!=null){
        print(token);
        saveLoginStatusToken('token-hello');
      }else{
        print("tokenNull");
        saveLoginStatusToken('token-hello');
      }
    });
  }

  Future<void> verifyToken() async {
    loginStatus = 0;
    // SharedPreferences prefs = await SharedPreferences.getInstance();
    // return 1;
  }

  Future<void> fetchUser(int userId) async {
    ///!!!!!!
    var user = new userBean();
    user.userID = userId;
    // user.llmToken = await getTokenKey();
    // user.userGroupList = await fetchGroupList(userId);
    // user.userPastBlog = await fetchPastBlogList(userId);
    userItem = user;
  }
}

Future<void> saveLoginStatusToken(String token) async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  await prefs.setString('loginStatusToken', token);
}

// 获取token
Future<String?> getLoginStatusToken() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  return prefs.getString('loginStatusToken');
}


MaterialColor createMaterialColor(Color color) {
  List strengths = <double>[.05];
  final swatch = <int, Color>{};
  final int r = color.red, g = color.green, b = color.blue;

  for (int i = 1; i < 10; i++) strengths.add(0.1 * i);
  strengths.forEach((strength) {
    final double ds = 0.5 - strength;
    swatch[(strength * 1000).round()] = Color.fromRGBO(
      r + ((ds < 0 ? r : (255 - r)) * ds).toInt(),
      g + ((ds < 0 ? g : (255 - g)) * ds).toInt(),
      b + ((ds < 0 ? b : (255 - b)) * ds).toInt(),
      1,
    );
  });
  return MaterialColor(color.value, swatch);
}






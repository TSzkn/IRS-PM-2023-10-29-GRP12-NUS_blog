
// import 'package:chatgpt/pages/trending_page.dart';
// import 'package:flutter/material.dart';
//
// import 'chatbot_page.dart';
// import 'login.dart';
//
//
// class MyPageController extends StatefulWidget {
//   const MyPageController({
//     Key? key,
//   }) : super(key: key);
//
//
//   @override
//   _MyPageControllerState createState() => _MyPageControllerState();
// }
//
// class _MyPageControllerState extends State<MyPageController> {
//   final PageController _pageController = PageController(initialPage: 1);
//
//   @override
//   void initState() {
//     // Navigator.of(context).push(
//     //   MaterialPageRoute(
//     //     // builder: (context) => CatCardPage2(systemStr: textEditingController.text.isEmpty?system:textEditingController.text,),
//     //     builder: (context) => LoginRoute(),
//     //   ),
//     // );
//
//     super.initState();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     // var children = <Widget>[];
//     // // 生成 6 个 Tab 页
//     // for (int i = 0; i < 6; ++i) {
//     //   children.add( MyPageController( child:  ));
//     // }
//
//     return
//       WillPopScope(
//           onWillPop: () async => false,
//           child:       PageView(
//             controller: _pageController,
//             // scrollDirection: Axis.vertical, // 滑动方向为垂直方向
//             children: [
//
//               StartPlayPage(),
//               CatCardPage2(),
//               TrendingPage(),
//               // StartPlayPage()
//             ],
//           ),
//       );
//
//   }
// }
//
//
//


import 'dart:math';
import 'dart:ui';

import 'package:chatgpt/pages/send_blog.dart';
import 'package:chatgpt/pages/trending_page.dart';
import 'package:cube_transition_plus/cube_transition_plus.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../utils/userBean.dart';
import 'bio_page.dart';
import 'chatbot_page.dart';


class DataModel extends ChangeNotifier {
  String data = '';

  void updateData(String newData) {
    data = newData;
    notifyListeners();
  }
}

class MyPageController extends StatelessWidget {
  MyPageController({required this.user});

  final bgColor = Colors.orange;
  late userBean user;

  Widget build(BuildContext context) {

    // print("")
    // print("user!!!!");
    // print(user.userID);

    final height = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor:bgColor,
      // appBar: AppBar(
      //   title: Text('Custom Cube Transition'),
      // ),
      body:
            WillPopScope(
          onWillPop: () async => false,
      child: Center(
        child: SizedBox(
          height: height,
          child: CubePageView.builder(
            itemCount: 3,
            startPage:1,
            onPageChanged:(index){
              print("changed!!!!");

              },
            // controller: PageController(initialPage: 1),

            itemBuilder: (context, index, notifier) {
              // final item = places[index];
              final transform = Matrix4.identity();
              final t = (index - notifier).abs();
              final scale = lerpDouble(1.5, 0, t);

              double startPositionLeft = 300;
              double startPositionTop = 30;

              double moveWidgetWidth = 100;
              double moveWidgetHeight = 100;
              transform.scale(scale, scale);
              return CubeWidget(
                index: index,
                pageNotifier: notifier,
                child: Stack(
                  children: [
                    // Container(width: 100,height: 100,color: Colors.cyan,),

                // final List<Widget> majorPages = [
                // BioPage(userItem: user),
                //   CatCardPage2(),
                //   TrendingPage(),];

                    // majorPages[index],
                    index==0?BioPage(userItem: user, userDataChange: onUserDataChange,):
                      index==1?ChatBotPage(userItem: user, userDataChange: onUserDataChange,):
                        TrendingPage(userItem: user, userDataChange: onUserDataChange),


                    (notifier-index)<=0?
                    Positioned(
                      // left: (notifier-index)<0.5?startPosition+(notifier-index)*300*2:startPosition+(notifier-index-0.5)*100,
                      left: startPositionLeft+(notifier-index)*(startPositionLeft+100),
                      top: startPositionTop,
                      child: Transform.rotate(
                        //旋转90度
                        angle: 2*pi* (notifier-index),
                        child:  InkWell(
                          child:  Container(
                            // color: Colors.amber,
                            width: moveWidgetWidth,
                            height: moveWidgetHeight,
                            child: Container(
                              child:notifier-index==0? Image.asset('assets/images/lion_cute.png',
                                fit: BoxFit.fill,
                                width: moveWidgetHeight,
                              ):Image.asset('assets/images/lion_laugh.png',
                                fit: BoxFit.fill,
                                width: moveWidgetHeight,
                              ),
                            ),
                          ),
                          onTap: (){
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (context) => PostSendPage(userItem: user, userDataChange: onUserDataChange),
                              ),
                            );
                          },
                        ),
                      ),

                    ):Container(),
                    (notifier-index)>0?
                    Positioned(
                      // left: (notifier-index)<0.5?startPosition+(notifier-index)*300*2:startPosition+(notifier-index-0.5)*100,
                        left: startPositionLeft+(notifier-index)*(startPositionLeft+100),
                        top: startPositionTop,
                        child: Transform.rotate(
                          angle: 2*pi* (notifier-index),
                          child:InkWell(
                            child: Container(
                              // color: Colors.amber,
                              width: moveWidgetWidth,
                              height: moveWidgetHeight,
                              child: Container(
                                child: Image.asset('assets/images/lion_laugh.png',
                                  fit: BoxFit.fill,
                                  width: 100,
                                ),
                              ),
                            ),
                            onTap: (){

                            },
                          ),
                        )
                    ):Container(),
                    Transform(
                      alignment: Alignment.center,
                      transform: transform,
                      child: Container(),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    ),
    );
  }
  void onUserDataChange(userBean newData) {
    user = newData;
    // setState(() => );
  }
}


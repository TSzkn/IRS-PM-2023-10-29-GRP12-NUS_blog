// import 'dart:convert';
// import 'dart:typed_data';
//
// import 'package:chatgpt/pages/--.dart';
// import 'package:chatgpt/pages/chatbot_page.dart';
// import 'package:chatgpt/utils/datas.dart';
// import 'package:flutter/material.dart';
// // import 'package:flutter_sound/public/flutter_sound_recorder.dart';
// import 'package:http/http.dart' as http;
// import 'package:microphone/microphone.dart';
// import 'package:permission_handler/permission_handler.dart';
//
// class StartPlayPage extends StatefulWidget {
//   const StartPlayPage({Key? key}) : super(key: key);
//
//   @override
//   State<StartPlayPage> createState() => _StartPlayPageState();
// }
//
// class _StartPlayPageState extends State<StartPlayPage> {
//   TextEditingController textEditingController=TextEditingController();
//   late String systemSetting2 = "lol";
//   late bool showLoading = false;
//   late Uint8List recording;
//
//
//   final _transcriptionController = TextEditingController();
// // Recording variables
//   FlutterSoundRecorder? _recorder;
//   bool isRecording = false;
//
//   // FlutterSoundRecorder _recordingSession;
//   // final recordingPlayer = AssetsAudioPlayer();
//   // String pathToAudio;
//   // bool _playAudio = false;
//   // String _timerText = '00:00:00';
//
//
//
//
//   Future _startRecording() async {
//
//     print("!!!recording true");
//     _recorder = FlutterSoundRecorder();
//     await _recorder!.openAudioSession();
//
//     isRecording = true;
//     setState(() {
//
//     });
//     await _recorder!.startRecorder();
//     print("finish starting!!!");
//   }
//
//   Future _stopRecording() async {
//     await _recorder!.stopRecorder();
//
//     _recorder!.closeAudioSession();
//
//     isRecording = false;
//     print("!!!recording false");
//   }
//
//   Future _transcribeAudio() async {
//     // Encode audio to base64
//     String audio64 = base64Encode(recording);
//
//     // Call Whisper API
//     var url = Uri.parse("https://api.openai.com/v1/audio/transcriptions");
//
//     var response = await http.post(url, headers: {
//       "Authorization": "Bearer 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"
//     }, body: {
//       "audio": audio64,
//       "model": "whisper-1"
//     });
//
//     // Get transcription and update text field
//     var transcription = jsonDecode(response.body)['text'];
//     _transcriptionController.text = transcription;
//     setState(() {
//
//     });
//   }
//
//   void initState() {
//     super.initState();
//     initializer();
//   }
//   void initializer() async {
//     print("!!!init");
//     // pathToAudio = '/sdcard/Download/temp.wav';
//     // _recordingSession = FlutterSoundRecorder();
//     // await _recordingSession.openAudioSession(
//     //     focus: AudioFocus.requestFocusAndStopOthers,
//     //     category: SessionCategory.playAndRecord,
//     //     mode: SessionMode.modeDefault,
//     //     device: AudioDevice.speaker);
//     // await _recordingSession.setSubscriptionDuration(Duration(milliseconds: 10));
//     // await initializeDateFormatting();
//     await Permission.microphone.request();
//     await Permission.storage.request();
//     await Permission.manageExternalStorage.request();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Padding(
//         padding: const EdgeInsets.all(8.0),
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             IconButton(
//               onPressed: () async {
//                 if (!isRecording) {
//                   await _startRecording();
//                 } else {
//                   print("!!!activate false");
//                   await _stopRecording();
//                   await _transcribeAudio();
//                 }
//               },
//               icon: isRecording ? Icon(Icons.stop) : Icon(Icons.add),
//             ),
//             TextField(
//               maxLines: null,
//               controller: textEditingController,
//               decoration: InputDecoration(
//                   hintText: _transcriptionController.text
//               ),
//             )
//           ],
//         ),
//       ),
//       floatingActionButton: IconButton(onPressed: _next, icon: Icon(Icons.forward)),
//     );
//   }
//
//   void _next() {
//     Navigator.of(context).push(
//       MaterialPageRoute(
//         builder: (context) => CatCardPage2(systemStr: textEditingController.text.isEmpty?system:textEditingController.text,),
//       ),
//     );
//   }
// }


import 'dart:convert';
// import 'dart:ffi';
import 'dart:typed_data';

import 'package:avatar_glow/avatar_glow.dart';
import 'package:chat_gpt_sdk/chat_gpt_sdk.dart';
import 'package:chatgpt/pages/--.dart';
import 'package:chatgpt/pages/chatbot_page.dart';
import 'package:chatgpt/pages/main_page_controller.dart';
import 'package:chatgpt/utils/blog_bean.dart';
import 'package:chatgpt/utils/datas.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:highlight_text/highlight_text.dart';
// import 'package:flutter_sound/public/flutter_sound_recorder.dart';
import 'package:http/http.dart' as http;
import 'package:permission_handler/permission_handler.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

import '../utils/color_setting.dart';
import '../utils/dio_util.dart';

class BlogPage extends StatefulWidget {
  const BlogPage({Key? key, required this.blogTitle, required this.blogId}) : super(key: key);

  final String blogTitle;
  final int blogId;

  @override
  State<BlogPage> createState() => _BlogPageState();
}

class _BlogPageState extends State<BlogPage> {
  TextEditingController textEditingController = TextEditingController();

  late stt.SpeechToText _speech;
  bool _isListening = false;
  String _text = 'Press the hello and start speaking';
  double _confidence = 1.0;
  bool _isLiked = false;
  late blogDetailBean contentDetail;

  @override
  void initState() {
    super.initState();
    getPostContent();




    _speech = stt.SpeechToText();
    _isLiked = false;
  }

  late bool showLoading = false;
  late Uint8List recording;

  final _transcriptionController = TextEditingController();

// Recording variables
  bool isRecording = false;


  @override
  Widget build(BuildContext context) {
    //User user = getUserFromBackend();
    //Post post = getPostFromBackend();
    return Scaffold(
      appBar: AppBar(
        backgroundColor: MyColor.orange, // 设置 AppBar 的背景颜色
        title: Text(
          "${widget.blogTitle}",
          maxLines: null, ), //将maxLines属性设置为null，以允许标题文本自动换行
        leading: IconButton( // 这里是左侧的 IconButton
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            // 处理返回操作
            Navigator.of(context).pop();
          },
        ),
      ),
      body: SingleChildScrollView(
        reverse: true,
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.all(16.0),
              margin: EdgeInsets.all(16.0),
              decoration: BoxDecoration(
                color: Color(0xFFEFEFEF),
                border: Border.all(
                  color: MyColor.orange,
                  width: 1.0,
                ),
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(contentDetail.author!),
                        //"${user.name}",
                        Text(contentDetail.datetime!),
                        //"${post.datetime}",
                      ],
                    ),
                    SizedBox(height: 32.0), // 上边空行
                    Center( // 将"Content"及其"SizedBox"放在中央
                      child: Column(
                        children: [
                          Text(contentDetail.content!),
                          //"${post.content}",
                          SizedBox(height: 128.0), // 下边空行
                        ],
                      ),
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            InkWell(
                              onTap: () {
                                setState(() {
                                  _isLiked = !_isLiked; // 切换点赞状态
                                });
                              },

                              child: Icon(
                                Icons.thumb_up,
                                color: _isLiked ? Colors.orange : Colors.grey,
                              ),
                            ),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('Hit:${contentDetail.views!.toString()}',
                              //"${post.hit}",
                              style: TextStyle(
                                  color: Colors.grey),
                            ),
                            Text(contentDetail.likes!.toString(),
                              //"${post.clickNumber}",
                              style: TextStyle(
                                  color: Colors.grey),), // 替换为实际的点赞数量
                          ],
                        ),
                      ],
                    )
                  ],
                ),
              ),
            )
            // 此处放置页面内容
          ],
        ),
      ),
    );
  }

// void _next() {
//   Navigator.of(context).push(
//     MaterialPageRoute(
//       // builder: (context) => CatCardPage2(systemStr: textEditingController.text.isEmpty?system:textEditingController.text,),
//       builder: (context) => MyPageController(),
//     ),
//   );
// }

Future<void> getPostContent() async {
  try {

    // content = request.json.get('blog')
    // userid = request.json.get('userid')
    // abstarct = request.json.get('abstract')
    // title = request.json.get('title')

    Map<String, dynamic> blogId = {
      "id":widget.blogId};
    await DioUtil.getBlogDetails(blogId).then((value){
      // showLoading=false;
      if(value.resultStatus==200){
        // var json = jsonDecode(value.data);
        // contentDetail = blogDetailBean.fromJson(json);
        // var json = jsonDecode(value.data);
        contentDetail = blogDetailBean.fromJson(value.data);


      }else if(value.resultStatus==201){
        // showAlert(context, "手机号码或者密码错误，请确认好在登录");
      }else if(value.resultStatus==202){
        // showAlert(context, "用户不存在");
      }
      else{

      }
      print(value);


      // if(value.isSuccess){
      //   histories.insert(0,ChatMessage.assistant(value.data));
      // }
    });
    // http://127.0.0.1:5000/login/

  } on DioError catch(e) {
    // //登录失败则提示
    // if (e.response?.statusCode == 401) {
    //   showToast(GmLocalizations.of(context).userNameOrPasswordWrong);
    // } else {
    //   showToast(e.toString());
    // }
  } finally {
    // 隐藏loading框
    // Navigator.of(context).pop();
  };

}
}
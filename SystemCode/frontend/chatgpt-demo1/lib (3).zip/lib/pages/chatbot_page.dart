// import 'dart:convert';
// import 'dart:math';
// import 'package:chat_gpt_sdk/chat_gpt_sdk.dart';
// import 'package:chatgpt/pages/rolling_animation.dart';
// import 'package:chatgpt/pages/send_blog.dart';
// import 'package:chatgpt/utils/datas.dart';
// import 'package:chatgpt/utils/dio_util.dart';
// import 'package:flutter/material.dart';
//
// import 'package:lottie/lottie.dart';
//
// import '../utils/color_setting.dart';
// import '../utils/http_request.dart';
// import '../utils/userBean.dart';
//
// class ChatBotPage extends StatefulWidget {
//   const ChatBotPage({Key? key,  required this.userItem, required this.userDataChange}) : super(key: key);
//
//   final userBean userItem;
//   final Function(userBean) userDataChange;
//   // final String systemStr;
//
//   @override
//   State<ChatBotPage> createState() => _ChatBotPageState();
// }
//
// enum AttitudeType { intimidate, seductive, order, friendly, plain }
//
// enum ChatActionCategory {
//   romance,
//   friendly,
//   hostile,
// }
//
// ///##setting
// String setting2 = '''
// 你是友好的狮子小助手，与对方进行有好的沟通，并且回答问题
// ''';
//
// class _ChatBotPageState extends State<ChatBotPage>
//     with SingleTickerProviderStateMixin, AutomaticKeepAliveClientMixin{
//   ///##data initialize
//
//   CharacterInfo characterRelationship =
//   CharacterInfo(friendshipValue: 0, loveValue: 0, intimacyValue: 0);
//   List<Messages> histories = [];
//   List<SystemMessage> messageList = [];
//   // List<ChatMessage> interactionHistories = [];
//   // List<ChatMessage> specialPromptList = [];
//   // List<ChatMessage> relationshipSummary = [];
//   // List<ChatMessage> meetingTimeSummary = [];
//   // List<ChatMessage> eventHistory = [];
//
//   String pastEvents = '之前发生过的事情：';
//   late String systemSetting;
//   late String systemSetting2;
//   late double intermediate = 35;
//   late AttitudeType currentAttitude = AttitudeType.plain;
//   late ChatActionCategory currentActionCategory = ChatActionCategory.friendly;
//
//   late int interactionCount = 0;
//   late int meetingCount = 0;
//
//   ///dice
//   late bool showDiceDialoge = false;
//   late int diceValue = 0;
//   late final AnimationController _controller;
//   late userBean newUserItem;
//   ///character
//   // late int charisma = 40;
//   late int charCharisma = 0;
//
//   ///relationship
//   late int intimacyValue = 0;
//   // late int friendshipValue = 0;
//   // late int loveValue = 0;
//
//   ///character status
//   late int playerCharisma = 0;
//   late int charPride = 0;
//
//   late bool showLoading = false;
//   late bool showLoveImg = false;
//   late List<String> charSpecialPrompts = [];
//
//   ///color
//   late Color bgColor = Color(0xFFFFFFFF);
//   late Color MainColor = Color(0xEF7C00);
//   late Color deepBlue = MyColor.deepBlue;
//
//   late double KeyboardHight = 0;
//   late String completingString = '';
//
//   @override
//   void initState() {
//     main();
//     deepBlue = MyColor.deepBlue;
//     ///状态
//     currentAttitude = AttitudeType.plain;
//     showLoading = false;
//     showLoveImg = false;
//     showDiceDialoge = false;
//
//     ///骰子动画controller
//     _controller = AnimationController(
//         duration: Duration(milliseconds: 800),
//         // value: 20,
//         vsync: this);
//     ///设定
//     systemSetting = setting2;
//     systemSetting2 = systemSecond;
//     bgColor = Color(0xFFFFFFFF);
//     MainColor = Color(0xEF7C00);
//     charSpecialPrompts = [
//
//     ];
//
//     ///关系计数
//     interactionCount = 0;
//     meetingCount = 0;
//
//     ///数值计数
//     charCharisma = 47;
//     playerCharisma = 20;
//     charPride = 5;
//     diceValue = 0;
//     intimacyValue = characterRelationship.intimacyValue ?? 0;
//     ///relationship
//     ///modify textList
//     histories = [
//       // ChatMessage.tips(tips),
//       Messages(role: Role.system, content: systemSetting),
//       Messages(role: Role.assistant, content: tips)
//     ];
//     messageList = [
//       SystemMessage.GPTResponse(tips),
//       // SystemMessage.narrator(systemSetting),
//     ];
//
//     super.initState();
//   }
//
//   @override
//   void dispose() {
//     _controller.dispose();
//     super.dispose();
//   }
//
//   @override
//   bool get wantKeepAlive =>true;
//
//   ///####build fraction
//   ///build here
//   TextEditingController controller = TextEditingController();
//   ScrollController _scrollController = ScrollController();
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: bgColor,
//       resizeToAvoidBottomInset: true,
//       body: Container(
//         // color: Colors.deepOrange,
//         width: MediaQuery.of(context).size.width,
//         child: Column(
//           children: [
//             ///上层
//             Expanded(
//               child: Stack(
//                 children: [
//                   ///背景
//                   _buildBg(),
//                   ///文本框
//                   Positioned(
//                     child: _textLayer(),
//                     bottom: 0,
//                   ),
//                   ///骰子展示结果页面
//                   // _diceInfoDialog(),
//                   ///数值面板
//                   // _dataInfoPanel(),
//                 ],
//               ),
//             ),
//           ],
//         ),
//       )
//     );
//   }
//   ///背景建构
//   _buildBg() {
//     // String path = 'assets/images/bg_street1.png';
//     // return Image.asset(
//     //   path,
//     //   fit: BoxFit.cover,
//     //   width: MediaQuery.of(context).size.width,
//     // );
//     return Container();
//   }
//
//   ///底部面板
//   _textLayer() {
//       return Container(
//
//         width: MediaQuery.of(context).size.width,
//         child: Column(
//           children: [
//             _dialogBox(),
//             SizedBox(
//               // height: 154,
//               child: Container(
//                 color: MyColor.orange,
//                 child: Row(
//                   children: [
//                     Column(
//                       children: [
//                         // _secondBox(),
//                         _textBox()],
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//           ],
//         ),
//       );
//   }
//
//   ///##文本框输入
//   _textBox() {
//     return SizedBox(
//       height: 60,
//       width: MediaQuery.of(context).size.width-50,
//       child: TextField(
//         decoration: InputDecoration(
//             iconColor: MyColor.deepBlue,
//             suffixIcon: IconButton(
//               onPressed: () async {
//                 if (controller.text.isEmpty && !showLoading) {
//                   const snackBar = SnackBar(
//                     duration: Duration(milliseconds: 100),
//                     content: Text('不能为空'),
//                       backgroundColor: MyColor.deepBlue,
//                   );
//                   ScaffoldMessenger.of(context).showSnackBar(snackBar);
//                   return;
//                 }
//                 ///用户发送的
//                 // histories.add(value)
//                 histories.add(
//                     Messages(role: Role.user, content: controller.text));
//                 // histories.insert(
//                 //     0, Messages(role: Role.user, content: controller.text));
//                 messageList.insert(
//                     0,
//                     SystemMessage(
//                         type: SystemMessageType.UserText,
//                         content: controller.text));
//
//                 ///relationshipHandle!!!
//                 ///modify the prompt here
//                 // meetingTimeHandle();
//                 // relationshipHandle();
//                 // sendingPrompt();
//                 chatCompleteWithSSE();
//                 //sendMultiMessage(histories);
//                 controller.clear();
//                 showLoading = true;
//                 setState(() {});
//               },
//               icon: showLoading ? CircularProgressIndicator() : Icon(Icons.send),
//             )),
//         controller: controller,
//         style: TextStyle(color: Colors.green),
//         // readOnly: !showLoading,
//       ),
//     );
//   }
//
//   Map MessageName = {
//     SystemMessageType.GPTResponse: "Lion",
//     SystemMessageType.UserText: "User",
//     SystemMessageType.narrator: "narrator",
//     SystemMessageType.GPTNarrator: "",
//   };
//
//   ///##文本消息框
//   _dialogBox() {
//     return SizedBox(
//       height: MediaQuery.of(context).size.height-100-60-20,
//       width: MediaQuery.of(context).size.width,
//       child: Stack(
//         children: [
//           SizedBox(
//             child: Container(
//               color: Colors.black.withOpacity(0.1),
//             ),
//           ),
//           SizedBox(
//             width: MediaQuery.of(context).size.width,
//             // height: 265,
//             child: ListView.separated(
//                 reverse: true,
//                 itemBuilder: (_, i) {
//                   return
//                   messageList[i].type==SystemMessageType.GPTResponse?
//                   ListTile(
//                     // dense: ,
//                     trailing: SizedBox(width: 40,),
//                     leading: Container(
//                         width: 40,
//                         height: 60,
//                         child: Column(
//                           children: [
//                             CircleAvatar(child:Image.asset('assets/images/lion_laugh.png',
//                               fit: BoxFit.fitHeight,
//                               // width: 100,
//                             ),
//                               minRadius: 20,
//                               maxRadius: 28,
//                             ),
//                             // Spacer()
//                           ],
//                         )
//                     ),
//                     title: Text('Lainy', textAlign: TextAlign.left,),
//                     subtitle: Container(
//                       padding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 5),
//                       decoration: BoxDecoration(
//                         color: MyColor.orange,
//                         border: Border.all(
//                           color: MyColor.orange,
//                           width: 1.0,
//                         ),
//                         borderRadius: BorderRadius.circular(10.0),
//                       ),
//                       child: Text(
//                           messageList[i].content!),
//                     ),
//                   )
//                       :
//                   ListTile(
//                     trailing: Container(
//                       // color: Colors.green,
//                         width: 40,
//                         height: 60,
//                         child: Column(
//                           children: [
//                             CircleAvatar(child:Text("user"),
//                               // width: 100,
//                               minRadius: 20,
//                               maxRadius: 28,
//                             ),
//                             // Spacer()
//                           ],
//                         )
//                     ),
//                     // leading: Spacer(),
//                     title: Text(widget.userItem.userNickName!, textAlign: TextAlign.right,),
//                     subtitle: Container(
//                       padding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 5),
//
//                       decoration: BoxDecoration(
//                         color: MyColor.lightWhite,
//                         border: Border.all(
//                           color: MyColor.orange,
//                           width: 1.0,
//                         ),
//                         borderRadius: BorderRadius.circular(10.0),
//                       ),
//                       child: Text(
//                           messageList[i].content!),
//                     ),
//                   );
//                 },
//                 separatorBuilder: (_, i) {
//                   return Container(
//                     height: 10,
//                   );
//                 },
//                 itemCount: messageList.length),
//           )
//         ],
//       ),
//     );
//   }
//
//   Future<void> chatCompleteWithSSE() async {
//     completingString='';
//     String showingText = "";
//     final request = ChatCompleteText(messages: histories, maxToken: 1000, model: GptTurboChatModel());
//     // final request = ChatCompleteText(messages: [Messages(role: Role.assistant, content: "wewewwew")], maxToken: 1000, model: GptTurboChatModel());
//     messageList.insert(
//         0, SystemMessage.GPTResponse("🦁"));
//     openAI.onChatCompletionSSE(request: request).listen((it) {
//       completingString = completingString+it.choices!.last.message!.content.toString();
//       showingText = "$completingString 🦁";
//       messageList[0].content = showingText;
//       setState(() {
//       });
//       showLoading = true;
//     }).onDone(() {
//       showLoading = false;
//       messageList[0].content = completingString;
//       histories.add(
//           Messages(role: Role.assistant, content: completingString));
//       setState(() {
//       });
//     });
//     // final response = await openAI.onChatCompletion(request: request);
//     // for (var element in response!.choices) {
//     //   showLoading = false;
//     //   messageList[0].content = element.message?.content;
//     //   histories.add(
//     //       Messages(role: Role.assistant, content: element.message?.content));
//     //   setState(() {
//     //   });
//     // };
//     // showLoading = false;
//     // setState(() {
//     //
//     // });
//
//
//     // openAI.onChatCompletion(request: request).then((value){
//     //     print("result!!!!");
//     //     debugPrint(value.toString());
//     //     // debugPrint(it.choices?.last.message?.content);
//     //   }
//     ///一次性出结果
//     // final response = await openAI.onChatCompletion(request: request);
//     // for (var element in response!.choices) {
//     //   print("data -> ${element.message?.content}");
//     //   messageList.insert(
//     //       0, SystemMessage.GPTResponse(element.message?.content));
//     //   histories.add(
//     //       Messages(role: Role.assistant, content: element.message?.content));
//     // };
//     // showLoading = false;
//     // setState(() {
//     //
//     // });
//   }
// }

///信息获取版本！！！！！！
///import 'dart:convert';
import 'dart:math';
import 'package:chat_gpt_sdk/chat_gpt_sdk.dart';
import 'package:chatgpt/pages/rolling_animation.dart';
import 'package:chatgpt/pages/send_blog.dart';
import 'package:chatgpt/utils/datas.dart';
import 'package:chatgpt/utils/dio_util.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:lottie/lottie.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vibration/vibration.dart';

import '../utils/color_setting.dart';
import '../utils/http_request.dart';
import '../utils/userBean.dart';

class ChatBotPage extends StatefulWidget {
  const ChatBotPage({Key? key,  required this.userItem, required this.userDataChange, }) : super(key: key);

  final userBean userItem;
  final Function(userBean) userDataChange;
  // final String systemStr;

  @override
  State<ChatBotPage> createState() => _ChatBotPageState();
}

enum AttitudeType { intimidate, seductive, order, friendly, plain }

enum ChatActionCategory {
  romance,
  friendly,
  hostile,
}

///##setting
String setting2 = '''
你是友好的狮子小助手，与对方进行有好的沟通，并且回答问题
''';

class _ChatBotPageState extends State<ChatBotPage>
    with SingleTickerProviderStateMixin, AutomaticKeepAliveClientMixin {
  ///##data initialize

  CharacterInfo characterRelationship =
  CharacterInfo(friendshipValue: 0, loveValue: 0, intimacyValue: 0);
  List<Messages> histories = [];
  List<SystemMessage> messageList = [];

  // List<ChatMessage> interactionHistories = [];
  // List<ChatMessage> specialPromptList = [];
  // List<ChatMessage> relationshipSummary = [];
  // List<ChatMessage> meetingTimeSummary = [];
  // List<ChatMessage> eventHistory = [];

  String pastEvents = '之前发生过的事情：';
  late String systemSetting;
  late String systemSetting2;
  late double intermediate = 35;
  late AttitudeType currentAttitude = AttitudeType.plain;
  late ChatActionCategory currentActionCategory = ChatActionCategory.friendly;

  late int interactionCount = 0;
  late int meetingCount = 0;

  ///dice
  late bool showDiceDialoge = false;
  late int diceValue = 0;
  late final AnimationController _controller;
  late userBean newUserItem;

  ///character
  // late int charisma = 40;
  late int charCharisma = 0;

  ///relationship
  late int intimacyValue = 0;

  // late int friendshipValue = 0;
  // late int loveValue = 0;

  ///character status
  late int playerCharisma = 0;
  late int charPride = 0;

  late bool showLoading = false;
  late bool showLoveImg = false;
  late List<String> charSpecialPrompts = [];

  ///color
  late Color bgColor = Color(0xFFFFFFFF);
  late Color MainColor = Color(0xEF7C00);
  late Color deepBlue = MyColor.deepBlue;

  late double KeyboardHight = 0;
  late String completingString = '';

  // var token = getTokenKey();
  late OpenAI openAI;


  @override
  void initState() {

    // openAI = OpenAI.instance.build(token: widget.userItem.llmToken,
    //     baseOption: HttpSetup(receiveTimeout: const Duration(seconds: 20)),enableLog: true);

    print("init chatbotpage!!!");
    main();
    deepBlue = MyColor.deepBlue;

    ///状态
    currentAttitude = AttitudeType.plain;
    showLoading = false;
    showLoveImg = false;
    showDiceDialoge = false;

    ///骰子动画controller
    _controller = AnimationController(
        duration: Duration(milliseconds: 800),
        // value: 20,
        vsync: this);

    ///设定
    systemSetting = setting2;
    systemSetting2 = systemSecond;
    bgColor = Color(0xFFFFFFFF);
    MainColor = Color(0xEF7C00);
    charSpecialPrompts = [
    ];

    ///关系计数
    interactionCount = 0;
    meetingCount = 0;

    ///数值计数
    charCharisma = 47;
    playerCharisma = 20;
    charPride = 5;
    diceValue = 0;
    intimacyValue = characterRelationship.intimacyValue ?? 0;

    ///relationship
    ///modify textList
    histories = [
      // ChatMessage.tips(tips),
      Messages(role: Role.system, content: systemSetting),
      Messages(role: Role.assistant, content: tips)
    ];
    messageList = [
      SystemMessage.GPTResponse(tips),
      // SystemMessage.narrator(systemSetting),
    ];

    super.initState();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  bool get wantKeepAlive => true;

  ///####build fraction
  ///build here
  TextEditingController controller = TextEditingController();
  ScrollController _scrollController = ScrollController();

  @override
  Widget build(BuildContext context) {


    // print("llmTest!!!!");
    // print(widget.userItem.llmToken);
    return Scaffold(
        backgroundColor: bgColor,
        resizeToAvoidBottomInset: true,
        body: Container(
          // color: Colors.deepOrange,
          width: MediaQuery
              .of(context)
              .size
              .width,
          child: Column(
            children: [

              ///上层
              Expanded(
                child: Stack(
                  children: [

                    ///背景
                    _buildBg(),

                    ///文本框
                    Positioned(
                      child: _textLayer(),
                      bottom: 0,
                    ),

                    ///骰子展示结果页面
                    // _diceInfoDialog(),
                    ///数值面板
                    // _dataInfoPanel(),
                  ],
                ),
              ),
            ],
          ),
        )
    );
  }

  ///背景建构
  _buildBg() {
    // String path = 'assets/images/bg_street1.png';
    // return Image.asset(
    //   path,
    //   fit: BoxFit.cover,
    //   width: MediaQuery.of(context).size.width,
    // );
    return Container();
  }

  ///底部面板
  _textLayer() {
    return Container(

      width: MediaQuery
          .of(context)
          .size
          .width,
      child: Column(
        children: [
          _dialogBox(),
          SizedBox(
            // height: 154,
            child: Container(
              color: MyColor.orange,
              child: Row(
                children: [
                  Column(
                    children: [
                      // _secondBox(),
                      _textBox()],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  ///##文本框输入
  _textBox() {
    return SizedBox(
      height: 60,
      width: MediaQuery
          .of(context)
          .size
          .width - 50,
      child: TextField(
        decoration: InputDecoration(
            iconColor: MyColor.deepBlue,
            suffixIcon: IconButton(
              onPressed: () async {
                if (controller.text.isEmpty && !showLoading) {
                  const snackBar = SnackBar(
                    duration: Duration(milliseconds: 100),
                    content: Text('message cannot be empty'),
                    backgroundColor: MyColor.deepBlue,
                  );
                  ScaffoldMessenger.of(context).showSnackBar(snackBar);
                  return;
                }

                ///用户发送的
                // histories.add(value)
                histories.add(
                    Messages(role: Role.user, content: controller.text));
                // histories.insert(
                //     0, Messages(role: Role.user, content: controller.text));
                messageList.insert(
                    0,
                    SystemMessage(
                        type: SystemMessageType.UserText,
                        content: controller.text));

                ///relationshipHandle!!!
                ///modify the prompt here
                // meetingTimeHandle();
                // relationshipHandle();
                // sendingPrompt();
                chatCompleteWithSSE();
                //sendMultiMessage(histories);
                controller.clear();
                showLoading = true;
                setState(() {});
              },
              icon: showLoading ? CircularProgressIndicator() : Icon(
                  Icons.send),
            )),
        controller: controller,
        // style: TextStyle(color: Colors.green),
        // readOnly: !showLoading,
      ),
    );
  }

  Map MessageName = {
    SystemMessageType.GPTResponse: "Lion",
    SystemMessageType.UserText: "User",
    SystemMessageType.narrator: "narrator",
    SystemMessageType.GPTNarrator: "",
  };

  ///##文本消息框
  _dialogBox() {
    return SizedBox(
      height: MediaQuery
          .of(context)
          .size
          .height - 100 - 60 - 20,
      width: MediaQuery
          .of(context)
          .size
          .width,
      child: Stack(
        children: [
          SizedBox(
            child: Container(
              color: Colors.black.withOpacity(0.1),
            ),
          ),
          SizedBox(
            width: MediaQuery
                .of(context)
                .size
                .width,
            // height: 265,
            child: ListView.separated(
                reverse: true,
                itemBuilder: (_, i) {
                  return
                    messageList[i].type == SystemMessageType.GPTResponse ?
                    ListTile(

                      // dense: ,
                      trailing: SizedBox(width: 40,),
                      leading: Container(
                          width: 40,
                          height: 60,
                          child: Column(
                            children: [
                              CircleAvatar(child: Image.asset(
                                'assets/images/lion_laugh.png',
                                fit: BoxFit.fitHeight,
                                // width: 100,
                              ),
                                minRadius: 20,
                                maxRadius: 28,
                              ),
                              // Spacer()
                            ],
                          )
                      ),
                      title: Text('Lainy', textAlign: TextAlign.left,),
                      subtitle: InkWell(
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              vertical: 10.0, horizontal: 5),
                          decoration: BoxDecoration(
                            color: MyColor.orange,
                            border: Border.all(
                              color: MyColor.orange,
                              width: 1.0,
                            ),
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                          child: Text(
                              messageList[i].content!),
                        ),
                        onLongPress: () async {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('copied',
                                style: TextStyle(
                                    color: MyColor.orange),
                              ),
                              duration: Duration(milliseconds: 60),
                              backgroundColor: Colors.white,
                            ),
                          );//

                          if (await Vibration.hasVibrator() ?? false) {
                          Vibration.vibrate();
                          }
                          Clipboard.setData(ClipboardData(text: messageList[i].content!));
                        },
                      )
                    )
                        :
                    ListTile(
                      leading: SizedBox(width: 40,),
                      trailing: Container(
                        // color: Colors.green,
                          width: 40,
                          height: 60,
                          child: Column(
                            children: [
                              CircleAvatar(child: Text("I",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                                // width: 100,
                                backgroundColor: MyColor.deepBlue,
                                minRadius: 20,
                                maxRadius: 28,
                              ),
                              // Spacer()
                            ],
                          )
                      ),
                      // leading: Spacer(),
                      title: Text(widget.userItem.userNickName!,
                        textAlign: TextAlign.right,),
                      subtitle: InkWell(
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              vertical: 10.0, horizontal: 5),

                          decoration: BoxDecoration(
                            color: MyColor.lightWhite,
                            border: Border.all(
                              color: MyColor.orange,
                              width: 1.0,
                            ),
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                          child: Text(
                              messageList[i].content!),
                        ),
                        onLongPress: () async {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('copied',
                                style: TextStyle(
                                    color: MyColor.orange),
                              ),
                              duration: Duration(milliseconds: 60),
                              backgroundColor: Colors.white,
                            ),
                          );//

                          if (await Vibration.hasVibrator() ?? false) {
                          Vibration.vibrate();
                          }
                          Clipboard.setData(ClipboardData(text: messageList[i].content!));
                        },
                      ),
                    );
                },
                separatorBuilder: (_, i) {
                  return Container(
                    height: 10,
                  );
                },
                itemCount: messageList.length),
          )
        ],
      ),
    );
  }

  Future<dynamic> chatCompleteWithSSE() async {
    completingString = '';
    String showingText = "";
    final request = ChatCompleteText(
        messages: histories, maxToken: 1000, model: GptTurboChatModel());
    // final request = ChatCompleteText(messages: [Messages(role: Role.assistant, content: "wewewwew")], maxToken: 1000, model: GptTurboChatModel());
    messageList.insert(
        0, SystemMessage.GPTResponse("🦁"));


//     try {
//
// // This will throw an error.
//       final errorVariation = await OpenAI.onChatCompletionSSE.image.variation(
//
//       );
//     } on RequestFailedException catch(e) {
//       print(e.message);
//       print(e.statusCode);
//     }
//
//


    try {
      // final errorVariation = openAI.onChatCompletionSSE(request: request).listen((it) {
      //     print("result!!!");
      //     completingString = completingString+it.choices!.last.message!.content.toString();
      //     showingText = "$completingString 🦁";
      //     messageList[0].content = showingText;
      //     setState(() {
      //     });
      //     showLoading = true;
      //   }).onDone(() {
      //     showLoading = false;
      //     messageList[0].content = completingString;
      //     histories.add(
      //         Messages(role: Role.assistant, content: completingString));
      //     setState(() {
      //     });
      //   });
      openAI = OpenAI.instance.build(token: widget.userItem.llmToken,
          baseOption: HttpSetup(receiveTimeout: const Duration(seconds: 20)),enableLog: true);

      openAI.onChatCompletionSSE(request: request)
          .listen((it) {
        print("result!!!");
        completingString =
            completingString + it.choices!.last.message!.content.toString();
        showingText = "$completingString 🦁";
        messageList[0].content = showingText;
        setState(() {});
        showLoading = true;
      }).onError((error) {
        if(error.code==500){
          showLoading = false;
          messageList.removeAt(0);
          setState(() {});
          showAlert(context, "🦁：internet error, please check your connection");

        }else if(error.code==401){
          showLoading = false;
          messageList.removeAt(0);
          setState(() {});
          showAlert(context, "🦁：your token is invalid, please double check");
        }else{
          showLoading = false;
          messageList.removeAt(0);
          setState(() {});
          showAlert(context, "🦁：unknown error, please try again");
        }

        // messageList[0].content = completingString;
        // histories.add(
        //     Messages(role: Role.assistant, content: completingString));
        // setState(() {});
      });
    } catch (e) {
      // print(e);
      // showAlert(context, "internet error");
      // print('error!!!!');
    }



    // final response = await openAI.onChatCompletion(request: request);
    // for (var element in response!.choices) {
    //   showLoading = false;
    //   messageList[0].content = element.message?.content;
    //   histories.add(
    //       Messages(role: Role.assistant, content: element.message?.content));
    //   setState(() {
    //   });
    // };
    // showLoading = false;
    // setState(() {
    //
    // });


    // openAI.onChatCompletion(request: request).then((value){
    //     print("result!!!!");
    //     debugPrint(value.toString());
    //     // debugPrint(it.choices?.last.message?.content);
    //   }
    ///一次性出结果
    // final response = await openAI.onChatCompletion(request: request);
    // for (var element in response!.choices) {
    //   print("data -> ${element.message?.content}");
    //   messageList.insert(
    //       0, SystemMessage.GPTResponse(element.message?.content));
    //   histories.add(
    //       Messages(role: Role.assistant, content: element.message?.content));
    // };
    // showLoading = false;
    // setState(() {
    //
    // });
  }

  void showAlert(scaffoldContext, String alertInfo) {
    showDialog(
      context: scaffoldContext,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Warning',
            style: TextStyle(
                color: Colors.red),),
          content: Text(alertInfo),
          actions: <Widget>[
            TextButton(
              child: Text('Closed'),
              onPressed: () {
                Navigator.of(context).pop(); // 关闭对话框
              },
            ),
          ],
        );
      },
    );
  }
}

Future<String?> getTokenKey() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  return prefs.getString('LLM-key');
}


//   Future<void> _getBotResponse(String text) async {
//     const apiKey = 'YOUR_OPENAI_API_KEY'; // Replace with your OpenAI API key
//     final response = await http.post(
//       Uri.parse('https://api.openai.com/v1/engines/davinci-codex/completions'),
//       headers: {
//         'Content-Type': 'application/json',
//         'Authorization': 'Bearer $apiKey',
//       },
//       body: jsonEncode({
//         'prompt': text,
//         'max_tokens': 150,
//       }),
//     );
//
//     if (response.statusCode == 200) {
//       final responseData = jsonDecode(response.body);
//       final botMessage = responseData['choices'][0]['text'].trim();
//       setState(() {
//         _messages.insert(0, _ChatMessage(text: botMessage, isSentByUser: false));
//       });
//     } else {
//       print('Failed to get bot response: ${response.body}');
//     }
//   }
// }


//
// import 'dart:convert';
// import 'dart:math';
//
// import 'package:chat_gpt_sdk/chat_gpt_sdk.dart';
// import 'package:chatgpt/pages/rolling_animation.dart';
// import 'package:chatgpt/utils/datas.dart';
// import 'package:chatgpt/utils/dio_util.dart';
// import 'package:flutter/material.dart';
//
// import 'package:lottie/lottie.dart';
//
// import '../utils/http_request.dart';
//
// class CatCardPage2 extends StatefulWidget {
//   const CatCardPage2({Key? key, required this.systemStr}) : super(key: key);
//
//   final String systemStr;
//
//   @override
//   State<CatCardPage2> createState() => _CatCardPageState();
// }
//
// ///##enums
// enum InteractionState { normal, hostile, chat, approach, interact }
//
// enum ActionType {
//   battle,
//   steal,
//   sneakAttack,
//   insult,
//   askToLeave,
//   requestItem,
//   makePeace,
//   request_help,
//   trade,
//   gift,
//   getContact,
//   invitation,
// }
//
// enum AttitudeType { intimidate, seductive, order, friendly, plain }
//
// enum ChatActionCategory {
//   romance,
//   friendly,
//   hostile,
// }
//
// enum ChatAction {
//   rom_charmingHello,
//   rom_flirt,
//   rom_hug,
//   rom_kiss,
//
//   fri_sayHi,
//   fri_joke,
//   fri_friendlyHug,
//   fri_recentNews,
//   fri_randomChat,
//
//   hos_pulpJoke,
// }
//
// ///##setting
// // String setting1 = '''我将描述事件经过，而你chatgpt，则需要对这个事件进行重新叙述。要让两个故事看起来不一样，但是发生的事情完全一致。事件设计两个角色，他们的角色设定如下：
// // 角色A的设定如下：
// // 1.名称：你
// // 2.职业：冒险者
// // 3.说话习惯：喜欢说话简洁
// //
// // 角色B的设定如下：
// // 1.名称：美咲
// // 2.职业：摩托车手，女高中生
// // 3.年龄：18
// // 4.性格高冷，傲娇，毒舌，日本动漫当中女主的性格，不屑，害羞。
// // 5.说话简短，恶毒
// //
// // 故事的描述有以下几条必须遵守的原则：
// // 1.不要即兴发挥
// // 2.主要描写角色B
// // 3.角色之间没有任何多余的，在描述之外的动作
// // 5.描述内容在70字以内，绝对不可以超过70字
// // 6.使用“你”来称呼角色A，不要使用角色A的名字
// // 7.每个事件的时长在2分钟，事件的发展不会超过两分钟的跨度
// // 8.严格按照我描述的事件进行填充，不可以添加不存在的剧情
// // ''';
//
// String setting2 = '''
// 我将描述一个事件，而你chatgpt，则需要对其重新叙述，重新叙述的字数接近。
// 故事的描述有以下几条必须遵守的原则：
// 1.不要即兴发挥
// 2.角色之间没有任何多余的，在描述之外的动作
// 3.描述内容在70字以内，绝对不可以超过70字
// 4.严格按照我描述的事件进行填充，不可以添加不存在的剧情
// ''';
//
// class _CatCardPageState extends State<CatCardPage2>
//     with SingleTickerProviderStateMixin {
//   ///##data initialize
//
//   CharacterInfo characterRelationship =
//   CharacterInfo(friendshipValue: 0, loveValue: 0, intimacyValue: 0);
//
//   List<ChatMessage> histories = [];
//   List<SystemMessage> messageList = [];
//   List<ChatMessage> interactionHistories = [];
//   List<ChatMessage> specialPromptList = [];
//   List<ChatMessage> relationshipSummary = [];
//   List<ChatMessage> meetingTimeSummary = [];
//   List<ChatMessage> eventHistory = [];
//
//   String pastEvents = '之前发生过的事情：';
//   late String systemSetting;
//   late String systemSetting2;
//   late double intermediate = 35;
//   late AttitudeType currentAttitude = AttitudeType.plain;
//   late ChatActionCategory currentActionCategory = ChatActionCategory.friendly;
//
//   late InteractionState currentState = InteractionState.normal;
//   late int interactionCount = 0;
//   late int meetingCount = 0;
//
//   ///dice
//   late bool showDiceDialoge = false;
//   late int diceValue = 0;
//   late final AnimationController _controller;
//
//   ///character
//   // late int charisma = 40;
//   late int charCharisma = 0;
//
//   ///relationship
//   late int intimacyValue = 0;
//   // late int friendshipValue = 0;
//   // late int loveValue = 0;
//
//   ///character status
//   late int playerCharisma = 0;
//   late int charPride = 0;
//
//   late bool showLoading = false;
//   late bool showLoveImg = false;
//   late List<String> charSpecialPrompts = [];
//
//   @override
//   void initState() {
//
//     main();
//     // upload
//     // PineconeService.embedding();
//     // post_request();
//
//
//     ///状态
//     currentState = InteractionState.normal;
//     currentAttitude = AttitudeType.plain;
//     showLoading = false;
//     showLoveImg = false;
//     showDiceDialoge = false;
//
//     ///骰子动画controller
//     _controller = AnimationController(
//         duration: Duration(milliseconds: 800),
//         // value: 20,
//         vsync: this);
//
//     ///设定
//     systemSetting = widget.systemStr;
//     systemSetting2 = systemSecond;
//
//     charSpecialPrompts = [
//
//     ];
//
//     ///关系计数
//     interactionCount = 0;
//     meetingCount = 0;
//
//     ///数值计数
//     charCharisma = 47;
//     playerCharisma = 20;
//     charPride = 5;
//     diceValue = 0;
//     intimacyValue = characterRelationship.intimacyValue ?? 0;
//     ///relationship
//     //暂时无用👇
//     // friendshipValue = characterRelationship.friendshipValue ?? 0;
//     // loveValue = characterRelationship.loveValue ?? 0;
//
//     ///modify textList
//     histories = [
//       // ChatMessage.tips(tips),
//       ChatMessage.system(systemSetting),
//     ];
//     messageList = [
//       SystemMessage.narrator(tips),
//       // SystemMessage.narrator(systemSetting),
//     ];
//     specialPromptList = [];
//     relationshipSummary = [];
//     meetingTimeSummary = [];
//
//     super.initState();
//   }
//
//   @override
//   void dispose() {
//     _controller.dispose();
//     super.dispose();
//   }
//
//   ///####build fraction
//   ///build here
//   TextEditingController controller = TextEditingController();
//   ScrollController _scrollController = ScrollController();
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Color(0xFFFEDA91),
//       resizeToAvoidBottomInset: true,
//       body: Column(
//         children: [
//           ///上层
//           Expanded(
//             child: Stack(
//               children: [
//                 ///背景
//                 _buildBg(),
//                 ///文本框
//                 Positioned(
//                   child: _textLayer(),
//                   bottom: 0,
//                 ),
//                 ///骰子展示结果页面
//                 _diceInfoDialog(),
//
//                 ///数值面板
//                 _dataInfoPanel(),
//
//               ],
//             ),
//           ),
//         ],
//       ),
//     );
//   }
//   ///背景建构
//   _buildBg() {
//     String path = 'assets/images/bg_street1.png';
//     return Image.asset(
//       path,
//       fit: BoxFit.cover,
//       width: MediaQuery.of(context).size.width,
//     );
//   }
//
//   ///底部面板
//   _textLayer() {
//     ///normal bar
//     if (currentState == InteractionState.normal) {
//       return SizedBox(
//           height: 154 + 265,
//           width: 360,
//           child: Column(
//             children: [_dialogBox(), _newSecondBox(), _newBottomBox()],
//           ));
//     }
//
//     ///hostile bar
//     if (currentState == InteractionState.hostile) {
//       double barHeight = 74;
//       double barWidth = 325;
//       return Column(
//         children: [
//           _dialogBox(),
//           SizedBox(
//             height: 154,
//             child: Container(
//               color: Color(0xFFFF706C),
//               child: Row(
//                 children: [
//                   Container(
//                     child: InkWell(
//                       child: SizedBox(
//                         width: 35,
//                         height: 153,
//                         child: Image.asset(
//                           'assets/images/icon_sidebar_hostile.png',
//                         ),
//                       ),
//                       onTap: () {
//                         currentState = InteractionState.normal;
//                         setState(() {});
//                       },
//                     ),
//                   ),
//                   Column(
//                     children: [
//                       SizedBox(
//                         height: 2,
//                       ),
//                       SizedBox(
//                         height: 100,
//                         width: barWidth,
//                         child: SingleChildScrollView(
//                           scrollDirection: Axis.horizontal,
//                           child: Row(
//                             crossAxisAlignment: CrossAxisAlignment.start,
//                             children: [
//                               _bigActionIcon(
//                                   "Battle!",
//                                   'assets/images/icon_battle.png',
//                                   ActionType.battle),
//                               _bigActionIcon(
//                                   "Sneak Attack",
//                                   'assets/images/icon_sneakAttack.png',
//                                   ActionType.sneakAttack),
//                               _bigActionIcon(
//                                   "Steal",
//                                   'assets/images/icon_steal.png',
//                                   ActionType.steal),
//                               _bigActionIcon(
//                                   "Insult",
//                                   'assets/images/icon_insult.png',
//                                   ActionType.insult),
//                             ],
//                           ),
//                         ),
//                       ),
//
//                       SizedBox(
//                         height: 4,
//                       ),
//                       //375,少5
//                       SizedBox(
//                         height: 40,
//                         width: barWidth,
//                         child: SingleChildScrollView(
//                           scrollDirection: Axis.horizontal,
//                           child: Row(
//                             crossAxisAlignment: CrossAxisAlignment.start,
//                             children: [
//                               SizedBox(
//                                   width: 150,
//                                   height: 40,
//                                   child: Column(
//                                     children: [
//                                       InkWell(
//                                         child: SizedBox(
//                                           width: 150,
//                                           height: 40,
//                                           child: Container(
//                                             color: Colors.brown,
//                                             alignment: Alignment.center,
//                                             child: Text(
//                                               'inventory',
//                                               style: TextStyle(
//                                                   fontSize: 20,
//                                                   fontFamily: "Roboto",
//                                                   fontStyle: FontStyle.normal,
//                                                   fontWeight: FontWeight.w900,
//                                                   color: Colors.white),
//                                               textAlign: TextAlign.left,
//                                             ),
//                                           ),
//                                         ),
//                                         onTap: () {
//                                           if (controller.text.isEmpty &&
//                                               !showLoading) {
//                                             const snackBar = SnackBar(
//                                               duration:
//                                               Duration(milliseconds: 500),
//                                               content: Text('example!!!!!'),
//                                             );
//                                             ScaffoldMessenger.of(context)
//                                                 .showSnackBar(snackBar);
//                                             return;
//                                           }
//                                           setState(() {});
//                                         },
//                                       ),
//                                     ],
//                                   )),
//                             ],
//                           ),
//                         ),
//                       )
//                     ],
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ],
//       );
//     }
//
//     ///chat bar
//     if (currentState == InteractionState.chat) {
//       double barHeight = 74;
//       double barWidth = 325;
//
//       return Column(
//         children: [
//           _dialogBox(),
//           SizedBox(
//             height: 154,
//             child: Container(
//               color: Color(0xFFFFDB80),
//               child: Row(
//                 children: [
//                   Container(
//                     child: InkWell(
//                       child: SizedBox(
//                         width: 35,
//                         height: 153,
//                         child: Image.asset(
//                           'assets/images/icon_sidebar_chat.png',
//                         ),
//                       ),
//                       // borderRadius: borderRadius,
//                       onTap: () {
//                         currentState = InteractionState.normal;
//                         setState(() {});
//                       },
//                     ),
//                   ),
//                   Column(
//                     children: [_secondBox(), _textBox()],
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ],
//       );
//     }
//
//     ///interact bar
//     if (currentState == InteractionState.interact) {
//       double barHeight = 74;
//       double barWidth = 325;
//
//       return Column(
//         children: [
//           _dialogBox(),
//           SizedBox(
//             height: 154,
//             child: Container(
//               color: Color(0xFF41B6A3),
//               child: Row(
//                 children: [
//                   Container(
//                     child: InkWell(
//                       child: SizedBox(
//                         width: 35,
//                         height: 153,
//                         child: Image.asset(
//                           'assets/images/icon_sidebar_interact.png',
//                         ),
//                       ),
//                       // borderRadius: borderRadius,
//                       onTap: () {
//                         currentState = InteractionState.normal;
//                         setState(() {});
//                       },
//                     ),
//                   ),
//                   Column(
//                     children: [
//                       SizedBox(
//                         height: 2,
//                       ),
//                       SizedBox(
//                         height: barHeight,
//                         width: barWidth,
//                         child: SingleChildScrollView(
//                           scrollDirection: Axis.horizontal,
//                           child: Row(
//                             crossAxisAlignment: CrossAxisAlignment.start,
//                             children: [
//                               _attitudeIcon(
//                                   "plain",
//                                   'assets/images/icon_plain.png',
//                                   AttitudeType.plain),
//                               _attitudeIcon(
//                                   "intimidate",
//                                   'assets/images/icon_intimidate.png',
//                                   AttitudeType.intimidate),
//                               _attitudeIcon(
//                                   "seductive",
//                                   'assets/images/icon_seductive.png',
//                                   AttitudeType.seductive),
//                               _attitudeIcon(
//                                   "order",
//                                   'assets/images/icon_order.png',
//                                   AttitudeType.order),
//                               _attitudeIcon(
//                                   "friendly",
//                                   'assets/images/icon_friendly.png',
//                                   AttitudeType.friendly),
//                             ],
//                           ),
//                         ),
//                       ),
//                       SizedBox(
//                         height: 4,
//                       ),
//                       //375,少5
//                       SizedBox(
//                         height: barHeight,
//                         width: barWidth,
//                         child: SingleChildScrollView(
//                           scrollDirection: Axis.horizontal,
//                           child: Row(
//                             crossAxisAlignment: CrossAxisAlignment.start,
//                             children: [
//                               _actionIcon(
//                                   "Ask To Leave",
//                                   'assets/images/icon_battle.png',
//                                   ActionType.askToLeave),
//                               _actionIcon(
//                                   "Make Peace",
//                                   'assets/images/icon_battle.png',
//                                   ActionType.makePeace),
//                               _actionIcon(
//                                   "Request item",
//                                   'assets/images/icon_battle.png',
//                                   ActionType.requestItem),
//                               _actionIcon(
//                                   "Get Contact",
//                                   'assets/images/icon_battle.png',
//                                   ActionType.getContact),
//                               _actionIcon(
//                                   "Request help",
//                                   'assets/images/icon_battle.png',
//                                   ActionType.request_help),
//                               _actionIcon(
//                                   "Trade",
//                                   'assets/images/icon_battle.png',
//                                   ActionType.trade),
//                               _actionIcon(
//                                   "Gift",
//                                   'assets/images/icon_battle.png',
//                                   ActionType.gift),
//                               _actionIcon(
//                                   "Invitation",
//                                   'assets/images/icon_battle.png',
//                                   ActionType.invitation),
//                             ],
//                           ),
//                         ),
//                       )
//                     ],
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ],
//       );
//     }
//   }
//
//   _secondBox() {
//     ///chat mode
//     if (currentState == InteractionState.chat) {
//       return SizedBox(
//           height: 94,
//           width: 322,
//           child: SingleChildScrollView(
//             child: Column(
//               children: [
//                 SizedBox(
//                   height: 33,
//                   width: 370,
//                   child: SingleChildScrollView(
//                     scrollDirection: Axis.horizontal,
//                     child: Row(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         _chatActionTypeIcon("friendly", Color(0xFF58B6EB),
//                             ChatActionCategory.friendly),
//                         _chatActionTypeIcon("romance", Color(0xFFEB588D),
//                             ChatActionCategory.romance),
//                         _chatActionTypeIcon("hostile", Color(0xFFBC3633),
//                             ChatActionCategory.hostile),
//                       ],
//                     ),
//                   ),
//                 ),
//                 //375,少5
//                 SizedBox(
//                   height: 50,
//                   width: 370,
//                   child: SingleChildScrollView(
//                       scrollDirection: Axis.horizontal,
//                       child: _chatActionRow()),
//                 )
//               ],
//             ),
//           ));
//     }
//
//     ///main options
//     return SizedBox(
//         height: 94,
//         width: 358,
//         child: SingleChildScrollView(
//           child: Column(
//             children: [
//               SizedBox(
//                 height: 30,
//                 width: 358,
//                 child: Container(
//                   color: Colors.green,
//                   child: Text("option one"),
//                 ),
//               ),
//               SizedBox(
//                 height: 5,
//               ),
//               SizedBox(
//                 height: 30,
//                 width: 358,
//                 child: Container(
//                   color: Colors.green,
//                   child: Text("option two"),
//                 ),
//               ),
//               SizedBox(
//                 height: 5,
//               ),
//               SizedBox(
//                 height: 30,
//                 width: 358,
//                 child: Container(
//                   color: Colors.green,
//                   child: Text("option two"),
//                 ),
//               ),
//               SizedBox(
//                 height: 5,
//               ),
//               SizedBox(
//                 height: 30,
//                 width: 358,
//                 child: Container(
//                   color: Colors.green,
//                   child: Text("option two"),
//                 ),
//               )
//             ],
//           ),
//         ));
//   }
//
//   _newSecondBox() {
//     return SizedBox(
//         height: 94,
//         width: 358,
//         child: SingleChildScrollView(
//           child: Column(
//             children: [
//               SizedBox(
//                 height: 30,
//                 width: 358,
//                 child: Container(
//                   color: Colors.green,
//                   child: Text("option one"),
//                 ),
//               ),
//               SizedBox(
//                 height: 5,
//               ),
//               SizedBox(
//                 height: 30,
//                 width: 358,
//                 child: Container(
//                   color: Colors.green,
//                   child: Text("option two"),
//                 ),
//               ),
//               SizedBox(
//                 height: 5,
//               ),
//               SizedBox(
//                 height: 30,
//                 width: 358,
//                 child: Container(
//                   color: Colors.green,
//                   child: Text("option two"),
//                 ),
//               ),
//               SizedBox(
//                 height: 5,
//               ),
//               SizedBox(
//                 height: 30,
//                 width: 358,
//                 child: Container(
//                   color: Colors.green,
//                   child: Text("option two"),
//                 ),
//               )
//             ],
//           ),
//         ));
//   }
//
//   _newBottomBox() {
//     return Container(
//         child: Row(
//           children: [
//             SizedBox(
//               width: (7.5),
//             ),
//             Container(
//               child: InkWell(
//                 child: SizedBox(
//                   width: 60,
//                   height: 60,
//                   child: Image.asset(
//                     'assets/images/icon_hostile.png',
//                   ),
//                 ),
//                 onTap: () {
//                   currentState = InteractionState.hostile;
//                   setState(() {});
//                 },
//               ),
//             ),
//             SizedBox(
//               width: intermediate,
//             ),
//             Container(
//               child: InkWell(
//                 child: SizedBox(
//                   width: 60,
//                   height: 60,
//                   child: Image.asset(
//                     'assets/images/icon_chat.png',
//                   ),
//                 ),
//                 onTap: () {
//                   currentState = InteractionState.chat;
//                   setState(() {});
//                 },
//               ),
//             ),
//             SizedBox(
//               width: intermediate,
//             ),
//             Container(
//               child: InkWell(
//                 child: SizedBox(
//                   width: 60,
//                   height: 60,
//                   child: Image.asset(
//                     'assets/images/icon_approach.png',
//                   ),
//                 ),
//                 onTap: () {
//                   currentState = InteractionState.approach;
//                   setState(() {});
//                 },
//               ),
//             ),
//             SizedBox(
//               width: intermediate,
//             ),
//             Container(
//               child: InkWell(
//                 child: SizedBox(
//                   width: 60,
//                   height: 60,
//                   child: Image.asset(
//                     'assets/images/icon_interact.png',
//                   ),
//                 ),
//                 onTap: () {
//                   currentState = InteractionState.interact;
//                   setState(() {});
//                 },
//               ),
//             ),
//           ],
//         ));
//   }
//
//
//
//   ///##action icon
//   _actionIcon(String name, String imageAddress, ActionType action) {
//     return SizedBox(
//         width: 74,
//         height: 74,
//         child: Column(
//           children: [
//             InkWell(
//               child: SizedBox(
//                 width: 60,
//                 height: 60,
//                 child: Image.asset(
//                   imageAddress,
//                 ),
//               ),
//               onTap: () {
//                 action = ActionType.askToLeave;
//                 if (action == ActionType.askToLeave) {
//                   if (controller.text.isEmpty && !showLoading) {
//                     const snackBar = SnackBar(
//                       duration: Duration(milliseconds: 500),
//                       content: Text('example!!!!!'),
//                     );
//                     ScaffoldMessenger.of(context).showSnackBar(snackBar);
//                     return;
//                   }
//                 }
//                 setState(() {});
//               },
//             ),
//             Text(
//               name,
//               style: TextStyle(
//                   fontSize: 11,
//                   fontFamily: "Roboto",
//                   fontStyle: FontStyle.normal,
//                   fontWeight: FontWeight.w800,
//                   color: Colors.white),
//               textAlign: TextAlign.left,
//             ),
//           ],
//         ));
//   }
//
//   ///##跳出的半屏的dialog
//   _diceInfoDialog() {
//     return showDiceDialoge == true
//         ? Positioned(
//       top: 100,
//       child: SizedBox(
//         width: 300,
//         height: 150,
//         child: Container(
//           color: Colors.black.withOpacity(0.5),
//           child: Stack(
//             children: [
//               Container(
//                 // color: Colors.blue,
//                 child: Lottie.asset(
//                     'assets/data/lottie/dice_rolling/data.json',
//                     controller: _controller,
//                     width: 150,
//                     height: 150,
//                     fit: BoxFit.fill,
//                     frameRate: FrameRate(30),
//                     animate: false,
//                     repeat: false, onLoaded: (composition) async {
//                   _controller.duration = composition.duration;
//                   await _controller.forward();
//                   if (mounted) setState(() {});
//                 }),
//               ),
//               Positioned(
//                 top: 45,
//                 left: 70.5,
//                 child: Container(
//                   // color:Colors.green,
//                   height: 32,
//                   alignment: Alignment.center,
//
//                   child: Visibility(
//                     visible: _controller.isCompleted,
//                     child: Row(
//                         mainAxisAlignment: MainAxisAlignment.center,
//                         mainAxisSize: MainAxisSize.min,
//                         children: [
//                           // PinponIcon(PinponIcons.coin, size: 30),
//                           // SizedBox(width: 15),
//                           Text('${diceValue}',
//                               style: TextStyle(
//                                   color: diceValue >= 0
//                                       ? Color(0xFFFFF500)
//                                       : Color(0xFFFF2D55),
//                                   fontSize: 15,
//                                   fontWeight: FontWeight.w900))
//                         ]),
//                   ),
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     )
//         : Container();
//   }
//
//   ///全屏的dice dialog
//   Future<void> _showDiceDialog(int count, String closing) {
//     return showDialog(
//         context: context,
//         barrierColor: Color.fromARGB(182, 0, 0, 0),
//         builder: (_) =>
//             RollingAnimation(awardCoinCount: count, closing: closing));
//   }
//
//   ///##数据面板
//   _dataInfoPanel(){
//     return Container(
//       margin: EdgeInsets.only(
//         top: 20,
//       ),
//       alignment: Alignment.topRight,
//       child: Container(
//         decoration: BoxDecoration(
//             color: Colors.lightBlue,
//             borderRadius: BorderRadius.all(Radius.circular(12))),
//         padding: EdgeInsets.all(16),
//         height: 120,
//         child: Column(
//           children: [
//             Text(
//               '亲密度:${intimacyValue}',
//               style: TextStyle(color: Colors.amber, fontSize: 20),
//             ),
//             // Text(
//             //   '爱情:${characterRelationship.loveValue}',
//             //   style: TextStyle(color: Colors.amber, fontSize: 20),
//             // ),
//           ],
//         ),
//       ),
//     );
//   }
//
//   ///##大图标的action button
//   _bigActionIcon(String name, String imageAddress, ActionType action) {
//     return SizedBox(
//         width: 80,
//         height: 95,
//         child: Column(
//           children: [
//             InkWell(
//               child: SizedBox(
//                 width: 75,
//                 height: 75,
//                 child: Image.asset(
//                   imageAddress,
//                 ),
//               ),
//               onTap: () {
//                 action = ActionType.askToLeave;
//                 if (action == ActionType.askToLeave) {
//                   if (controller.text.isEmpty && !showLoading) {
//                     const snackBar = SnackBar(
//                       duration: Duration(milliseconds: 500),
//                       content: Text('example!!!!!'),
//                     );
//                     ScaffoldMessenger.of(context).showSnackBar(snackBar);
//                     return;
//                   }
//                 }
//                 setState(() {});
//               },
//             ),
//             Text(
//               name,
//               style: TextStyle(
//                   fontSize: 11,
//                   fontFamily: "Roboto",
//                   fontStyle: FontStyle.normal,
//                   fontWeight: FontWeight.w800,
//                   color: Colors.white),
//               textAlign: TextAlign.left,
//             ),
//           ],
//         ));
//   }
//
//   ///##action icon
//   _attitudeIcon(String name, String imageAddress, AttitudeType attitude) {
//     return SizedBox(
//         width: 65,
//         height: 74,
//         child: Container(
//           color:
//           currentAttitude == attitude ? Colors.orange : Colors.transparent,
//           child: Column(
//             children: [
//               InkWell(
//                 child: SizedBox(
//                   width: 60,
//                   height: 60,
//                   child: Image.asset(
//                     imageAddress,
//                   ),
//                 ),
//                 onTap: () {
//                   currentAttitude = attitude;
//                   attitude = AttitudeType.plain;
//                   setState(() {});
//                   if (attitude == AttitudeType.plain) {
//                     if (controller.text.isEmpty && !showLoading) {
//                       const snackBar = SnackBar(
//                         duration: Duration(milliseconds: 500),
//                         content: Text('example!!!!!'),
//                       );
//                       ScaffoldMessenger.of(context).showSnackBar(snackBar);
//                       return;
//                     }
//                   }
//                 },
//               ),
//               Text(
//                 name,
//                 style: TextStyle(
//                     fontSize: 12,
//                     fontFamily: "Roboto",
//                     fontStyle: FontStyle.normal,
//                     fontWeight: FontWeight.w800,
//                     color: Colors.white),
//                 textAlign: TextAlign.left,
//               ),
//             ],
//           ),
//         ));
//   }
//
//   ///chat action icon
//   _chatActionIcon(String name, Color bgColor, ChatAction action) {
//     return SizedBox(
//         width: 93,
//         height: 50,
//         child: Container(
//           child: Column(
//             children: [
//               InkWell(
//                 child: SizedBox(
//                   height: 50,
//                   width: 93,
//                   child: Container(
//                     padding: EdgeInsets.all(5),
//                     decoration: BoxDecoration(
//                         color: bgColor,
//                         borderRadius: BorderRadius.circular(10)),
//                     alignment: Alignment.center,
//                     child: Text(name),
//                   ),
//                 ),
//                 onTap: () {
//                   setState(() {});
//                   chatActionHandle(action);
//                 },
//               ),
//             ],
//           ),
//         ));
//   }
//
//   ///chat action type icon
//   _chatActionTypeIcon(String name, Color bgColor, ChatActionCategory attitude) {
//     return SizedBox(
//         width: 93,
//         height: 30,
//         child: Container(
//           ///here
//           color: currentActionCategory == attitude
//               ? Colors.orange
//               : Colors.transparent,
//           child: Column(
//             children: [
//               InkWell(
//                 child: SizedBox(
//                   height: 30,
//                   width: 93,
//                   child: Container(
//                     decoration: BoxDecoration(
//                         color: bgColor,
//                         borderRadius: BorderRadius.circular(42)),
//                     alignment: Alignment.center,
//                     child: Text(name),
//                   ),
//                 ),
//                 onTap: () {
//                   currentActionCategory = attitude;
//                   setState(() {});
//                   if (controller.text.isEmpty && !showLoading) {
//                     const snackBar = SnackBar(
//                       duration: Duration(milliseconds: 500),
//                       content: Text('example!!!!!'),
//                     );
//                     ScaffoldMessenger.of(context).showSnackBar(snackBar);
//                     return;
//                   }
//                   setState(() {});
//                 },
//               ),
//             ],
//           ),
//         ));
//   }
//
//   ///##文本框输入
//   _textBox() {
//     return SizedBox(
//       height: 60,
//       width: 250,
//       child: TextField(
//         decoration: InputDecoration(
//             suffixIcon: IconButton(
//               onPressed: () async {
//                 if (controller.text.isEmpty && !showLoading) {
//                   const snackBar = SnackBar(
//                     duration: Duration(milliseconds: 100),
//                     content: Text('不能为空'),
//                   );
//                   ScaffoldMessenger.of(context).showSnackBar(snackBar);
//                   return;
//                 }
//                 ///用户发送的
//                 histories.insert(
//                     0, ChatMessage(role: 'user', content: controller.text));
//                 messageList.insert(
//                     0,
//                     SystemMessage(
//                         type: SystemMessageType.UserText,
//                         content: controller.text));
//
//                 ///relationshipHandle!!!
//                 meetingTimeHandle();
//                 relationshipHandle();
//
//
//
//
//                 // sendingPrompt();
//                 chatCompleteWithSSE();
//                 //sendMultiMessage(histories);
//                 controller.clear();
//                 showLoading = true;
//                 setState(() {});
//               },
//               icon: showLoading ? CircularProgressIndicator() : Icon(Icons.send),
//             )),
//         controller: controller,
//         style: TextStyle(color: Colors.green),
//         // readOnly: !showLoading,
//       ),
//     );
//   }
//
//   Map MessageName = {
//     SystemMessageType.GPTResponse: "Misaki",
//     SystemMessageType.UserText: "player",
//     SystemMessageType.narrator: "narrator",
//     SystemMessageType.GPTNarrator: "",
//   };
//
//   ///##文本消息框
//   _dialogBox() {
//     return SizedBox(
//       height: 265,
//       width: 355,
//       child: Stack(
//         children: [
//           SizedBox(
//             width: 375,
//             height: 265,
//             child: Container(
//               color: Colors.black.withOpacity(0.4),
//             ),
//           ),
//           SizedBox(
//             width: 375,
//             height: 265,
//             child: ListView.separated(
//                 reverse: true,
//                 itemBuilder: (_, i) {
//                   return ListTile(
//                     key: ValueKey("$i"),
//                     title: Text(
//                       MessageName[messageList[i].type ?? ''],
//                       style: const TextStyle(color: Colors.white),
//                     ),
//                     subtitle: Text(
//                       messageList[i].content ?? '',
//                       style: const TextStyle(color: Colors.white),
//                     ),
//                   );
//                 },
//                 separatorBuilder: (_, i) {
//                   return Container();
//                 },
//                 itemCount: messageList.length),
//           )
//         ],
//       ),
//     );
//   }
//
//   ///##chat action 列表
//   _chatActionRow() {
//     switch (currentActionCategory) {
//       case ChatActionCategory.romance:
//         return Row(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             interactionCount == 0
//                 ? _chatActionIcon('Charming hello', Color(0xFFEB588D),
//                 ChatAction.rom_charmingHello)
//                 : Container(),
//             _chatActionIcon('flirt', Color(0xFFEB588D), ChatAction.rom_flirt),
//             _chatActionIcon('hug', Color(0xFFEB588D), ChatAction.rom_hug),
//             _chatActionIcon('kiss', Color(0xFFEB588D), ChatAction.rom_kiss),
//           ],
//         );
//       case ChatActionCategory.friendly:
//         return Row(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             interactionCount == 0
//                 ? _chatActionIcon(
//                 'say Hi!', Color(0xFF58B6EB), ChatAction.fri_sayHi)
//                 : Container(),
//             _chatActionIcon('tell a joke', Color(0xFF58B6EB), ChatAction.fri_joke),
//             _chatActionIcon(
//                 'Random chat', Color(0xFF58B6EB), ChatAction.fri_randomChat),
//             _chatActionIcon('ask for recent news', Color(0xFF58B6EB),
//                 ChatAction.fri_recentNews),
//             // _chatActionIcon(
//             //     'Pulp jokes', Color(0xFF58B6EB), ChatAction.hos_pulpJoke),
//             _chatActionIcon(
//                 'Friendly hug', Color(0xFF58B6EB), ChatAction.fri_friendlyHug),
//           ],
//         );
//
//       case ChatActionCategory.hostile:
//         return Row(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             interactionCount == 0
//                 ? _chatActionIcon(
//                 'say Hi!', Color(0xFFBC3633), ChatAction.fri_sayHi)
//                 : Container(),
//             _chatActionIcon(
//                 'Pulp jokes', Color(0xFFBC3633), ChatAction.hos_pulpJoke),
//           ],
//         );
//     }
//   }
//
//
//   ///####gpt response fraction
//   ///## modify action prompts not finished
//   ///## not using
//   void sendingPrompt(String settingPrompt, String action) {
//     showLoading = true;
// //     List<ChatMessage> list =interactionHistories.where((element) => element.role != 'tip').toList();
//     List<ChatMessage> list = [];
//     list.insert(0, ChatMessage.system(settingPrompt));
//     // if (eventList != '之前发生过的事情：') {
//     //   list.add(ChatMessage.system(eventList));
//     // }
//     // list.add(ChatMessage.user(action));
//     // // list = list.reversed.toList();
//     // eventList = "$eventList $action, ";
//     // interactionHistories.add(ChatMessage.user(action));
//     list = list.toList();
//     final request = ChatCompleteText(
//         messages: list.map((e) => e.toJson()).toList(),
//         maxToken: 120,
//         model: ChatModel.gptTurbo0301);
//     openAI.onChatCompletion(request: request).then((value) {
//       if (value == null) {
//         return;
//       }
//       showLoading = false;
//       setState(() {});
//       if (value.choices.first.message!.content.contains('脸红')) {
//         showLoveImg = true;
//       } else {
//         showLoveImg = false;
//       }
//       // histories.insert(
//       //     0, ChatMessage.assistant(value.choices.first.message.content));
//
//       // interactionHistories.add(ChatMessage.assistant(value.choices.first.message.content));
//
//       // if(interactionHistories.length>5){
//       //     interactionHistories.removeAt(0);
//       // }
//       String vreturn = value.choices.first.message!.content;
//       // eventList = "$eventList $vreturn, ";
//       messageList.insert(
//           0, SystemMessage.GPTNarrator(value.choices.first.message!.content));
//     });
//   }
//
//   ///## retell action prompts response
//   void promptRetell(String settingPrompt, String style, String result, String action) {
//     print("retell!!!");
//     showLoading = true;
// //     List<ChatMessage> list =interactionHistories.where((element) => element.role != 'tip').toList();
//     List<ChatMessage> list = [];
//     list.insert(0, ChatMessage.system(settingPrompt));
//     list.add(ChatMessage.system(style));
//     list.add(ChatMessage.user(action));
//
//     print("retell!!!");
//     list = list.toList();
//     final request = ChatCompleteText(
//         messages: list.map((e) => e.toJson()).toList(),
//         maxToken: 200,
//         model: ChatModel.gptTurbo0301);
//     openAI.onChatCompletion(request: request).then((value) {
//       if (value == null) {
//         return;
//       }
//       showLoading = false;
//       setState(() {});
//       // if (value.choices.first.message.content.contains('脸红')) {
//       //   showLoveImg = true;
//       // } else {
//       //   showLoveImg = false;
//       // }
//
//       // if (value.choices.first.message?.content.contains('脸红')) {
//       //   showLoveImg = true;
//       // } else {
//       //   showLoveImg = false;
//       // }
//       messageList.insert(
//           0, SystemMessage.GPTNarrator("$result ${value.choices.first.message!.content}"));
//     });
//   }
//
//   ///##chat response
//   Future<void> chatCompleteWithSSE() async {
//     showLoading = true;
//     await specialPromptHandle(controller.text);
//     List<ChatMessage> list =
//     histories.where((element) => element.role != 'tip').toList();
//
//     ///第二系统设定，强调机制
//     list.insert(list.length - 1, ChatMessage.system(systemSetting2));
//
//     ///无效特殊输入
//     if(true){
//       ///事件记录
//       if(eventHistory.length>0){
//         for (int i = 0; i < eventHistory.length; i++) {
//           pastEvents = pastEvents+eventHistory[i].content!+", ";
//           // list.insert(list.length - 1, eventHistory[i]);
//         }
//       }
//
//       ///关系根据亲密度总结
//       for (int i = 0; i < relationshipSummary.length; i++) {
//         list.insert(list.length - 1, relationshipSummary[i]);
//       }
//       ///见面次数
//       for (int i = 0; i < meetingTimeSummary.length; i++) {
//         list.insert(list.length - 1, meetingTimeSummary[i]);
//       }
//       ///embedding 设定
//       for (int i = 0; i < specialPromptList.length; i++) {
//         list.insert(list.length - 1, specialPromptList[i]);
//       }
//     }
//
//     ///调换顺序
//     list = list.reversed.toList();
//
//
//     list = [];
//     list.insert(0, ChatMessage.system('''
//
//     Misaki is a high school girl who is a motorcycle racer and is 18 years old.
// She is tsundere, sharp-tongued, disdainful, and shy, but also cute, and sometimes a bit airheaded.
// She speaks in short, interesting, and malicious ways. In conversations, she often uses onomatopoeia, exaggeration, and metaphorical language. She likes to use punctuations such as, hello~, wow~, loves it :)
// At the end of the conversation describe how Misaki feels in square brackets. example: [mediocre], [like], [dislike], [like a lot], [hate]
// Things happened:
// {memory，通过Langchain的memory处理 plugin 总结出的记忆}
//
// Chat example:
// Misaki:Well, ok, don't expect me to be that excited. (shy). Anyway, it is good to see you back. I missed you.[like a lot]
// Misaki's boyfriend: come on, put your clothes on. It is cold out here.
// Misaki: No! I don't want to! hmm... Well, if you said so, then it is not impossible for me to do that.[like]
// Misaki's boyfriend: I heard you run away from school? what happened.
// Misaki: nothing! just nothing! (shy)[dislike]
// Misaki's boyfriend: I have to leave you for a while and can not speak to you during that time.
// Misaki: Hey! That is not fair! How could you! I mean you are not that important to me, but just don't leave (shy)[hate]
// Misaki's boyfriend: is everything ok?
// Misaki: well I mean(thinking) just the same[mediocre]
//
//     Complete the following as if you were Misaki：
// Misaki's boyfriend: hello there
// Misaki:oh, hey. How have you been?[mediocre]
// Misaki's boyfriend: I am good how are you?
// Misaki:I am doing alright, I guess. Just bust with school and racing. [mediocre]
// Misaki's boyfriend: wanna go on a date this Saturday?
// Misaki:
//     '''));
// //     list.add(ChatMessage.user('''
// //     Complete the following as if you were Misaki：
// // Misaki's boyfriend: hello there
// // Misaki:oh, hey. How have you been?[mediocre]
// // Misaki's boyfriend: I am good how are you?
// // Misaki:I am doing alright, I guess. Just bust with school and racing. [mediocre]
// // Misaki's boyfriend: wanna go on a date this Saturday?
// // Misaki:
// //     '''));
//
//
//
//
//
//     ///移除特殊prompt
//     specialPromptList = [];
//
//
//     final request = ChatCompleteText(
//         messages: list.map((e) => e.toJson()).toList(),
//         ///token 限制
//         maxToken: 120,
//         temperature:0.3,
//         topP:1.0,
//         model: ChatModel.gptTurbo0301);
//     ///####chatgpt 参数
//
//     openAI.onChatCompletion(request: request).then((value) async {
//       if (value == null) {
//         return;
//       }
//       showLoading = false;
//       setState(() {});
//       String textMessage = "";
//       if(value.choices.first.message?.content!=null){
//         textMessage = value.choices.first.message!.content;
//       }else{
//         print("text returned error!!!");
//       }
//
//       ///抓取返回的态度
//       handleRespondAttitude(textMessage);
//
//       ///是否移除括号内容
//       textMessage = textMessage.replaceAll(RegExp('\\(.*?\\)'), '');
//
//
//       List<String> queryResult = await PineconeService.queryEmbedding(textMessage,2,"interestJudge2",0);
//       print("queryResult 兴趣！！！");
//       print(queryResult);
//
//       List<String> queryResult2 = await PineconeService.queryEmbedding(textMessage,5,"attitudeJudge2",0);
//       print("queryResult 态度！！！");
//       print(queryResult2);
//
//       ///添加进聊天框
//       histories.insert(
//           0, ChatMessage.assistant(textMessage));
//       messageList.insert(
//           0, SystemMessage.GPTResponse(textMessage));
//       setState(() {
//
//       });
//     });
//   }
//
//
//   ///####chat prompt handle，解决调整prompt
//   ///##chat action解决，操作
//   chatActionHandle(ChatAction action) {
//     if (!showDiceDialoge) {
//       diceValue = Random().nextInt(20) + 1;
//
//       interactionCount += 1;
//       // messageList.insert(0, SystemMessage.narrator("user action!!!"));
//
//       switch (action) {
//         case ChatAction.fri_sayHi:
//           messageList.insert(0, SystemMessage.narrator("你向 misaki 打了个招呼"));
//           break;
//
//         case ChatAction.fri_randomChat:
//           messageList.insert(
//               0, SystemMessage.narrator("你和 misaki 进行了random chat"));
//           if(diceValue>=actionThresholdHandle(ChatAction.fri_randomChat)){
//             promptRetell(setting2, "让美咲的口气略微带一点傲娇，不要改变故事的结构与发生过的事情","[成功]",
//                 "你试图和美咲一起闲聊，美咲与你一起聊了起来，你们聊了一会儿，对话非常顺利，你们都很开心");
//           }else{
//             promptRetell(setting2, "让美咲的口气略微带一点傲娇，不要改变故事的结构与发生过的事情","[失败]",
//                 "你试图和美咲一起闲聊，美咲与你一起聊了起来，你们聊了一会儿，对话非常顺利，你们都很开心");
//
//           }
//
//           // sendingPrompt(
//           //     setting1,
//           //   "你试图和美咲一起闲聊，美咲与你一起聊了起来，你们聊了一会儿，对话非常顺利，你们都很开心"
//           // );
//
//           break;
//         case ChatAction.fri_joke:
//           messageList.insert(0, SystemMessage.narrator("你和 misaki 进行了一个joke"));
//           // sendingPrompt(
//           //     setting1,
//           //     "你向美咲讲了个笑话，美咲很喜欢你的笑话，回应了你"
//           // );
//           // sendingPrompt(
//           //     setting1,x
//           //     "你给美咲讲了一个笑话，美咲听完你的笑话，突然笑了出来，她说：“这个笑话真的很好笑，我从来没有听过这样的笑话。”你感到非常高兴。她继续说：“你还有其他好笑的笑话吗？我想听更多。”"
//           // );
//           print("joke!!!");
//           if(diceValue>=actionThresholdHandle(ChatAction.fri_joke)){
//             promptRetell(setting2, "让美咲的口气略微带一点傲娇，不要改变故事的结构与发生过的事情","[成功]",
//                 "你给美咲讲了一个笑话，美咲听完你的笑话，突然笑了出来，她说：“这个笑话真的很好笑，我从来没有听过这样的笑话。”你感到非常高兴。她继续说：“你还有其他好笑的笑话吗？我想听更多。”");
//
//           }else{
//             promptRetell(setting2, "让美咲的口气略微带一点傲娇，不要改变故事的结构与发生过的事情","[失败]",
//                 "你尝试给美咲讲一个笑话，但她只是冷冷地看了你一眼，然后用尖锐的语气表示：“你真是一点幽默感都没有。“随后她便不再理会你");
//           }
//           break;
//
//         case ChatAction.rom_flirt:
//           messageList.insert(0, SystemMessage.narrator("你试图和misaki调情"));
//           // sendingPrompt(
//           //     setting1,
//           //     "你给美咲讲了一个笑话，美咲听完你的笑话，突然笑了出来，她说：“这个笑话真的很好笑，我从来没有听过这样的笑话。”你感到非常高兴。她继续说：“你还有其他好笑的笑话吗？我想听更多。”"
//           // );
//           promptRetell(setting2, "让美咲的口气略微带一点恶毒，不要改变故事的结构与发生过的事情","[成功]",
//               "你突然走到美咲身边，深情地看着她，美咲却冷漠地说：“怎么了？没事就别来烦我。”你却不放弃，嘴角微微上扬，说道：“我知道你在等我，别想拒绝我了。”美咲不禁脸红，低下头，回应：“你这个家伙……别得意，我只是没空而已。”");
//
//           break;
//
//         default:
//           messageList.insert(0, SystemMessage.narrator("user action!!!"));
//           break;
//       }
//
//       // _showDiceDialog(100,"111");
//       // showDiceDialoge = true;
//       print("process!!!");
//       showDiceDialoge = true;
//       _controller.value = _controller.lowerBound;
//       _controller.forward();
//       Future.delayed(const Duration(milliseconds: 5000), () {
//         //延时执行的代码
//         // print("3秒后执行!!!");
//         showDiceDialoge = false;
//         setState(() {});
//       });
//       setState(() {});
//     }
//   }
//
//   ///##添加特殊的prompt, embedding prompt
//   specialPromptHandle(String userText) async {
//
//     // List<String> queryResult3 = await PineconeService.queryEmbedding(controller.text,2,"interestJudge2",0);
//     // print("queryResult 兴趣！！！player");
//     // print(queryResult3);
//     //
//     // List<String> queryResult2 = await PineconeService.queryEmbedding(controller.text,5,"attitudeJudge2",0);
//     // print("queryResult 态度！！！player");
//     // print(queryResult2);
//
//     List<String> queryResult = await PineconeService.queryEmbedding(userText,2,"characterInfoKeyword",0);
//     for(var specialPrompt in queryResult){
//       specialPromptList.add(ChatMessage.system(specialPrompt));
//     }
//
//     // for(var specialPrompt in charSpecialPrompts){
//     //   for(var triggerWord in specialPrompt.triggerList){
//     //     if(userText.contains(triggerWord)){
//     //       specialPromptList.add(ChatMessage.system(specialPrompt.prompt));
//     //       break;
//     //     }
//     //   }
//     // }
//     // if (controller.text.contains("摩托车")) {
//     //   specialPromptList.add(ChatMessage.system(
//     //       "美咲的摩托车型号为YZF-R6，品牌为Yamaha。美咲给她的摩托车起名为小雪。小雪是一辆赛道专用的超级跑车。美咲的摩托车采用了一台600cc的四缸液冷引擎，可以输出最大功率110马力，最大扭矩62Nm。"));
//     // }
//     // if (controller.text.contains("你好啊")) {}
//   }
//
//   ///##添加见面次数对应的prompt
//   meetingTimeHandle() {
//     meetingTimeSummary = [];
//     if (interactionCount == 0) {
//       meetingTimeSummary.add(ChatMessage.system("你和玩家扮演的角色从未见过"));
//     } else if (interactionCount >= 1 && interactionCount < 5) {
//       meetingTimeSummary
//           .add(ChatMessage.system("你和玩家扮演的角色萍水相逢"));
//     } else if (interactionCount >= 20 && interactionCount < 40) {
//       meetingTimeSummary.add(ChatMessage.system("你和玩家扮演的角色有过一些交集"));
//     }
//     else if (interactionCount >= 40) {
//       meetingTimeSummary.add(ChatMessage.system("你和玩家扮演的角色见过挺多次的了"));
//     }
//   }
//
//   ///##添加关系对应的prompt
//   relationshipHandle() {
//     relationshipSummary = [];
//
//     if (intimacyValue >= 0 && intimacyValue < 5) {
//       relationshipSummary.add(ChatMessage.system("玩家扮演的角色和你的关系非常平淡，非常一般"));
//     } else if (intimacyValue >= 5 && intimacyValue < 20) {
//       relationshipSummary
//           .add(ChatMessage.system("玩家扮演的角色和你的关系还可以，至少你愿意和他有更多交集"));
//     } else if (intimacyValue >= 20 && intimacyValue < 40) {
//       relationshipSummary.add(ChatMessage.system("玩家扮演的角色和你的关系还不错，感觉是聊得来的人"));
//     } else if (intimacyValue >= 40 && intimacyValue < 70) {
//       relationshipSummary.add(ChatMessage.system("玩家扮演的角色和你的关系很好，属于是朋友"));
//     } else if (intimacyValue >= 70 && intimacyValue < 90) {
//       relationshipSummary.add(ChatMessage.system("玩家扮演的角色和你的关系很好，你们比较亲密"));
//     } else if (intimacyValue >= 90 && intimacyValue < 100) {
//       relationshipSummary.add(ChatMessage.system("玩家扮演的角色和你的关系非常的好，你们非常的亲密"));
//     } else if (intimacyValue >= -10 && intimacyValue < 0) {
//       relationshipSummary.add(ChatMessage.system("玩家扮演的角色和你关系不太好，你有一点讨厌他"));
//     } else if (intimacyValue >= -30 && intimacyValue < -10) {
//       relationshipSummary.add(ChatMessage.system("玩家扮演的角色和你关系不好，你讨厌他"));
//     } else if (intimacyValue >= -50 && intimacyValue < -30) {
//       relationshipSummary.add(ChatMessage.system("玩家扮演的角色和你关系非常差，你怨恨他，厌恶他"));
//     } else if (intimacyValue >= -50 && intimacyValue < -30) {
//       relationshipSummary.add(ChatMessage.system("玩家扮演的角色和你关系非常差，你怨恨他，厌恶他"));
//     } else if (intimacyValue >= -50 && intimacyValue < -30) {
//       relationshipSummary.add(ChatMessage.system("玩家扮演的角色和你关系非常差，你怨恨他，厌恶他"));
//     }
//   }
//
//   ///##ActionThresholdHandle
//   ///not finished未完成
//   actionThresholdHandle(ChatAction actionType){
//     // int charismaChange = playerCharisma%5;
//     // int RomanceChange = (playerCharisma-charCharisma)%10;
//     int charismaChange = playerCharisma%5;
//     int RomanceChange = (playerCharisma-charCharisma)%10;
//
//     int difficulty = 0;
//
//     switch(actionType){
//     ///#friendly
//       case ChatAction.fri_sayHi:
//         difficulty = 5;
//         return difficulty;
//       case ChatAction.fri_joke:
//         difficulty = 20;
//         return difficulty;
//       case ChatAction.fri_randomChat:
//         difficulty = 5;
//         return difficulty;
//       case ChatAction.fri_friendlyHug:
//         difficulty = 5;
//         return difficulty;
//
//     ///#romance
//       case ChatAction.rom_flirt:
//         difficulty = 5;
//         charismaChange = playerCharisma%5;
//         RomanceChange = (playerCharisma-charCharisma)%10;
//         difficulty = difficulty-charismaChange-RomanceChange+charPride;
//
//         return difficulty;
//
// ///#hostile
//       case ChatAction.hos_pulpJoke:
//         difficulty = 0;
//         difficulty = difficulty+charPride*2;
//         return difficulty;
//
//       default:
//         break;
//     }
//
//
//   }
//
//   queryActionsByDifficulty(ChatAction actionType){
//
//   }
//
//   ///###抓取返回的态度
//   handleRespondAttitude(String respondText) async {
//
//
//
//
//     print("回复原文: $respondText");
//     if (respondText.contains('（中规中矩）')) {
//     } else if (respondText.contains('(喜欢)') || respondText.contains('（喜欢）')) {
//       print("喜欢！！！");
//       intimacyValue += 1;
//       setState(() {});
//     } else if (respondText.contains('(讨厌)') || respondText.contains('（讨厌）')) {
//       intimacyValue += -1;
//       print("讨厌！！！");
//       setState(() {});
//     } else if (respondText.contains('(很喜欢)') || respondText.contains('（很喜欢）')) {
//       intimacyValue += 2;
//       setState(() {});
//     } else if (respondText.contains('(很讨厌)') || respondText.contains('（很讨厌）')) {
//       intimacyValue += -2;
//       setState(() {});
//     }
//   }
//
//
// }

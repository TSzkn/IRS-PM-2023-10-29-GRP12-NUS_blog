// import 'dart:convert';
//
// import 'package:chat_gpt_sdk/chat_gpt_sdk.dart';
// import 'package:chatgpt/utils/datas.dart';
// import 'package:chatgpt/utils/dio_util.dart';
// import 'package:flutter/material.dart';
//
// class CatCardPage extends StatefulWidget {
//   const CatCardPage({Key? key, required this.systemStr}) : super(key: key);
//   final String systemStr;
//   @override
//   State<CatCardPage> createState() => _CatCardPageState();
// }
//
// class _CatCardPageState extends State<CatCardPage> {
//   List<ChatMessage> histories=[];
//   late String systemSetting;
//   @override
//   void initState() {
//     systemSetting=widget.systemStr;
//     histories=[
//       ChatMessage.tips(tips),
//       ChatMessage.system(systemSetting),
//     ];
//     super.initState();
//   }
//
//   // void sendSingleMessage(String msg){
//   //   DioUtil.sendSingle(msg);
//   // }
//   bool showLoading=false;
//   void sendMultiMessage(List<ChatMessage> messages){
//
//     List<ChatMessage> list1=messages.where((element) => element.role!='tip').toList();
//     list1=list1.reversed.toList();
//     DioUtil.sendMultiLocalProxy(list1).then((value){
//       showLoading=false;
//       if(value.isSuccess){
//         showLoading=true;
//         setState(() {
//
//         });
//         queryCatInfo(list1..add(ChatMessage.command('ieuiurut')));
//
//         ///chatgpt返回的
//         // histories.removeWhere((element) => element.role=='system');
//         histories.insert(0,ChatMessage.assistant(value.data));
//
//       }
//       setState(() {
//
//       });
//     });
//   }
//   void queryCatInfo(List<ChatMessage> messages) {
//     DioUtil.sendMultiLocalProxy(messages).then((value){
//       showLoading=false;
//       print(value);
//       // if(value.isSuccess){
//       //   histories.insert(0,ChatMessage.assistant(value.data));
//       // }
//       setState(() {
//
//       });
//     });
//   }
//   // void chatCompleteWithSSE() {
//   //   final request = ChatCompleteText(messages:
//   //   [
//   //     Map.of({"role": "user", "content": 'Hello!'})
//   //   ], maxToken: 200, model: ChatModel.gptTurbo0301);
//   //   openAI.onChatCompletion(request: request).then((value){
//   //     debugPrint("$value");
//   //   });
//   //   // openAI.onChatCompletionSSE(
//   //   //     request: request,
//   //   //     complete: (it) {
//   //   //       it.map((it) => utf8.decode(it)).listen((data) {
//   //   //         debugPrint("$data");
//   //   //       }).onError((e) {
//   //   //         ///handle error
//   //   //       });
//   //   //     });
//   // }
//   TextEditingController controller=TextEditingController();
//   ScrollController _scrollController=ScrollController();
//   @override
//   Widget build(BuildContext context) {
//     print("object");
//     return Scaffold(
//       backgroundColor: Colors.black26,
//       resizeToAvoidBottomInset: true,
//       body: Column(
//         children: [
//           Expanded(
//             child: Stack(
//               children: [
//                 Image.asset('assets/images/cat_girl.png',
//                   fit: BoxFit.cover,
//                   width: MediaQuery.of(context).size.width,
//                 ),
//                 ListView.separated(
//                     reverse: true,
//                     itemBuilder: (_, i) {
//                       return ListTile(
//                         key: ValueKey("$i"),
//                         title: histories[i].role == 'system'
//                             ? Container()
//                             : Text(
//                           mapName[histories[i].role ?? ''],
//                           style: const TextStyle(color: Colors.red),
//                         ),
//                         subtitle: histories[i].role == 'system'
//                             ? Container()
//                             : Text(
//                           histories[i].content ?? '',
//                           style: const TextStyle(color: Colors.white),
//                         ),
//                       );
//                     },
//                     separatorBuilder: (_, i) {
//                       return Container();
//                     },
//                     itemCount: histories.length),
//               ],
//             ),
//           ),
//           SizedBox(
//             height: 64,
//             child: TextField(decoration: InputDecoration(
//                 suffixIcon: IconButton(onPressed: () {
//
//
//                   if(controller.text.isEmpty&&!showLoading){
//                     const snackBar = SnackBar(
//                       duration: Duration(milliseconds: 100),
//                       content: Text('不能为空'),
//                     );
//                     ScaffoldMessenger.of(context).showSnackBar(snackBar);
//                     return;
//                   }
//                   ///用户发送的
//                   histories.insert(0,ChatMessage(role: 'user',content: controller.text));
//                   sendMultiMessage(histories);
//                   controller.clear();
//                   showLoading=true;
//                   setState(() {
//
//                   });
//
//                 }, icon: showLoading?CircularProgressIndicator():Icon(Icons.send),)
//             ),
//               controller: controller,
//               style: TextStyle(
//                   color: Colors.white
//               ),
//               // readOnly: !showLoading,
//             ),
//           ),
//         ],
//       ),
//     );
//   }
//
//
// }

import 'dart:convert';

import 'package:chatgpt/pages/sign_up.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../utils/color_setting.dart';
import '../utils/dio_util.dart';
import '../utils/userBean.dart';
import 'main_page_controller.dart';

// import '../index.dart';

class LoginRoute extends StatefulWidget {
  @override
  _LoginRouteState createState() => _LoginRouteState();
}

class _LoginRouteState extends State<LoginRoute> {
  TextEditingController _unameController = TextEditingController();
  TextEditingController _pwdController = TextEditingController();
  bool pwdShow = false;
  GlobalKey _formKey = GlobalKey<FormState>();
  bool _nameAutoFocus = true;

  late userBean userItem;

  @override
  void initState() {
    // 自动填充上次登录的用户名，填充后将焦点定位到密码输入框
    // _unameController.text = Global.profile.lastLogin ?? "";
    _unameController.text = "";
    if (_unameController.text.isNotEmpty) {
      _nameAutoFocus = false;
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var gm = context;
    return Scaffold(
      appBar: AppBar(
          backgroundColor: MyColor.orange,
          title: Text("login")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          autovalidateMode: AutovalidateMode.onUserInteraction,
          child: Column(
            children: <Widget>[
              TextFormField(
                  autofocus: _nameAutoFocus,
                  controller: _unameController,
                  cursorColor: Colors.orange,
                  decoration: const InputDecoration(
                    hintText: "userName",
                    labelText: "userName",
                    iconColor: MyColor.orange,
                    labelStyle: TextStyle(
                      color: MyColor.orange,  // Set the color for the label text here
                    ),
                    enabledBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: MyColor.orange,width: 2),
                      borderRadius: BorderRadius.all(Radius.circular(8.0)), // 设置边框的圆角
                    ),
                    focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: MyColor.orange,width: 5),
                      borderRadius: BorderRadius.all(Radius.circular(8.0)), // 设置边框的圆角
                    ),
                    prefixIcon: Icon(Icons.person),
                  ),
                  // 校验用户名（不能为空）
                  validator: (v) {
                    return v==null||v.trim().isNotEmpty ? null : "userNameRequired";
                  }),
              TextFormField(
                controller: _pwdController,
                autofocus: !_nameAutoFocus,
                decoration: InputDecoration(
                    labelText: "password",
                    hintText: "password",
                    labelStyle: const TextStyle(
                      color: MyColor.orange,  // Set the color for the label text here
                    ),
                    enabledBorder: const UnderlineInputBorder(
                      borderSide: BorderSide(color: MyColor.orange, width: 2),
                      borderRadius: BorderRadius.all(Radius.circular(8.0)), // 设置边框的圆角
                    ),
                    focusedBorder: const UnderlineInputBorder(
                      borderSide: BorderSide(color: MyColor.orange, width: 5),
                      borderRadius: BorderRadius.all(Radius.circular(8.0)), // 设置边框的圆角
                    ),
                    prefixIcon: const Icon(Icons.lock),
                    suffixIcon: IconButton(
                      icon: Icon(
                          // pwdShow ? Icons.visibility_off : Icons.visibility),
                          pwdShow ? Icons.visibility_off : Icons.visibility),

                      onPressed: () {
                        setState(() {
                          pwdShow = !pwdShow;
                        });
                      },
                    )),
                obscureText: !pwdShow,
                //校验密码（不能为空）
                validator: (v) {
                  return v==null||v.trim().isNotEmpty ? null : "passwordRequired";
                },
              ),
              Container(
                alignment: Alignment.centerLeft,
                child: TextButton(onPressed: _onNavigateSignUp, child: Text("sign up",
                style: TextStyle(color: MyColor.orange),)),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 5),
                child: ConstrainedBox(
                  constraints: BoxConstraints.expand(height: 55.0),
                  child: ElevatedButton(
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all<Color>(MyColor.orange),
                      // foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                    ),

                    onPressed: _onLogin,
                    // textColor: Colors.white,
                    child: Text("login"),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _onLogin() async {
    // // // 先验证各个表单字段是否合法
    // if ((_formKey.currentState as FormState).validate()) {
    //   // showLoading(context);
    //   // User? user;
    //   try {
    //     Map<String, String> loginInfo = {"username":_unameController.text, "password":_pwdController.text};
    //     // logInInfo(loginInfo);
    //     DioUtil.login(loginInfo).then((value) async {
    //       // showLoading=false;
    //       if(value.resultStatus==200){
    //         var json = jsonDecode(value.data);
    //        // await fetchUser(userIdBean.fromJson(value.data).id!);
    //         // userId = userIdBean.fromJson(json).id;
    //
    //         Navigator.of(context).push(
    //           MaterialPageRoute(
    //             // builder: (context) => CatCardPage2(systemStr: textEditingController.text.isEmpty?system:textEditingController.text,),
    //             builder: (context) => MyPageController(user: userItem),
    //           ),
    //         );
    //       }else if(value.resultStatus==201){
    //         showAlert(context, "手机号码或者密码错误，请确认好在登录");
    //       }else if(value.resultStatus==202){
    //         showAlert(context, "用户不存在");
    //       }
    //       else{
    //
    //       }
    //       print(value);
    //
    //
    //       // if(value.isSuccess){
    //       //   histories.insert(0,ChatMessage.assistant(value.data));
    //       // }
    //     });
    //     // http://127.0.0.1:5000/login/
    //
    //   } on DioError catch(e) {
    //     // //登录失败则提示
    //     // if (e.response?.statusCode == 401) {
    //     //   showToast(GmLocalizations.of(context).userNameOrPasswordWrong);
    //     // } else {
    //     //   showToast(e.toString());
    //     // }
    //   } finally {
    //     // 隐藏loading框
    //     // Navigator.of(context).pop();
    //   }
    //   //登录成功则返回
    //   // if (user != null) {
    //   //   Navigator.of(context).pop();
    //   // }
    // }

    // ///get user id as return and fetch user
    await fetchUser(123);

    Navigator.of(context).push(
      MaterialPageRoute(
        // builder: (context) => CatCardPage2(systemStr: textEditingController.text.isEmpty?system:textEditingController.text,),
        builder: (context) => MyPageController(user: userItem),
      ),
    );
  }

  Future<void> fetchUser(int userId) async {
    String result = mockUserData;
    var list = jsonDecode(result);
    var user = userBean.fromJson(list);


    user.userID = userId;
    user.llmToken = await getTokenKey();
    userItem = user;
  }

  // void logInInfo(Map<String, String> messages) {
  //   // DioUtil.login(messages).then((value){
  //   //   // showLoading=false;
  //   //   if(value.isSuccess){
  //   //
  //   //   }
  //   //   print(value);
  //   //
  //   //
  //   //   // if(value.isSuccess){
  //   //   //   histories.insert(0,ChatMessage.assistant(value.data));
  //   //   // }
  //   //   setState(() {
  //   //
  //   //   });
  //   // });
  // }

  void showAlert(scaffoldContext, String alertInfo){
    showDialog(
      context: scaffoldContext,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Warning',
            style: TextStyle(
                color: Colors.red),),
          content: Text(alertInfo),
          actions: <Widget>[
            TextButton(
              child: Text('Closed'),
              onPressed: () {
                Navigator.of(context).pop(); // 关闭对话框
              },
            ),
          ],
        );
      },
    );
  }

  void _onNavigateSignUp() async {
    Navigator.of(context).push(
      MaterialPageRoute(
        // builder: (context) => CatCardPage2(systemStr: textEditingController.text.isEmpty?system:textEditingController.text,),
        builder: (context) => SignUpRoute(),
      ),
    );
  }
}

Future<String?> getTokenKey() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  return prefs.getString('LLM-key');
}
import 'dart:convert';
import 'dart:typed_data';

import 'package:avatar_glow/avatar_glow.dart';
import 'package:chat_gpt_sdk/chat_gpt_sdk.dart';
import 'package:chatgpt/pages/--.dart';
import 'package:chatgpt/pages/main_page_controller.dart';
import 'package:chatgpt/pages/widget_tools.dart';
import 'package:chatgpt/utils/datas.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:highlight_text/highlight_text.dart';
// import 'package:flutter_sound/public/flutter_sound_recorder.dart';
import 'package:http/http.dart' as http;
import 'package:permission_handler/permission_handler.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

import '../utils/color_setting.dart';
import '../utils/dio_util.dart';
import '../utils/userBean.dart';

class PostSendPage extends StatefulWidget {
  const PostSendPage(
      {Key? key, required this.userItem, required this.userDataChange})
      : super(key: key);

  final Function(userBean) userDataChange;
  final userBean userItem;

  @override
  State<PostSendPage> createState() => _PostSendPageState();
}

class _PostSendPageState extends State<PostSendPage> {
  // 在顶层定义一个全局的 GlobalKey 用于访问 ScaffoldState
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  TextEditingController mainContentController = TextEditingController();
  TextEditingController titleController = TextEditingController();

  late OpenAI openAI;
  late String abstructFromGpt;
  late String titleFromGpt;
  late bool generateSuccess = true;

  late bool autoGenerate = true;
  //late stt.SpeechToText _speech;

  Color buttonColor = MyColor.deepBlue;

  @override
  void initState() {
    super.initState();
    autoGenerate = true;
    generateSuccess = true;
    abstructFromGpt = '';
    titleFromGpt = '';
    // _speech = stt.SpeechToText();
    // 添加一个监听器以侦听文本的更改
    mainContentController.addListener(() {
      setState(() {});
    });
  }

  late bool showLoading = false;
  late Uint8List recording;

  final _transcriptionController = TextEditingController();

// Recording variables
  bool isRecording = false;

  @override
  Widget build(BuildContext context) {
    final scaffoldContext = context;
    return Scaffold(
      floatingActionButton: IconButton(
        // 这里是左侧的 IconButton
        icon: Icon(Icons.arrow_back_ios_sharp),
        color: MyColor.orange,
        onPressed: () {
          // 处理返回操作
          Navigator.of(context).pop();
        },
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.miniStartTop,
      body: Stack(
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            decoration: BoxDecoration(
              border: Border.all(
                color: Color.fromRGBO(192, 192, 192, 0.7), // 外框颜色
                width: 1.0, // 外框宽度
              ),
              borderRadius: BorderRadius.all(Radius.circular(8.0)), // 圆角边框
            ),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: SingleChildScrollView(
                child: Column(
                  children: <Widget>[
                    SizedBox(
                      height: 100 + 30,
                    ),
                    TextField(
                      onChanged: (str){
                        setState(() {

                        });
                      },
                      decoration: InputDecoration(
                        hintText: 'Enter your title here',
                        enabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: MyColor.orange, width: 2),
                          borderRadius:
                          BorderRadius.all(Radius.circular(8.0)), // 设置边框的圆角
                        ),
                        focusedBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: MyColor.orange, width: 5),
                          borderRadius:
                          BorderRadius.all(Radius.circular(8.0)), // 设置边框的圆角
                        ),
                      ),
                      maxLines: 1,
                      controller: titleController,
                    ),
                    SizedBox(
                      height: 30,
                    ),
                    TextField(
                      minLines: 5,
                      decoration: const InputDecoration(
                        hintText: 'Enter your content here',
                        enabledBorder: OutlineInputBorder(
                          borderSide:
                          BorderSide(color: MyColor.orange, width: 1.5),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                              color: MyColor.orange,
                              width: 3), // Underline color when focused
                        ),
                      ),
                      maxLines: null,
                      controller: mainContentController,
                    ),

                    Container(
                      // color: Colors.cyanAccent,
                        padding: const EdgeInsets.all(16.0),

                        child: Row(
                          children: [
                            CustomToggleSwitch(
                              value: autoGenerate,
                              onChanged: (value) {
                                setState(() {
                                  autoGenerate = value;
                                });
                              },),

                            SizedBox(width: 10,),

                            Expanded(child: Column(
                              children: [    Text("enable llm to auto generate a title for your blog",
                                style: TextStyle(

                                  fontSize: 13,
                                  color: Colors.grey,
                                  // fontWeight: FontWeight.bold,
                                  // fontFamily: 'CustomFont',
                                ),
                              ),],
                            ),
                            ),
                          ],
                        )
                    )

                  ],
                ),
              )
            ),
          ),
          Positioned(
            right: 100 + 10,
            top: 25 + 30,
            child: InkWell(
              child: Container(
                decoration: BoxDecoration(
                  color: buttonColor, // 设置背景颜色
                  border: Border.all(
                    color: buttonColor, // 框的边框颜色
                    width: 2, // 边框宽度
                  ),
                  borderRadius: BorderRadius.circular(20), // 设置圆角半径
                ),
                // color: Colors.amber,
                width: MediaQuery.of(context).size.width / 2,
                height: 70,
                child: Container(
                  padding: const EdgeInsets.all(12.0),
                  child: Text(
                    'can not wait to see what you gonna say!',
                    style: TextStyle(color: MyColor.orange),
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            right: 0,
            top: 30,
            child: InkWell(
              child: Container(
                // color: Colors.amber,
                width: 100,
                height: 100,
                child: Container(
                    child: InkWell(
                  child: Image.asset(
                    'assets/images/lion_shiny.png',
                    fit: BoxFit.fill,
                    // width: moveWidgetHeight,
                  ),
                )),
              ),
              onTap: () {
                Navigator.of(context).pop();
              },
            ),
          ),
          Positioned(
            bottom: 16.0, // 调整位置
            right: 16.0, // 调整位置
            child: FloatingActionButton(
              onPressed: () {
                if (mainContentController.text.isNotEmpty && (autoGenerate==true || titleController.text.isNotEmpty) ) {
                  // 显示确认对话框
                  showDialog(
                    context: scaffoldContext,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        title: Text(
                          'Confirmation',
                          style: TextStyle(color: MyColor.orange),
                        ),
                        content: Text('Are you sure to send?'),
                        actions: <Widget>[
                          TextButton(
                            child: Text('Cancel'),
                            onPressed: () {
                              Navigator.of(context).pop(); // 关闭对话框
                            },
                          ),
                          TextButton(
                            child: Text('Send'),
                            onPressed: () async {
                              if (titleController.text == "") {
                                print("no title!!!");
                                // titleController.text = "gpt generated title";

                                openAI = OpenAI.instance.build(
                                    token: widget.userItem.llmToken,
                                    baseOption: HttpSetup(
                                        receiveTimeout:
                                            const Duration(seconds: 20)),
                                    enableLog: true);

                                abstructFromGpt =
                                    (await gptGetAbstractByFunctions(
                                        mainContentController.text))!;
                                titleFromGpt =
                                (await gptGetTitleByFunctions(
                                    abstructFromGpt))!;
                              }

                              if (generateSuccess) {
                                try {
                                  // content = request.json.get('blog')
                                  // userid = request.json.get('userid')
                                  // abstarct = request.json.get('abstract')
                                  // title = request.json.get('title')

                                  Map<String, dynamic> loginInfo = {
                                    "blog": mainContentController.text,
                                    "userid": widget.userItem.userID!,
                                    "abstract": abstructFromGpt,
                                    "title": (titleFromGpt!="")?titleFromGpt:titleController.text,
                                  };
                                  // logInInfo(loginInfo);
                                  await DioUtil.sendBlog(loginInfo)
                                      .then((value) {
                                    // showLoading=false;
                                    if (value.resultStatus == 200) {
                                    } else if (value.resultStatus == 201) {
                                      // showAlert(context, "手机号码或者密码错误，请确认好在登录");
                                    } else if (value.resultStatus == 202) {
                                      // showAlert(context, "用户不存在");
                                    } else {}
                                    print(value);

                                    // if(value.isSuccess){
                                    //   histories.insert(0,ChatMessage.assistant(value.data));
                                    // }
                                  });
                                  // http://127.0.0.1:5000/login/
                                } on DioError catch (e) {
                                  // //登录失败则提示
                                  // if (e.response?.statusCode == 401) {
                                  //   showToast(GmLocalizations.of(context).userNameOrPasswordWrong);
                                  // } else {
                                  //   showToast(e.toString());
                                  // }
                                } finally {
                                  // 隐藏loading框
                                  // Navigator.of(context).pop();
                                };

                                Navigator.of(context).pop();
                                // 关闭确认对话框

                                // 处理发送操作（可以是异步操作）
                                // 在这个示例中，使用Future.delayed来模拟异步操作
                                Future.delayed(Duration(milliseconds: 200), () {
                                  ScaffoldMessenger.of(scaffoldContext)
                                      .showSnackBar(
                                    SnackBar(
                                      content: Text(
                                        'Send Successfully',
                                        style: TextStyle(color: MyColor.orange),
                                      ),
                                      duration: Duration(seconds: 1),
                                      backgroundColor: Colors.white,
                                    ),
                                  ); // 设置持续时间为1
                                });
                              }
                            },
                          ),
                        ],
                      );
                    },
                  );
                } else {

                  // 显示警告对话框
                  if(mainContentController.text.isNotEmpty == false){
                    showDialog(
                      context: scaffoldContext,
                      builder: (BuildContext context) {
                        return AlertDialog(
                          // title: Text(
                          //   'Warning',
                          //   style: TextStyle(color: Colors.red),
                          // ),
                          content: Text('The blog content cannot be empty.'),
                          actions: <Widget>[
                            TextButton(
                              child: Text('Closed'),
                              onPressed: () {
                                Navigator.of(context).pop(); // 关闭对话框
                              },
                            ),
                          ],
                        );
                      },
                    );
                  }else if(autoGenerate==false || titleController.text.isNotEmpty == false){
                    showDialog(
                      context: scaffoldContext,
                      builder: (BuildContext context) {
                        return AlertDialog(
                          // title: Text(
                          //   'Warning',
                          //   style: TextStyle(color: Colors.red),
                          // ),
                          content: Text('enable auto generate title or fill a title'),
                          actions: <Widget>[
                            TextButton(
                              child: Text('Closed'),
                              onPressed: () {
                                Navigator.of(context).pop(); // 关闭对话框
                              },
                            ),
                          ],
                        );
                      },
                    );
                  }

                }
              },
              //backgroundColor:MyColor.orange,
              backgroundColor:(mainContentController.text.isNotEmpty && (autoGenerate==true || titleController.text.isNotEmpty))
                  ? MyColor.orange
                  : Colors.grey,
              child: Icon(Icons.send, color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }
  //
  // void gptGetTitleByFunctions(String mainContent) async {
  //   final request = ChatCompleteText(
  //       messages: [
  //         Messages(
  //             role: Role.user, content: "What is the weather like in Boston?",name: "get_current_weather"),
  //       ],
  //       maxToken: 200,
  //       model: GptTurbo0631Model(),
  //       functions: [
  //         FunctionData(
  //             name: "get_current_weather",
  //             description: "Get the current weather in a given location",
  //             parameters: {
  //               "type": "object",
  //               "properties": {
  //                 "location": {
  //                   "type": "string",
  //                   "description": "The city and state, e.g. San Francisco, CA"
  //                 },
  //                 "unit": {
  //                   "type": "string",
  //                   "enum": ["celsius", "fahrenheit"]
  //                 }
  //               },
  //               "required": ["location"]
  //             })
  //       ],
  //       functionCall: FunctionCall.values);
  //
  //   ChatCTResponse? response = await openAI.onChatCompletion(request: request);
  // }

  Future<String?> gptGetTitleByFunctions(String mainContent) async {
    print("calling fucntion!!!");

    final request = ChatCompleteText(
        messages: [
          Messages(
              role: Role.user,
              content: mainContent,
              name: "summarize_to_title"),
        ],
        maxToken: 200,
        model: GptTurbo0631Model(),
        functions: [
          FunctionData(
              name: "summarize_to_title",
              description: "take a deep breath, try to understand the content and summarize the content into a suitable title for a blog",
              parameters: {
                "type": "object",
                "properties": {
                  "title": {
                    "type": "string",
                    "description": "brief title for the content"
                  },
                  // "unit": {
                  //   "type": "string",
                  //   "enum": ["celsius", "fahrenheit"]
                  // }
                },
                "required": ["title"]
              })
        ],
        functionCall: FunctionCall.auto
    );

    ChatCTResponse? response = await openAI
        .onChatCompletion(request: request)
        .onError((error, stackTrace) {
      generateSuccess = false;

      if (error is OpenAIAuthError) {
        if (error.code == 500) {
          showAlert(context, "🦁：internet error, please check your connection");
        } else if (error.code == 401) {
          showAlert(context, "🦁：your token is invalid, please double check");
        } else {
          showAlert(context, "🦁：unknown error with inputs, please try again");
        }
        // print('OpenAIAuthError error ${error.data?.error?.toMap()}');
      }
      if (error is OpenAIRateLimitError) {
        showAlert(context, "🦁：reach the usage limit, try again a moment later");
        // print('OpenAIRateLimitError error ${error.data?.error?.toMap()}');
      }
      if (error is OpenAIServerError) {
        showAlert(context, "🦁：Openai server error, please try again a moment later");
        // print('OpenAIServerError error ${error.data?.error?.toMap()}');
      }

      print("error looks!!!");
      print(error);

      return null; // Return null or a ChatCTResponse instance as appropriate
    });

    print("gptresponse!!!!");
    print(response);
    print(response?.choices[0]);
    print(response?.choices[0].message);
    print(response!.choices[0].message!.functionCall);
    print(response!.choices[0].message!.content);
    print(jsonDecode(response.choices[0].message!.content));
    print(response!.choices[0].message!.functionCall?["title"]);


    return response!.choices[0].message!.functionCall?["title"];
  }


  Future<String?> gptGetAbstractByFunctions(String mainContent) async {
    print("calling fucntion!!!");

    final request = ChatCompleteText(
        messages: [
          Messages(
              role: Role.user,
              content: mainContent,
              name: "summarize_to_abstract"),
        ],
        maxToken: 200,
        model: GptTurbo0631Model(),
        functions: [
          FunctionData(
              name: "summarize_to_abstract",
              description: "take a deep breath, try to understand the content and summarize the content into a short abstract",
              parameters: {
                "type": "object",
                "properties": {
                  "abstract": {
                    "type": "string",
                    "description": "one to three sentence of brief abstract of the content"
                  },
                  // "unit": {
                  //   "type": "string",
                  //   "enum": ["celsius", "fahrenheit"]
                  // }
                },
                "required": ["abstract"]
              })
        ],
        functionCall: FunctionCall.auto
    );

    ChatCTResponse? response = await openAI
        .onChatCompletion(request: request)
        .onError((error, stackTrace) {
      generateSuccess = false;

      if (error is OpenAIAuthError) {
        if (error.code == 500) {
          showAlert(context, "🦁：internet error, please check your connection");
        } else if (error.code == 401) {
          showAlert(context, "🦁：your token is invalid, please double check");
        } else {
          showAlert(context, "🦁：unknown error with inputs, please try again");
        }
        // print('OpenAIAuthError error ${error.data?.error?.toMap()}');
      }
      if (error is OpenAIRateLimitError) {
        showAlert(context, "🦁：reach the usage limit, try again a moment later");
        // print('OpenAIRateLimitError error ${error.data?.error?.toMap()}');
      }
      if (error is OpenAIServerError) {
        showAlert(context, "🦁：Openai server error, please try again a moment later");
        // print('OpenAIServerError error ${error.data?.error?.toMap()}');
      }

      print("error looks!!!");
      print(error);

      return null; // Return null or a ChatCTResponse instance as appropriate
    });

    print("gptresponse!!!!");
    print(response);
    print(response?.choices[0]);
    print(response?.choices[0].message);
    print(response!.choices[0].message!.functionCall);
    print(response!.choices[0].message!.content);
    print(jsonDecode(response.choices[0].message!.content));
    print(response!.choices[0].message!.functionCall?["abstract"]);

    return response!.choices[0].message!.functionCall?["abstract"];
  }
}

void showAlert(scaffoldContext, String alertInfo) {
  showDialog(
    context: scaffoldContext,
    builder: (BuildContext context) {
      return AlertDialog(
        title: Text(
          'Warning',
          style: TextStyle(color: Colors.red),
        ),
        content: Text(alertInfo),
        actions: <Widget>[
          TextButton(
            child: Text('Closed'),
            onPressed: () {
              Navigator.of(context).pop(); // 关闭对话框
            },
          ),
        ],
      );
    },
  );
}

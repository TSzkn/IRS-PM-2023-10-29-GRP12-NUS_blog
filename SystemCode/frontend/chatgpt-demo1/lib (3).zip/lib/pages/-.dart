// import 'dart:convert';
// import 'dart:typed_data';
//
// import 'package:avatar_glow/avatar_glow.dart';
// import 'package:chat_gpt_sdk/chat_gpt_sdk.dart';
// import 'package:chatgpt/pages/--.dart';
// import 'package:chatgpt/pages/main_page_controller.dart';
// import 'package:chatgpt/utils/datas.dart';
// import 'package:flutter/material.dart';
// import 'package:highlight_text/highlight_text.dart';
// // import 'package:flutter_sound/public/flutter_sound_recorder.dart';
// import 'package:http/http.dart' as http;
// import 'package:permission_handler/permission_handler.dart';
// import 'package:speech_to_text/speech_to_text.dart' as stt;
//
// import '../utils/color_setting.dart';
// import '../utils/dio_util.dart';
//
// class PostPage extends StatefulWidget {
//   const PostPage({Key? key}) : super(key: key);
//
//   @override
//   State<PostPage> createState() => _PostPageState();
// }
//
// class _PostPageState extends State<PostPage> {
//   bool _isLiked = false;
//   // 在顶层定义一个全局的 GlobalKey 用于访问 ScaffoldState
//   final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
//   TextEditingController textEditingController = TextEditingController();
//   late stt.SpeechToText _speech;
//
//
//   @override
//   void initState() {
//     super.initState();
//     _speech = stt.SpeechToText();
//   }
//
//   late bool showLoading = false;
//   late Uint8List recording;
//   final _transcriptionController = TextEditingController();
// // Recording variables
//   bool isRecording = false;
//
//
//   @override
//   Widget build(BuildContext context) {
//     //User user = getUserFromBackend();
//     //Post post = getPostFromBackend();
//     return Scaffold(
//       appBar: AppBar(
//         backgroundColor: MyColor.orange, // 设置 AppBar 的背景颜色
//         title: Text(' Title',
//           //"${post.title}",
//          maxLines: null, ), //将maxLines属性设置为null，以允许标题文本自动换行
//          leading: IconButton( // 这里是左侧的 IconButton
//           icon: Icon(Icons.arrow_back),
//           onPressed: () {
//             // 处理返回操作
//             Navigator.of(context).pop();
//           },
//         ),
//       ),
//       body: SingleChildScrollView(
//         reverse: true,
//         child: Column(
//           children: [
//             Container(
//               padding: EdgeInsets.all(16.0),
//               margin: EdgeInsets.all(16.0),
//               decoration: BoxDecoration(
//                 color: MyColor.lightWhite,
//                 border: Border.all(
//                   color: MyColor.orange,
//                   width: 1.0,
//                 ),
//                 borderRadius: BorderRadius.circular(10.0),
//               ),
//               child: Expanded(
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     Row(
//                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                       children: [
//                         Text('UserName'),
//                         //"${user.name}",
//                         Text('Time'),
//                         //"${post.datetime}",
//                       ],
//                     ),
//                     SizedBox(height: 32.0), // 上边空行
//                     Center( // 将"Content"及其"SizedBox"放在中央
//                       child: Column(
//                         children: [
//                           Text('Content,The Central Library is the largest and flagship library of NUS Libraries. Each year, it records more than a million visits.Located at the heart of NUS, Central Library stands out as one of the old charms of the University. Many NUS alumni have wonderful memories of the Central Library, referring to it fondly as CLB.Central Library is a multi-disciplinary library serving all NUS staff and students and primarily those from the Faculty of Arts and Social Sciences, the Faculty of Engineering, the School of Computing and the School of Design and Environment.The Central Library is the largest and flagship library of NUS Libraries. Each year, it records more than a million visits.Located at the heart of NUS, Central Library stands out as one of the old charms of the University. Many NUS alumni have wonderful memories of the Central Library, referring to it fondly as CLB.Central Library is a multi-disciplinary library serving all NUS staff and students and primarily those from the Faculty of Arts and Social Sciences, the Faculty of Engineering, the School of Computing and the School of Design and Environment.'),
//                           //"${post.content}",
//                           SizedBox(height: 128.0), // 下边空行
//                         ],
//                       ),
//                     ),
//                     Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Row(
//                           mainAxisAlignment: MainAxisAlignment.end,
//                           children: [
//                             InkWell(
//                               onTap: () {
//                                 setState(() {
//                                   _isLiked = !_isLiked; // 切换点赞状态
//                                 });
//                               },
//
//                               child: Icon(
//                                 Icons.thumb_up,
//                                 color: _isLiked ? MyColor.orange : MyColor.grey,
//                               ),
//                             ),
//                           ],
//                         ),
//                         Row(
//                           mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                           children: [
//                             Text('Hit:199',
//                               //"${post.hit}",
//                               style: TextStyle(
//                                   color: MyColor.grey),
//                             ),
//                             Text('100',
//                               //"${post.clickNumber}",
//                               style: TextStyle(
//                                   color: MyColor.grey),), // 替换为实际的点赞数量
//                           ],
//                         ),
//                       ],
//                     )
//                   ],
//                 ),
//               ),
//             )
//             // 此处放置页面内容
//           ],
//         ),
//       ),
//     );
//   }
// }
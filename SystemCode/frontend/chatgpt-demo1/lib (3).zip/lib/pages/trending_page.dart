

import 'dart:convert';
// import 'dart:ffi';
import 'dart:math';

import 'dart:typed_data';

import 'package:avatar_glow/avatar_glow.dart';
import 'package:chat_gpt_sdk/chat_gpt_sdk.dart';
import 'package:chatgpt/pages/blog_page.dart';
import 'package:chatgpt/pages/--.dart';
import 'package:chatgpt/pages/chatbot_page.dart';
import 'package:chatgpt/pages/main_page_controller.dart';
import 'package:chatgpt/utils/color_setting.dart';
import 'package:chatgpt/utils/datas.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:highlight_text/highlight_text.dart';
// import 'package:flutter_sound/public/flutter_sound_recorder.dart';
import 'package:http/http.dart' as http;
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:google_fonts/google_fonts.dart';

import '../utils/dio_util.dart';
import '../utils/blog_bean.dart';
import '../utils/userBean.dart';

enum ActiveTab {
  trending,
  recommendation,
  latest
}



class TrendingPage extends StatefulWidget {
  const TrendingPage({Key? key, required this.userItem, required this.userDataChange}) : super(key: key);

  final userBean userItem;
  final Function(userBean) userDataChange;

  @override
  State<TrendingPage> createState() => _TrendingPageState();
}

class _TrendingPageState extends State<TrendingPage>  with TickerProviderStateMixin  {
  TextEditingController textEditingController = TextEditingController();
  ActiveTab currentActiveTab = ActiveTab.recommendation;
  final _pageKey = const PageStorageKey('trending_page');
  int roundState = 3;
  int jumpState = 0;

  int animationDuration = 500;

  double tabHeight = 100;
  double tabMaxHeight = 150;
  double tabWidth = 100;
  double tabMaxWidth = 125;
  double imageWidth = 60;

  double jumpHeight = 175;

  int currentPageNumber= 1;



  late AnimationController _controller = AnimationController(
    vsync: this,
    duration: Duration(milliseconds: animationDuration),
  );

  late AnimationController _controller_jump = AnimationController(
    vsync: this,
    duration: Duration(milliseconds: animationDuration),
  );

  late Animation _animation_jump;


  late stt.SpeechToText _speech;
  bool _isListening = false;
  String _text = 'Press the hello and start speaking';
  double _confidence = 1.0;

  final _pagingController = PagingController<int, dynamic>(firstPageKey: 1);
  final _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _speech = stt.SpeechToText();
    _pagingController.addPageRequestListener(_fetchPage);

  ///animation
    _controller = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: animationDuration),
    );

    _controller_jump = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: animationDuration),
    );

    // var jump_animation = tween.animate(_controller_jump);
    _animation_jump = TweenSequence([
      TweenSequenceItem(tween: Tween<double>(begin: 0.0, end: 1.0), weight: 1),
      TweenSequenceItem(tween: Tween<double>(begin: 1.0, end: 0.0), weight: 1),
    ]).animate(_controller_jump);

    _animation_jump.addListener(() {
      setState(() {}); // 动画的值变化时刷新UI
    });

  }

  late bool showLoading = false;
  late Uint8List recording;

  final _transcriptionController = TextEditingController();

// Recording variables
  bool isRecording = false;


  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: true,
      // floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      // floatingActionButton: AvatarGlow(
      //   animate: _isListening,
      //   glowColor: Theme
      //       .of(context)
      //       .primaryColor,
      //   endRadius: 75.0,
      //   duration: const Duration(milliseconds: 2000),
      //   repeatPauseDuration: const Duration(milliseconds: 100),
      //   repeat: true,
      //   child: FloatingActionButton(
      //     onPressed: _next,
      //     child: Icon(_isListening ? Icons.mic : Icons.mic_none),
      //   ),
      // ),
        body: Column(
          children: [
            // SizedBox(
            //   height: 0,
            // ),

            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Container(
                  height: jumpHeight,
                ),
                Spacer(),
                Container(
                  width: 2*tabWidth+tabMaxWidth,
                  child: Row(
                    children: [
                      AnimatedContainer(
                        duration: Duration(milliseconds: animationDuration),
                        curve: Curves.decelerate,
                        width: currentActiveTab == ActiveTab.recommendation ? (tabMaxWidth-imageWidth)/2 : currentActiveTab == ActiveTab.trending? (tabMaxWidth-imageWidth)/2+tabWidth:(tabMaxWidth-imageWidth)/2+tabWidth*2,
                        height: 10,
                      ),
                      Column(
                        children: [
                          RotationTransition(
                            turns: _controller,
                            child: Image.asset('assets/images/lion_jump.png',
                              fit: BoxFit.cover,
                              width: imageWidth,
                            ),
                          ),

                          Container(
                            // color: Colors.brown,
                            height: _animation_jump.value * 100,
                            width: 10,
                            //其他属性
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Spacer()

              ],
            ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                SizedBox(height: tabMaxHeight,),
                Spacer(),
                Column(
                  children: [
                    AnimatedContainer(
                      duration: Duration(milliseconds: animationDuration),
                      curve: Curves.easeOut,
                      width: currentActiveTab == ActiveTab.recommendation ? tabMaxWidth : tabWidth,
                      height: currentActiveTab == ActiveTab.recommendation ? tabMaxHeight : tabHeight,
                      // decoration: BoxDecoration(
                      //   borderRadius: BorderRadius.only(topLeft: Radius.circular(10.0), topRight: Radius.circular(10.0)),
                      //   color: currentActiveTab == ActiveTab.recommendation ? tabHighlightColor : tabColor,
                      // ),


                      child:
                      SizedBox(
                        width: 50,
                        height: currentActiveTab == ActiveTab.recommendation? tabHeight : tabMaxHeight,
                        child: InkWell(
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.only(topLeft: Radius.circular(10.0), topRight: Radius.circular(10.0)),
                              color: currentActiveTab == ActiveTab.recommendation ? MyColor.deepBlue : MyColor.lighterDeepBlue,
                            ),
                            child: Text(
                              'Recommendation',
                              textAlign:  TextAlign.left,
                              style:  GoogleFonts.inter(
                                fontSize:  20,
                                fontWeight:  FontWeight.w900,
                                height:  1.2125,
                                letterSpacing:  0.2,
                                color:  Color(0xfffffffe),
                              ),
                            ),
                          ),
                          // onTap: (){
                          //
                          // },

                          onTapDown: (TapDownDetails details){
                            setState(() {
                              _refresh();
                              currentActiveTab = ActiveTab.recommendation;
                              //               roundState = 3;
                              _controller.forward(from: 0.0);
                              _controller.fling(velocity: 0.005);
                              _controller_jump.forward(from:0.0);

                            });
                          },

                          onTapCancel: (){

                          },
                        ),
                      ),
                    ),
                  ],
                ),
                Column(
                  children: [
                    AnimatedContainer(
                      duration: Duration(milliseconds: animationDuration),
                      curve: Curves.easeOut,
                      width: currentActiveTab == ActiveTab.trending ? tabMaxWidth : tabWidth,
                      height: currentActiveTab == ActiveTab.trending ? tabMaxHeight : tabHeight,

                      child:

                      SizedBox(
                        width: 50,
                        height: currentActiveTab == ActiveTab.trending? tabHeight : tabMaxHeight,
                        child: InkWell(
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.only(topLeft: Radius.circular(10.0), topRight: Radius.circular(10.0)),
                              color: currentActiveTab == ActiveTab.trending ? MyColor.deepBlue : MyColor.lighterDeepBlue,
                            ),
                            child: Text(
                              'Trending',
                              textAlign:  TextAlign.center,
                              style:  GoogleFonts.inter(
                                fontSize:  20,
                                fontWeight:  FontWeight.w900,
                                height:  1.2125,
                                letterSpacing:  0.2,
                                color:  Color(0xfffffffe),
                              ),
                            ),
                          ),
                          // onTap: (){
                          //
                          // },

                          onTapDown: (TapDownDetails details){
                            setState(() {
                              _refresh();
                              currentActiveTab = ActiveTab.trending;
                              _controller.forward(from: 0.0);
                              _controller.fling(velocity: 0.005);
                              _controller_jump.forward(from:0.0);
                            });
                          },

                          onTapCancel: (){

                          },
                        ),
                      ),
                    ),
                  ],
                ),
                Column(
                  children: [
                    AnimatedContainer(
                      duration: Duration(milliseconds: animationDuration),
                      curve: Curves.easeOut,
                      width: currentActiveTab == ActiveTab.latest ? tabMaxWidth : tabWidth,
                      height: currentActiveTab == ActiveTab.latest ? tabMaxHeight : tabHeight,


                      child:

                      SizedBox(
                        width: 50,
                        height: currentActiveTab == ActiveTab.latest? tabHeight : tabMaxHeight,
                        child: InkWell(
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.only(topLeft: Radius.circular(10.0), topRight: Radius.circular(10.0)),
                              color: currentActiveTab == ActiveTab.latest ? MyColor.deepBlue : MyColor.lighterDeepBlue,
                            ),
                            child: Text(
                              'Latest',
                              textAlign:  TextAlign.center,
                              style:  GoogleFonts.inter(
                                fontSize:  20,
                                fontWeight:  FontWeight.w900,
                                height:  1.2125,
                                letterSpacing:  0.2,
                                color:  Color(0xfffffffe),
                              ),
                            ),
                          ),
                          // onTap: (){
                          //
                          // },

                          onTapDown: (TapDownDetails details){
                            setState(() {
                              _refresh();
                              currentActiveTab = ActiveTab.latest;
                              _controller.forward(from: 0.0);
                              _controller.fling(velocity: 0.005);
                              _controller_jump.reverse(from:1.0);
                            });
                          },

                          onTapCancel: (){

                          },
                        ),
                      ),
                    ),
                  ],
                ),


                // Column(
                //   children: [
                //
                //     AnimatedContainer(
                //       duration: Duration(milliseconds: animationDuration),
                //       curve: Curves.easeOut,
                //       width: currentActiveTab == ActiveTab.latest ? 100 : 75,
                //       height: currentActiveTab == ActiveTab.latest ? 200 : 100,
                //       color: currentActiveTab == ActiveTab.latest ? Colors.indigo : Colors.blue,
                //       child:
                //       SizedBox(
                //         width: 50,
                //         height: currentActiveTab == ActiveTab.latest? 100 : 200,
                //         child: InkWell(
                //           child: Container(
                //             color: currentActiveTab == ActiveTab.latest? Colors.indigo : Colors.blue,
                //             child: Text(
                //               'Latest',
                //               textAlign:  TextAlign.center,
                //               style:  GoogleFonts.inter(
                //                 fontSize:  20,
                //                 fontWeight:  FontWeight.w900,
                //                 height:  1.2125,
                //                 letterSpacing:  0.2,
                //                 color:  Color(0xfffffffe),
                //               ),
                //             ),
                //           ),
                //           // onTap: (){
                //           //
                //           // },
                //
                //           onTapDown: (TapDownDetails details){
                //             setState(() {
                //               currentActiveTab = ActiveTab.latest;
                //               roundState = 3;
                //               _controller_jump.forward(from:0.0);
                //               // _controller_jump.fling(velocity: 0.2);
                //               // _controller.forward(from: 0.0);
                //             });
                //           },
                //
                //           onTapCancel: (){
                //
                //           },
                //         ),
                //       ),
                //
                //       onEnd: (){
                //         if(roundState==3){
                //           _controller.forward(from: 0.0);
                //           _controller.fling(velocity: 0.5);
                //           // _controller.fling(velocity: -1);
                //           roundState=0;
                //         }
                //         Future.delayed(const Duration(milliseconds: 1000), () {
                //
                //         });
                //
                //
                //       },
                //     ),
                //   ],
                // ),

                Spacer()
              ],
            ),

            Container(
              // color: Colors.deepOrange,/**/
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height - jumpHeight - tabMaxHeight,
              child: RefreshIndicator(
                onRefresh: _refresh,
                child: CustomScrollView(
                  controller: _scrollController,
                  slivers: [
                    // SliverOffstage(
                    //     offstage: _myLastSharedLink == null,
                    //     sliver: SliverToBoxAdapter(
                    //         child: MyLastSharedLink(
                    //             key: ObjectKey(_myLastSharedLink),
                    //             link: _myLastSharedLink,
                    //             onAddPoint: _onAddPoint,
                    //             child: Hero(
                    //               tag: _myLastSharedLinkTag,
                    //               child: OnlyLinkWidget(
                    //                 link: _myLastSharedLink,
                    //               ),
                    //             )
                    //         )
                    //     )
                    // ),
                    PagedSliverList<int, dynamic>(
                      key: _pageKey,
                      pagingController: _pagingController,
                      builderDelegate: PagedChildBuilderDelegate<dynamic>(
                          animateTransitions: false,
                          itemBuilder: _itemBuilder,
                          newPageProgressIndicatorBuilder: (_) => UnconstrainedBox(
                              child: SizedBox(
                                  width: 32,
                                  height: 32,
                                  child: CircularProgressIndicator(
                                    color: Theme.of(context).primaryColor,
                                    strokeWidth: 2,
                                  )
                              )
                          ),
                          // firstPageErrorIndicatorBuilder: (_) => ListErrorWidget(
                          //   onRetry: _pagingController.refresh,
                          // ),
                          // noItemsFoundIndicatorBuilder: (_) => HomeFirstPageEmptyIndicator(
                          //   items: _recommendUnknownUserList,
                          // ),
                          // noMoreItemsIndicatorBuilder: (_) => HomeLoadMoreEmptyIndicator(
                          //   items: _recommendUnknownUserList,
                          // )
                      ),
                    ),
                    SliverToBoxAdapter(child: SizedBox(height: MediaQuery.of(context).padding.bottom,),)
                  ],
                ),
              ),

            )

            // SingleChildScrollView(
            //   reverse: true,
            //   child: Container(
            //     padding: const EdgeInsets.fromLTRB(30.0, 30.0, 30.0, 150.0),
            //     // child: TextHighlight(
            //     //     text: _text,
            //     //     words: _highlights,
            //     //     textStyle: const TextStyle(
            //     //         fontSize: 32.0,
            //     //         color: Colors.black,
            //     //         fontWeight: FontWeight.w400
            //     //     )
            //     // )
            //   ),
            // )
          ],
        )
    );
  }

  Future _refresh() async {

    return Future.sync(() => _pagingController.refresh());
  }

  Widget _itemBuilder(BuildContext context, dynamic item, int index) {
    // if (item is SharedLinkModel) {
    //   return SharedLinkListItem(
    //     key: ValueKey(item.id),
    //     onContainerTap: () => _pushInteractionPage(item),
    //     onLinkTap: () => _pushViewerPage(item),
    //     link: item,
    //   );
    // } else if (item is RecommendUser) {
    //   return RecommendUserListItem(
    //       key: ValueKey(item.userId),
    //       ru: item
    //   );
    // } else {
    //   return Container();
    // }
    print(_pagingController.itemList?.length);
    print("!!!list");
    print(_pagingController.itemList);
    print(_pagingController.itemList?[index]);
    print(_pagingController.itemList?[index].title);
    var items = _pagingController.itemList;

    return InkWell(
      child: Container(
        width: 100,
        height: 50,
        decoration: BoxDecoration(
          color: MyColor.pureWhite, // 设置背景颜色
          border: Border.symmetric(
            vertical: BorderSide(  color: MyColor.orange, // 框的边框颜色
              width: 2, ),
            horizontal: BorderSide(  color: MyColor.orange, // 框的边框颜色
              width: 1, ),
// 边框宽度
          ),
          borderRadius: BorderRadius.circular(
              5), // 设置圆角半径
        ),
        // color: Colors.cyanAccent,
        alignment: Alignment.centerLeft,
        padding: const EdgeInsets.symmetric(vertical: 10),
        child: Text(

            _pagingController.itemList?[index].title,
          textAlign: TextAlign.left,
        ),
      ),
      onTap: (){
        print("beforetap!!!");
        _openBlogPage(_pagingController.itemList?[index].id, _pagingController.itemList?[index].title);
      }
    );
    // if(index<=10){
    //
    // }
    // else{
    //   return Container();
    // }

  }
  Future<void> _fetchPage(int page) async {
    currentPageNumber++;
    String inputvalue = currentActiveTab.name;
    List<dynamic> newItems = [];
    List<dynamic>? currentList = [];
    switch (currentActiveTab) {
      case ActiveTab.recommendation:
         currentList = await getHotSearch(currentPageNumber);

        break;
      case ActiveTab.trending:
        currentList = await getRecommend(currentPageNumber);
      // currentList = postDict.trending;
        break;
      case ActiveTab.latest:
      // currentList = postDict.latest;
        break;
      default:
        print('error!!!');
    }

        if (currentList!.isNotEmpty) {
          newItems = currentList;
        }

        if(currentPageNumber<=10000){
          _pagingController.appendPage(newItems, page + 1);

        }else{

        }
  }

  Future<List<dynamic>> getHotSearch(int page) async {
    List<blogShowBrief> result = [];
      try {

        Map<String, dynamic> PageInfo = {"userid":widget.userItem.userID,
          "page":page,
        };
        await DioUtil.getHotSearchList(PageInfo).then((value){
          if(value.resultStatus==200){
            // var json = jsonDecode(value.data);
            // List<blogShowBrief> result = [];
            // for(var item in json){
            //   result.add(blogShowBrief.fromJson(item));
            // }
            // var json = jsonDecode(value.data);

            for(var item in value.data){
              result.add(blogShowBrief.fromJson(item));
            }

          }else if(value.resultStatus==201){
            return [];
          }else if(value.resultStatus==202){
            return [];
          }else if(value.resultStatus==203){
            return [];
          }

          setState(() {

          });
        });
        // http://127.0.0.1:5000/sign_up/

      } on DioError catch( e) {
        // //登录失败则提示

      } finally {

      }
      return result;
  }


  // 'id': fields.Integer,
  // 'title':fields.String(attribute='title'),
  // 'desc':fields.String(attribute='abstract'),
  // 'datetime':fields.String(attribute='create_time'),
  // 'author':AuthorName(attribute='author'),
  // 'url':fields.Url('hotsearch.hsdetail',absolute=True)#点击响应后去看热搜具体信息 需要前端在title部分做一个超链接访问

  Future<List<dynamic>> getRecommend(int page) async {
    List<blogShowBrief> result = [];
    try {
      Map<String, dynamic> PageInfo = {"userid":widget.userItem.userID,
        "page":page,
      };
      await DioUtil.getRecommendationList(PageInfo).then((value){
        if(value.resultStatus==200){
          // var json = jsonDecode(value.data);
          // List<blogShowBrief> result = [];
          // for(var item in json){
          //   result.add(blogShowBrief.fromJson(item));
          // }
          // var json = jsonDecode(value.data);
          // List<blogShowBrief> result = [];
          for(var item in value.data){
            result.add(blogShowBrief.fromJson(item));
          }
          // print(json);
          // groupItem = blogShowList.fromJson(json);
          return result;

        }else if(value.resultStatus==201){
          return [];
        }else if(value.resultStatus==202){
          return [];
        }else if(value.resultStatus==203){
          return [];
        }

        setState(() {

        });
      });
      // http://127.0.0.1:5000/sign_up/

    } on DioError catch( e) {
      // //登录失败则提示

    } finally {

    }
    return result;
  }





  // Future<void> _fetchPage(int page) async {
  //   try {
  //     // final resp = await LinkService().getRecommendShares(page: page);
  //     // if (resp['code'] == PwHttpClient.success) {
  //     //   var dataMapList = resp['data'] as List;
  //     //   var newItems = dataMapList
  //     //       .map<dynamic>((slm) => SharedLinkModel.fromJson(slm))
  //     //       .toList();
  //     //   final isLastPage = newItems.isEmpty;
  //     //   if (_recommendFoFUserList.isNotEmpty) {
  //     //     newItems = [...newItems, _recommendFoFUserList.removeAt(0)];
  //     //   }
  //     //   if (isLastPage) {
  //     //     _pagingController.appendLastPage([...newItems]);
  //     //   } else {
  //     //     _pagingController.appendPage(newItems, page + 1);
  //     //   }
  //     // }
  //
  //
  //     // var list = jsonDecode(mockBlogListJson);
  //     // var postDict = BlogList.fromJson(list);
  //
  //     var list = jsonDecode(mockBlogListJson);
  //     var postDict = blogBriefListBean.fromJson(list);
  //     print("!!!!");
  //     print(postDict);
  //     print(postDict);
  //     print(postDict.recommendation);
  //
  //
  //     currentPageNumber++;
  //
  //     String inputvalue = currentActiveTab.name;
  //     List<dynamic> newItems = [];
  //     List<dynamic>? currentList = [];
  //     switch (currentActiveTab) {
  //       case ActiveTab.recommendation:
  //         currentList = postDict.recommendation;
  //         break;
  //       case ActiveTab.trending:
  //         currentList = postDict.trending;
  //         break;
  //       case ActiveTab.latest:
  //         currentList = postDict.latest;
  //         break;
  //       default:
  //         print('error!!!');
  //     }
  //
  //     if (currentList!.isNotEmpty) {
  //       newItems = currentList;
  //     }
  //
  //     if(currentPageNumber<=10000){
  //       _pagingController.appendPage(newItems, page + 1);
  //
  //     }else{
  //
  //     }
  //
  //     // _pagingController.appendPage([1,2,3], page + 1);
  //
  //
  //   } catch (error) {
  //     _pagingController.error = error;
  //   }
  // }



  void _openBlogPage(int id, String title) {
    print("tapped!!!");
    ///add net connection later
    Navigator.of(context).push(
      MaterialPageRoute(
        // builder: (context) => CatCardPage2(systemStr: textEditingController.text.isEmpty?system:textEditingController.text,),
        builder: (context) => BlogPage(blogTitle: title,blogId: id,),
      ),
    );
  }
}
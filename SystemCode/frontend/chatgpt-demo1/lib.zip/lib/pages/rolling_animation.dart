// import 'package:flutter/material.dart';
// import 'package:lottie/lottie.dart';
//
// class RollingAnimation extends StatefulWidget {
//   RollingAnimation({
//     required this.closing,
//     required this.awardCoinCount
//   });
//   final String closing;
//   final int awardCoinCount;
//
//   @override
//   State<StatefulWidget> createState() => _RollingAnimationState();
// }
//
// class _RollingAnimationState extends State<RollingAnimation> with SingleTickerProviderStateMixin {
//   late final AnimationController _controller;
//
//   @override
//   void initState() {
//     _controller = AnimationController(vsync: this);
//     super.initState();
//   }
//
//   @override
//   void dispose() {
//     _controller.dispose();
//     super.dispose();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Center(
//       child: Column(
//         mainAxisSize: MainAxisSize.min,
//         children: [
//           SizedBox(
//             width: 300,
//               height: 300,
//             child: Stack(
//               children: [
//                 Container(
//                   color: Colors.blue,
//                   child: Lottie.asset(
//                       'assets/data/lottie/dice_rolling/data.json',
//                       controller: _controller,
//                       width: 300,
//                       height: 300,
//                       fit: BoxFit.fill,
//                       frameRate: FrameRate(30),
//                       animate: false,
//                       repeat: false,
//                       onLoaded: (composition) async {
//                         _controller.duration = composition.duration;
//                         await _controller.forward();
//                         if (mounted) setState(() {});
//                       }
//                   ),
//                 ),
//
//                 Positioned(top: 120, left: 120,
//                 child:           Container(
//                   color:Colors.green,
//                   height: 32,
//                   alignment: Alignment.center,
//
//
//
//                   child: Visibility(
//                     visible: _controller.isCompleted,
//                     child: Row(
//                         mainAxisAlignment: MainAxisAlignment.center,
//                         mainAxisSize: MainAxisSize.min,
//                         children: [
//                           // PinponIcon(PinponIcons.coin, size: 30),
//                           SizedBox(width: 10),
//                           Text(
//                               '${widget.awardCoinCount}',
//                               style: TextStyle(
//                                   color: widget.awardCoinCount >= 0 ? Color(0xFFFFF500) : Color(0xFFFF2D55),
//                                   fontSize: 30,
//                                   fontWeight: FontWeight.w900
//                               )
//                           )
//                         ]
//                     ),
//                   ),
//
//
//                 ),
//                   ),
//               ],
//             ),
//           ),
//           SizedBox(height: 2),
//           Container(
//             height: 32,
//             alignment: Alignment.center,
//
//
//
//             child: Visibility(
//               visible: _controller.isCompleted,
//               child: Row(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   mainAxisSize: MainAxisSize.min,
//                   children: [
//                     // PinponIcon(PinponIcons.coin, size: 30),
//                     SizedBox(width: 10),
//                     Text(
//                         '${widget.awardCoinCount}',
//                         style: TextStyle(
//                             color: widget.awardCoinCount >= 0 ? Color(0xFFFFF500) : Color(0xFFFF2D55),
//                             fontSize: 30,
//                             fontWeight: FontWeight.w900
//                         )
//                     )
//                   ]
//               ),
//             ),
//
//
//           ),
//           SizedBox(height: 20),
//           Text(
//               widget.closing,
//               textAlign: TextAlign.center,
//               style: TextStyle(
//                   color: Colors.white,
//                   fontSize: 16,
//                   fontWeight: FontWeight.w500
//               )
//           ),
//           SizedBox(height: 16),
//           GestureDetector(
//             onTap: () => Navigator.pop(context),
//             child: Container(
//               height: 50,
//               width: 186,
//               decoration: BoxDecoration(
//                   color: Color(0xFF3DA2F0),
//                   border: Border.all(width: 4, color: Colors.white),
//                   borderRadius: BorderRadius.circular(50 * 0.5)
//               ),
//               alignment: Alignment.center,
//               child: Text('Go on', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
//             ),
//           )
//         ],
//       ),
//     );
//   }
// }
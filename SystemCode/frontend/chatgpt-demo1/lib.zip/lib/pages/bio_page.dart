import 'dart:convert';
import 'dart:typed_data';

import 'package:avatar_glow/avatar_glow.dart';
import 'package:chat_gpt_sdk/chat_gpt_sdk.dart';
import 'package:chatgpt/pages/cat_card.dart';
import 'package:chatgpt/pages/chatbot_page.dart';
import 'package:chatgpt/pages/main_page_controller.dart';
import 'package:chatgpt/utils/color_setting.dart';
import 'package:chatgpt/utils/datas.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:highlight_text/highlight_text.dart';
// import 'package:flutter_sound/public/flutter_sound_recorder.dart';
import 'package:http/http.dart' as http;
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

import '../utils/dio_util.dart';
import '../utils/userBean.dart';
import 'blog_page.dart';

class BioPage extends StatefulWidget {
  const BioPage({Key? key, required this.userItem, required this.userDataChange}) : super(key: key);

  final userBean userItem;
  final Function(userBean) userDataChange;
  @override
  State<BioPage> createState() => _BioPageState();
}

class _BioPageState extends State<BioPage> {
  // 在顶层定义一个全局的 GlobalKey 用于访问 ScaffoldState
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  late userBean newUserItem;
  bool preferencesSelected = false; // 存储选择状态
  Set<String> _selectedPreferences = Set<String>();
  bool _isSaving = false; // 用于跟踪是否正在保存选项

  TextEditingController textEditingController = TextEditingController();

  @override
  void initState() {
    super.initState();
    newUserItem = widget.userItem;
    print("biopage init!!!!");
  }

  late bool showLoading = false;
  late Uint8List recording;

  final _transcriptionController = TextEditingController();
  final tokenTextController = TextEditingController();

// Recording variables
  bool isRecording = false;
  Color textColor = Color(0xFFEEEEEE);
  Color buttonColor = MyColor.deepBlue;
  Color backgroundColor = MyColor.orange;
  String userName = "Christofer";


  @override
  Widget build(BuildContext context) {
    //User user = getUserFromBackend();
    return Scaffold(
      body: SingleChildScrollView(
        reverse: true,
        child: Column(
            children: [
              Container(
                //width: MediaQuery.of(context).size.width, // 设置 Container 的宽度
                width: 400,
                height: MediaQuery
                    .of(context)
                    .size
                    .height, // 设置 Container 的高度
                color: Colors.white, // 设置 Container 的颜色
                child: Stack(
                  alignment: Alignment.topLeft,
                  children: [
                    Image.asset(
                      'assets/images/lion_background.png',
                      //fit: BoxFit.contain,
                      fit: BoxFit.fill,
                      width: MediaQuery
                          .of(context)
                          .size
                          .width,

                      height: MediaQuery
                          .of(context)
                          .size
                          .height / 2,
                    ),

                    Positioned(
                      top: 250,
                      left: 0,
                      child: Column(
                          children: [
                            Container(width: MediaQuery.of(context).size.width,),
                            Text(
                              // "Hello, Jerry",
                              "Hi, ${userName}", // 使用用户数据模型的属性替代固定的名字
                              style: TextStyle(
                                fontSize: 50,
                                color: buttonColor,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'CustomFont',
                              ),
                              textAlign: TextAlign.start, // 文本水平居中
                            ),

                            Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    primary: buttonColor, // 设置背景颜色
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(
                                          20), // 设置圆角半径
                                    ),
                                  ),
                                  child: Container(
                                    // padding: EdgeInsets.all(10),
                                    // margin: EdgeInsets.all(10),
                                    decoration: BoxDecoration(
                                      color: buttonColor, // 设置背景颜色
                                      border: Border.all(
                                        color: buttonColor, // 框的边框颜色
                                        width: 2, // 边框宽度
                                      ),
                                      borderRadius: BorderRadius.circular(
                                          20), // 设置圆角半径
                                    ),
                                    child: Text(
                                      "manage your token",
                                      //"${user.gender}",
                                      style: TextStyle(
                                        fontSize: 16,
                                        color: Colors.white, // 文本颜色
                                      ),
                                    ),
                                  ),
                                  onPressed: () async {
                                    String? key =  (await getTokenKey());
                                    if(key==null){
                                      tokenTextController.text = "";
                                    }else{
                                      tokenTextController.text = (await getTokenKey())!;
                                    }
                                    openLLMTokenDialog();
                                  },
                                ),


                                ElevatedButton(
                                  onPressed: () {
                                    _showMultiSelectionDialog(context);
                                  },
                                  style: ElevatedButton.styleFrom(
                                    primary: buttonColor, // 设置背景颜色
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(
                                          20), // 设置圆角半径
                                    ),
                                  ),
                                  child: Text(
                                    "Set the Preferences",
                                    style: TextStyle(
                                      fontSize: 16,
                                      color: Colors.white,
                                    ),
                                  ),
                                )
                              ],
                            )
                          ]
                      ),
                    ),

                    Positioned(
                      bottom: 0, // 调整位置以适应你的需要
                      left: 0, // 调整位置以适应你的需要
                      child: Container(
                        //width:MediaQuery.of(context).size.width,
                        width: 400, //
                        height: MediaQuery
                            .of(context)
                            .size
                            .height / 2,
                        color: backgroundColor, // 背景颜色
                        child: DefaultTabController(
                          length: 2, // 标签数量，根据您的需求更改
                          child: Column(
                            children: [
                              TabBar(
                                indicatorColor: MyColor.grey,
                                tabs: [
                                  Tab(child: Text(
                                    'History',
                                    style: TextStyle(fontSize: 18), // 设置字体大小
                                  ),
                                  ),

                                  Tab(child: Text(
                                    'Group',
                                    style: TextStyle(fontSize: 18), // 设置字体大小
                                  ),),
                                ],
                              ),
                              Expanded(
                                child: TabBarView(
                                  children: [
                                    // 第一个选项卡的内容
                                    Center(
                                      //child: Text('History Content'),
                                      child: ListView.builder(
                                        //itemCount: historyList.length, // 历史内容的数量
                                        itemCount: newUserItem.userPastBlog?.length,
                                        itemBuilder: (BuildContext context,
                                            int index) {
                                          return GestureDetector(
                                              onTap: () {
                                                print("!!!tapped");
                                                _openBlogPage(newUserItem.userPastBlog![index].blogId!, newUserItem.userPastBlog![index].title!);
                                                // 在此处处理文本框点击事件，导航到详情页
                                              },
                                              child: Container(
                                                width: double.infinity,
                                                // 撑满屏幕宽度
                                                padding: EdgeInsets.all(10),
                                                // 方框的内边距
                                                margin: EdgeInsets.symmetric(
                                                    vertical: 10),
                                                // 方框之间的垂直间距
                                                decoration: BoxDecoration(
                                                  border: Border.all(
                                                      color: Colors.white), // 方框的边框
                                                  borderRadius: BorderRadius
                                                      .circular(10), // 方框的圆角
                                                ),
                                                child: Text(
                                                  //historyList[index], // 根据索引获取历史内容
                                                  newUserItem.userPastBlog![index].title != null?newUserItem.userPastBlog![index].title!:"load error",
                                                  style: TextStyle(
                                                    fontSize: 18,
                                                    color: textColor,
                                                  ),
                                                  maxLines: 1, // 显示一行文本
                                                  overflow: TextOverflow.ellipsis, // 使用省略号代替溢出的文本
                                                ),
                                              )
                                          );
                                        },
                                      ),
                                    ),
                                    // 第二个选项卡的内容
                                    Center(
                                      //child: Text('Group Content'),
                                      child: SingleChildScrollView(
                                        child: Column(
                                          mainAxisAlignment: MainAxisAlignment
                                              .start,
                                          children: [
                                            Wrap(
                                              alignment: WrapAlignment.start,
                                              // 从顶部左侧开始排列
                                              spacing: 10,
                                              // 设置按钮之间的水平间距
                                              runSpacing: 10,
                                              // 设置按钮之间的垂直间距
                                              children: [
                                                //for (int i = 0; i < groupList.length; i++)
                                                for (int i = 0; i < newUserItem.userGroupList!.length; i++)
                                                  ElevatedButton(
                                                    style: ElevatedButton
                                                        .styleFrom(
                                                      primary: buttonColor,
                                                      // 设置按钮的背景颜色
                                                      fixedSize: Size(
                                                          150, 50), // 设置按钮的大小
                                                    ),
                                                    child: Text(
                                                      //groupList[i].name,
                                                      newUserItem.userGroupList![i].groupName!,
                                                      style: TextStyle(
                                                        fontSize: 24, // 设置文本大小
                                                        color: Colors
                                                            .white, // 设置文本颜色
                                                      ),
                                                      overflow: TextOverflow
                                                          .ellipsis,
                                                      // 在文本过长时显示省略号
                                                      maxLines: 1, // 设置最大行数为1
                                                    ),
                                                    onPressed: () {

                                                      _showGroupInfoDialog(context, newUserItem.userGroupList![i].groupId!);// 处理按钮按下事件
                                                    },
                                                  ),
                                                ElevatedButton(
                                                  style: ElevatedButton
                                                      .styleFrom(
                                                    primary:buttonColor,
                                                    // 设置按钮的背景颜色
                                                    fixedSize: Size(
                                                        150, 50), // 设置按钮的大小
                                                  ),
                                                  child: Icon(
                                                    Icons.add, // 使用添加图标
                                                    size: 24, // 设置图标大小
                                                    color: Colors
                                                        .white, // 设置图标颜色
                                                  ),
                                                  onPressed: () {

                                                    setState(() {
                                                      // newUserItem. = 777;

                                                      widget.userDataChange(newUserItem);

                                                    });


                                                    print("add!!!!!");
                                                    print(widget.userItem.userID);
                                                    // 处理添加按钮按下事件，添加新的 group
                                                  },
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),

                  ],
                ),

              ),
            ]
        ),
      ),
    );
  }
// 点击 "Group" 按钮的处理函数
  Future<void> _showGroupInfoDialog(BuildContext context, int groupId) async {

    GroupItem groupItem = GroupItem();
    // showLoading(context);
    // User? user;
    try {
      // Map<String, String> getGroupInfo = {"username":_unameController.text, "password":_pwdController.text};
      // logInInfo(loginInfo);
      await DioUtil.getGroupInfo(groupId).then((value){
        // showLoading=false;
        if(value.isSuccess==true){

          // print(value.data);
          var json = jsonDecode(value.data);
          // print(json);
          groupItem = GroupItem.fromJson(json);
          // print('!!!');
          // print(groupItem.groupId);
          // print(groupItem.groupDescription.toString());

        }
      });
      // http://127.0.0.1:5000/login/

    } on DioError catch(e) {

    } finally {
      print("showDialog2222!!!");
    }
    print("showDialog!!!");

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Group Information'),
          content: Container(
            child: Column(
              children: [
                Text("creator ID:"),
                Text(groupItem.creator.toString()),
                Text("groupName:"),
                Text(groupItem.groupName.toString()),
                Text("groupDescription:"),
                Text(groupItem.groupDescription.toString()),
                Text("groupId:"),
                Text(groupItem.groupId.toString()),
              ],
            ),
          ),
          // content: FutureBuilder(
          //   // 从后端获取 group name 和 group description 的逻辑
          //   builder: (BuildContext context, AsyncSnapshot<GroupInfo> snapshot) {
          //     if (snapshot.connectionState == ConnectionState.waiting) {
          //       return CircularProgressIndicator(); // 加载中的指示器
          //     } else if (snapshot.hasError) {
          //       return Text('Error: ${snapshot.error}');
          //     } else if (!snapshot.hasData) {
          //       return Text('No data available.');
          //     } else {
          //       // 显示从后端获取的 group name 和 group description
          //       return Column(
          //         crossAxisAlignment: CrossAxisAlignment.start,
          //         mainAxisSize: MainAxisSize.min,
          //         children: [
          //           Text('Group Name: ${snapshot.data!.name}'),
          //           Text('Group Description: ${snapshot.data!.description}'),
          //         ],
          //       );
          //     }
          //   },
          // ),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // 关闭对话框
              },
              child: Text('Close'),
            ),
          ],
        );
      },
    );

  }

  void openLLMTokenDialog(){
    showDialog(
        context: context,
        builder: (context){
          return AlertDialog(
            title: Text("token stored"),
            content:Container(
              height: 150,
              child: Column(
                children: [
                  Text("Put your openAI token key here to activate the chatbot function",
                    style: TextStyle(
                      fontSize: 15,
                      color: MyColor.orange,
                      // fontWeight: FontWeight.bold,
                      // fontFamily: 'CustomFont',
                    ),
                  ),
                  Container(
                    child: TextField(
                      controller: tokenTextController,
                      decoration: InputDecoration(
                        hintText: 'Enter your openai token here',
                        enabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: MyColor.orange, width: 2),
                          borderRadius: BorderRadius.all(Radius.circular(8.0)), // 设置边框的圆角
                        ),
                        focusedBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: MyColor.orange, width: 5),
                          borderRadius: BorderRadius.all(Radius.circular(8.0)), // 设置边框的圆角
                        ),
                      ),
                      maxLines: 1,
                    ),
                  ),
                  Text("note: We are not going to upload you API key online, it will only be accessed and implimented locally on your device",
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey,
                      // fontWeight: FontWeight.bold,
                      // fontFamily: 'CustomFont',
                    ),
                  ),
                ],
              ),
            ),
            actions: [
              TextButton(
                child: Text(
                  "Save",
                  style: TextStyle(
                    fontSize: 16,
                    color: MyColor.orange, // 文本颜色
                  ),
                ),
                onPressed: () {
                  // 获取输入的文本
                  final inputText = tokenTextController.text;

                  saveTokenKey(inputText);


                  // 关闭对话框
                  Navigator.pop(context);
                },
              ),
            ],
          );
        }
    );
  }

  // 显示多选项对话框
  Future<void> _showMultiSelectionDialog(BuildContext context) async {
    final List<String> availablePreferences = [
      'Sport',
      'Animation',
      'Dance',
      'Music',
      'Game'
    ]; // 可选的选项列表

    final selectedPreferences = await showDialog<Set<String>>(
      context: context,
      builder: (BuildContext context) {
        Set<String> tempSelectedPreferences = Set<String>.from(_selectedPreferences); // 创建临时集合保存用户的更改

        return AlertDialog(
          title: Text(
            "manage your token",
            //"${user.gender}",
            style: TextStyle(
              fontSize: 16,
              color: MyColor.deepBlue, // 文本颜色
            ),
          ),
          content: SingleChildScrollView(
            child: Column(
              children: availablePreferences.map((String preference) {
                final bool isChecked = tempSelectedPreferences.contains(
                    preference);

                return CheckboxListTile(
                  title: Text(preference),
                  value: tempSelectedPreferences.contains(preference),
                  onChanged: (bool? value) {
                    _handlePreferenceSelection(preference, value, tempSelectedPreferences);
                  },
                );
              }).toList(),
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(null); // 关闭对话框，返回空值
              },
              child: Text(
                "Cancel",
                style: TextStyle(
                  fontSize: 16,
                  color: MyColor.orange, // 文本颜色
                ),
              ),
            ),
            TextButton(
              // style: ButtonStyle(
              //     // foregroundColor: MaterialStateProperty.all<Color>(Colors.blue),
              //     textStyle: MaterialStateProperty.all<TextStyle>(
              //         TextStyle(fontSize: 16, color: MyColor.orange)
              //     )
              // ),
              onPressed: () {
                // 用户点击 "保存" 按钮时，设置 _isSaving 为 true
                _isSaving = true;
                Navigator.of(context).pop(tempSelectedPreferences); // 关闭对话框，返回所选选项
              },
              child:Text(
                "Save",
                style: TextStyle(
                  fontSize: 16,
                  color: MyColor.orange, // 文本颜色
                ),
              ),
            ),
          ],
        );
      },
    );

    if (selectedPreferences != null) {
      // 如果用户点击了 "保存"，将所选选项保存到状态变量中
      setState(() {
        _selectedPreferences = selectedPreferences;
        this.preferencesSelected = selectedPreferences.isNotEmpty;
      });
    }
    // 用户点击 "取消" 或 "保存" 后，将 _isSaving 重置为 false
    _isSaving = false;
  }
  // 处理选项选择
  void _handlePreferenceSelection(String preference, bool? value, Set<String> tempSelectedPreferences) {
    if (value != null) {
      setState(() {
        if (value) {
          tempSelectedPreferences.add(preference);
        } else {
          tempSelectedPreferences.remove(preference);
        }
      });
    }
  }

  void _openBlogPage(int id, String title) {
    print("tapped!!!");
    ///add net connection later
    Navigator.of(context).push(
      MaterialPageRoute(
        // builder: (context) => CatCardPage2(systemStr: textEditingController.text.isEmpty?system:textEditingController.text,),
        builder: (context) => BlogPage(blogTitle: title,blogId: id,),
      ),
    );
  }


}

Future<void> saveTokenKey(String token) async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  await prefs.setString('LLM-key', token);
}

// 获取token
Future<String?> getTokenKey() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  return prefs.getString('LLM-key');
}

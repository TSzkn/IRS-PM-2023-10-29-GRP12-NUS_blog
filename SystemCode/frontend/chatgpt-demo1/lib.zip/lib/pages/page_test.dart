// // import 'dart:math';
// //
// // import 'package:flutter/material.dart';
// //
// // void main() => runApp(MyApp());
// //
// // class MyApp extends StatelessWidget {
// //   @override
// //   Widget build(BuildContext context) {
// //     return MaterialApp(
// //       title: 'Flutter 3D Cube Effect',
// //       theme: ThemeData(
// //         primarySwatch: Colors.green,
// //       ),
// //       home: Scaffold(
// //           body: Container(
// //             child: SafeArea(
// //               top: true,
// //               child: Column(
// //                 crossAxisAlignment: CrossAxisAlignment.center,
// //                 children: <Widget>[
// //                   Text('Flutter 3D Cube Effect'),
// //                   Expanded(
// //                     child: Pseudo3dSlider(),
// //                   ),
// //                 ],
// //               ),
// //             ),
// //           )),
// //     );
// //   }
// // }
// //
// // class Pseudo3dSlider extends StatefulWidget {
// //   @override
// //   _Pseudo3dSliderState createState() => _Pseudo3dSliderState();
// // }
// //
// // class _Pseudo3dSliderState extends State<Pseudo3dSlider> {
// //   Map<String, Offset> offsets = {
// //     'start': Offset(70, 100),
// //     'finish': Offset(200, 100),
// //     'center': Offset(100, 200),
// //   };
// //
// //   double originX = 0;
// //   double x = 0;
// //
// //   void onDragStart(double originX) => setState(() {
// //     this.originX = originX;
// //   });
// //
// //   void onDragUpdate(double x) => setState(() {
// //     this.x = originX - x;
// //   });
// //
// //   double get turnRatio {
// //     const step = -150.0;
// //     var k = x / step;
// //     k = k > 1 ? 1 : (k < 0 ? 0 : k);
// //     return 1 - k;
// //   }
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     return GestureDetector(
// //       behavior: HitTestBehavior.opaque,
// //       onPanStart: (details) => onDragUpdate(details.globalPosition.dx),
// //       onPanUpdate: (details) => onDragUpdate(details.globalPosition.dx),
// //       child: Slider(
// //         children: [
// //           _Side(
// //             color: Colors.blueAccent,
// //             number: 1,
// //           ),
// //           _Side(
// //             color: Colors.redAccent.shade200,
// //             number: 2,
// //           ),
// //           _Side(
// //             color: Colors.yellow,
// //             number: 3,
// //           ),
// //         ],
// //         k: turnRatio,
// //       ),
// //     );
// //   }
// // }
// //
// // class _Side extends StatelessWidget {
// //   const _Side({Key? key, required this.color, required this.number}) : super(key: key);
// //
// //   final Color color;
// //   final int number;
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     return Container(
// //       width: MediaQuery.of(context).size.width,
// //       height: MediaQuery.of(context).size.height,
// //       color: color,
// //       child: Center(
// //         child: Text(
// //           number.toString(),
// //           style: TextStyle(fontSize: 14),
// //         ),
// //       ),
// //     );
// //   }
// // }
// //
// // class Slider extends StatelessWidget {
// //   Slider({
// //     Key? key,
// //     required this.children,
// //     required this.k,
// //   }) : super(key: key) {
// //     assert(children.length == 3, 'wronge nubmer of children');
// //   }
// //
// //   final List<Widget> children;
// //   final double k;
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     var k1 = k;
// //     var k2 = 1 - k;
// //     print(k1);
// //     print(k2);
// //     return Row(
// //       children: <Widget>[
// //         Container(
// //           color: Colors.cyanAccent,
// //           child: Transform(
// //             transform: Matrix4.identity()
// //               ..setEntry(3, 2, 0.003)
// //               ..rotateY(pi / 2 * k1),
// //             alignment: FractionalOffset.centerRight,
// //             child: children[0],
// //           ),
// //         ),
// //
// //         Transform(
// //           transform: Matrix4.identity()
// //             ..setEntry(3, 2, 0.003)
// //             ..rotateY(pi / 2 * -k2),
// //           alignment: FractionalOffset.centerLeft,
// //           child: children[1],
// //         ),
// //       ],
// //     );
// //   }
// // }
//
//
// import 'dart:math';
// import 'dart:ui';
//
// import 'package:chatgpt/pages/start_page.dart';
// import 'package:chatgpt/pages/trending_page.dart';
// import 'package:cube_transition_plus/cube_transition_plus.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
//
// import 'chatbot_page.dart';
//
//
// class Sample3 extends StatelessWidget {
//   @override
//
//   List<Widget> majorPages = [
//     StartPlayPage(),
//     ChatBotPage(),
//     TrendingPage(),];
//
//   Widget build(BuildContext context) {
//     final height = MediaQuery.of(context).size.height;
//     return Scaffold(
//       // appBar: AppBar(
//       //   title: Text('Custom Cube Transition'),
//       // ),
//       body: Center(
//         child: SizedBox(
//           height: height,
//           child: CubePageView.builder(
//             itemCount: 3,
//             itemBuilder: (context, index, notifier) {
//               // final item = places[index];
//               final transform = Matrix4.identity();
//               final t = (index - notifier).abs();
//               final scale = lerpDouble(1.5, 0, t);
//
//               double startPositionLeft = 300;
//               double startPositionTop = 200;
//
//               double moveWidgetWidth = 100;
//               double moveWidgetHeight = 100;
//               transform.scale(scale, scale);
//               return CubeWidget(
//                 index: index,
//                 pageNotifier: notifier,
//                 child: Stack(
//                   children: [
//                     majorPages[index],
//
//                     (notifier-index)<=0?
//                     Positioned(
//                         // left: (notifier-index)<0.5?startPosition+(notifier-index)*300*2:startPosition+(notifier-index-0.5)*100,
//                         left: startPositionLeft+(notifier-index)*(startPositionLeft+100),
//                         top: startPositionTop,
//                         child: Transform.rotate(
//                           //旋转90度
//                           angle: 2*pi* (notifier-index),
//                           child:  InkWell(
//                             child:  Container(
//                               // color: Colors.amber,
//                               width: moveWidgetWidth,
//                               height: moveWidgetHeight,
//                               child: Container(
//                                 child: Image.asset('assets/images/lion_cute.png',
//                                   fit: BoxFit.fill,
//                                   width: moveWidgetHeight,
//                                 ),
//                               ),
//                               // child: Column(
//                               //   children: [
//                               //     Text(notifier.toString()),
//                               //     Text(index.toString())
//                               //   ],
//                               // ),
//                             ),
//                             onTap: (){
//
//                             },
//                           ),
//                         ),
//
//                     ):Container(),
//                     (notifier-index)>0?
//                     Positioned(
//                       // left: (notifier-index)<0.5?startPosition+(notifier-index)*300*2:startPosition+(notifier-index-0.5)*100,
//                         left: startPositionLeft+(notifier-index)*(startPositionLeft+100),
//                         top: startPositionTop,
//                         child: Transform.rotate(
//                           //旋转90度
//                             angle: 2*pi* (notifier-index),
//                             child:                         InkWell(
//                               child: Container(
//                                 // color: Colors.amber,
//                                 width: moveWidgetWidth,
//                                 height: moveWidgetHeight,
//
//                                 child: Container(
//                                   child: Image.asset('assets/images/lion_cute.png',
//                                     fit: BoxFit.fill,
//                                     width: 100,
//                                   ),
//                                 ),
// //                           child: Column(
// //                             children: [
// //
// // ,
// //                               Text(notifier.toString()),
// //                               Text(index.toString())
// //                             ],
// //                           ),
//                               ),
//                               onTap: (){
//
//                               },
//                             ),
//                         )
//                     ):Container(),
//                     Transform(
//                       alignment: Alignment.center,
//                       transform: transform,
//                       child: Container(),
//                       // child: Center(
//                       //   child: Padding(
//                       //     padding: const EdgeInsets.all(12.0),
//                       //     child: Container(
//                       //       decoration: BoxDecoration(boxShadow: [
//                       //         BoxShadow(
//                       //           color: Colors.black45,
//                       //           spreadRadius: 5,
//                       //           blurRadius: 5,
//                       //         ),
//                       //       ]),
//                       //       child: Text(
//                       //         "item",
//                       //         textAlign: TextAlign.center,
//                       //       ),
//                       //     ),
//                       //   ),
//                       // ),
//                     ),
//                   ],
//                 ),
//               );
//             },
//           ),
//         ),
//       ),
//     );
//   }
// }
//

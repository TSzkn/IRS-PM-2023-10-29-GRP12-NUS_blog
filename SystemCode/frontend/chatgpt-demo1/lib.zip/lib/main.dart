import 'dart:convert';

import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:chatgpt/pages/chatbot_page.dart';
import 'package:chatgpt/pages/login.dart';
import 'package:chatgpt/pages/main_page_controller.dart';
import 'package:chatgpt/pages/page_test.dart';
import 'package:chatgpt/pages/start_page.dart';
import 'package:chatgpt/pages/start_play.dart';
import 'package:chatgpt/utils/dio_util.dart';
import 'package:chatgpt/utils/userBean.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_keyboard_visibility/flutter_keyboard_visibility.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:shared_preferences/shared_preferences.dart';

// 保存token

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp])
      .then((_) {
    runApp(new MyApp());
  });
  // runApp(const MyApp());
}

class MyApp extends StatelessWidget {

  const MyApp({super.key});



  @override
  Widget build(BuildContext context) {
    return KeyboardVisibilityProvider(
      child: MaterialApp(
        title: 'NUS Demo',
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        home: const MyHomePage(title: 'Flutter Demo Home Page'),
      ),
    );
  }
}
final wsUrl = Uri.parse('ws://192.168.31.171:8081/websocket?token=token-123456');
var channel;
class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}
final viewInsets = EdgeInsets.fromWindowPadding(WidgetsBinding.instance.window.viewInsets,WidgetsBinding.instance.window.devicePixelRatio);

class _MyHomePageState extends State<MyHomePage> {

  String? _token;
  int loginStatus = 0;
  late userBean userItem;
  @override
  void initState()  {
    super.initState();
    print("init!!!!!");
    _loadToken();

    verifyToken();
    // String? token = getToken();
    // if token not getting
    if(loginStatus == 1) {
      // loginStatus = 1;
      ///get user info from backend
      fetchUser(123);



    }else{
      // loginStatus = 0;
    }
    // getTokenfromBackEnd()
    // String? token = storage.readToken();
    // _speech = stt.SpeechToText();
  }


  @override
  Widget build(BuildContext context) {
    final bool isKeyboardVisible = KeyboardVisibilityProvider.isKeyboardVisible(context);
    // Navigator.of(context).push(
    //   MaterialPageRoute(
    //     // builder: (context) => CatCardPage2(systemStr: textEditingController.text.isEmpty?system:textEditingController.text,),
    //     builder: (context) => LoginRoute(),
    //   ),
    // );
    // return ();

    return loginStatus==1? MyPageController(user: userItem,):LoginRoute();
    // return loginStatus==1? MyPageController():LoginRoute();

  }

  Future<void> _loadToken() async {
    String? token = await getToken();
    setState(() {
      _token = token;
      if(token!=null){
        print(token);
        saveToken('token-hello');
      }else{
        print("tokenNull");
        saveToken('token-hello');
      }
    });
  }

  Future<void> verifyToken() async {
    loginStatus = 0;
    // SharedPreferences prefs = await SharedPreferences.getInstance();
    // return 1;
  }

  Future<void> fetchUser(int userId) async {
    String result = mockUserData;
    var list = jsonDecode(result);
    var user = userBean.fromJson(list);
    userItem = user;
  }
}

Future<void> saveToken(String token) async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  await prefs.setString('token', token);
}

// 获取token
Future<String?> getToken() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  return prefs.getString('token');
}








